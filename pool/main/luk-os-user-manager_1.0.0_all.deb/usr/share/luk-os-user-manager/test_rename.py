import backend
import subprocess
from unittest.mock import MagicMock

# Mock subprocess.run
backend.subprocess.run = MagicMock()

def test_rename():
    print("Testing rename user...")
    username = "olduser"
    new_username = "newuser"
    realname = "New Name"
    
    success, msg = backend.modify_user(username, realname=realname, new_username=new_username)
    
    if success:
        print("Success!")
    else:
        print(f"Failed: {msg}")
        
    # Check the command called
    backend.subprocess.run.assert_called()
    args, kwargs = backend.subprocess.run.call_args
    print(f"Command called: {args[0]}")

if __name__ == "__main__":
    test_rename()
