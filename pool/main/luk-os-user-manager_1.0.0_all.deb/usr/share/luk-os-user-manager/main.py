import sys
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import os
import subprocess
import gettext
import locale

import config

# Setup Localization
config.setup_locale()

from ui import MainWindow

if __name__ == "__main__":
    # Check for root privileges
    if os.geteuid() != 0:
        # Try to run with pkexec
        print("Attempting to elevate privileges with pkexec...")
        try:
            # Pass the current python interpreter and script path
            # We need to preserve DISPLAY and XAUTHORITY for the GUI to work
            cmd = ['pkexec', 'env']
            
            for var in ['DISPLAY', 'XAUTHORITY', 'WAYLAND_DISPLAY']:
                if var in os.environ:
                    cmd.append(f'{var}={os.environ[var]}')
            
            script_path = os.path.abspath(sys.argv[0])
            args = sys.argv[1:]
            cmd.extend([sys.executable, script_path] + args)
            
            subprocess.check_call(cmd)
        except subprocess.CalledProcessError:
            print("Failed to elevate privileges. Exiting.")
            sys.exit(1)
        sys.exit(0)

    # Set default icon for the application
    icon_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
    if os.path.exists(icon_path):
        try:
            Gtk.Window.set_default_icon_from_file(icon_path)
        except Exception as e:
            print(f"Failed to set default icon: {e}")

    win = MainWindow()
    win.show_all()
    Gtk.main()
