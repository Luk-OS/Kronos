import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
import cairo

try:
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, 10, 10)
    p = Gdk.pixbuf_get_from_surface(s, 0, 0, 10, 10)
    print("Gdk.pixbuf_get_from_surface exists")
except Exception as e:
    print(f"Error: {e}")
