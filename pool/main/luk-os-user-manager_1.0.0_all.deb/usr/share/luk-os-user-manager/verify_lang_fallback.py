import os
import sys
import locale
from unittest.mock import patch

# Add current directory to path so we can import config
sys.path.append(os.getcwd())

import config

def test_fallback():
    print("Testing language fallback...")
    
    # Mock locale.getdefaultlocale to return Russian
    with patch('locale.getdefaultlocale', return_value=('ru_RU', 'UTF-8')):
        # Also mock getlocale just in case
        with patch('locale.getlocale', return_value=('ru_RU', 'UTF-8')):
            # Ensure config.get_language returns 'system'
            with patch('config.get_language', return_value='system'):
                # Reset environment
                if 'LANGUAGE' in os.environ:
                    del os.environ['LANGUAGE']
                
                print("Simulating system language: ru_RU")
                config.setup_locale()
                
                lang = os.environ.get('LANGUAGE')
                print(f"Resulting LANGUAGE: {lang}")
                
                if lang == 'en':
                    print("SUCCESS: Fallback to 'en' worked.")
                else:
                    print(f"FAILURE: Expected 'en', got '{lang}'")

def test_supported():
    print("\nTesting supported language (es)...")
    
    # Mock locale.getdefaultlocale to return Spanish
    with patch('locale.getdefaultlocale', return_value=('es_ES', 'UTF-8')):
        with patch('locale.getlocale', return_value=('es_ES', 'UTF-8')):
            with patch('config.get_language', return_value='system'):
                if 'LANGUAGE' in os.environ:
                    del os.environ['LANGUAGE']
                
                print("Simulating system language: es_ES")
                config.setup_locale()
                
                lang = os.environ.get('LANGUAGE')
                print(f"Resulting LANGUAGE: {lang}")
                
                if lang == 'es':
                    print("SUCCESS: Kept supported language 'es'.")
                else:
                    print(f"FAILURE: Expected 'es', got '{lang}'")

if __name__ == "__main__":
    test_fallback()
    test_supported()
