import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

try:
    print(f"Gdk.Pixbuf: {Gdk.Pixbuf}")
except AttributeError:
    print("Gdk.Pixbuf does not exist")

try:
    from gi.repository import GdkPixbuf
    print(f"GdkPixbuf: {GdkPixbuf}")
    print(f"GdkPixbuf.Pixbuf: {GdkPixbuf.Pixbuf}")
except ImportError:
    print("GdkPixbuf could not be imported")
