import subprocess
import pwd
import grp
import os

MIN_UID = 1000
MAX_UID = 60000
ADMIN_GROUPS = ['sudo', 'wheel', 'admin']

def get_primary_admin_group():
    """
    Returns the first available admin group from ADMIN_GROUPS.
    If none are found, it creates 'wheel' and returns it.
    """
    available_groups = [g.gr_name for g in grp.getgrall()]
    for group in ADMIN_GROUPS:
        if group in available_groups:
            return group
            
    # If we are here, no admin group exists. Create 'wheel'.
    try:
        subprocess.run(['groupadd', 'wheel'], check=True)
        return 'wheel'
    except subprocess.CalledProcessError:
        # If creation fails (e.g. permission denied), fallback to 'wheel' anyway
        # so the error propagates when we try to use it, or maybe just return it.
        return 'wheel'


def get_current_user():
    """
    Returns the username of the user who launched the application.
    Checks PKEXEC_UID first, then SUDO_USER, then falls back to current user.
    """
    # Check for pkexec
    pkexec_uid = os.environ.get('PKEXEC_UID')
    if pkexec_uid:
        try:
            return pwd.getpwuid(int(pkexec_uid)).pw_name
        except (ValueError, KeyError):
            pass
            
    # Check for sudo
    sudo_user = os.environ.get('SUDO_USER')
    if sudo_user:
        return sudo_user
        
    # Fallback to current effective user (likely root if running as root, or user if not)
    # But if we are running as root without pkexec/sudo, we might return 'root'.
    # The goal is to prevent the *real* user from deleting themselves.
    # If they are logged in as root directly, they probably shouldn't delete root either.
    return os.environ.get('USER') or os.getlogin()

def get_users():
    """
    Returns a list of dictionaries containing user info for normal users.
    """
    users = []
    for p in pwd.getpwall():
        if MIN_UID <= p.pw_uid <= MAX_UID:
            groups = [g.gr_name for g in grp.getgrall() if p.pw_name in g.gr_mem]
            try:
                primary_group = grp.getgrgid(p.pw_gid).gr_name
                if primary_group not in groups:
                    groups.insert(0, primary_group)
            except KeyError:
                pass
            
            users.append({
                'username': p.pw_name,
                'uid': p.pw_uid,
                'gid': p.pw_gid,
                'gecos': p.pw_gecos,
                'home': p.pw_dir,
                'shell': p.pw_shell,
                'groups': ", ".join(groups)
            })
    return users

def add_user(username, realname, password, primary_group=None, is_admin=False):
    """
    Adds a new user.
    """
    # Use -N to not create a user private group automatically
    # If a group with the username already exists, this prevents the error
    cmd = ['useradd', '-m', '-N', '-c', realname]
    
    # Set primary group - default to 'users' if not specified
    if not primary_group:
        # Check if 'users' group exists, otherwise use the first available group
        try:
            grp.getgrnam('users')
            primary_group = 'users'
        except KeyError:
            # Fallback to creating with default behavior (will create user group)
            # Remove -N flag in this case
            cmd = ['useradd', '-m', '-c', realname]
    
    if primary_group:
        cmd.extend(['-g', primary_group])
    
    if is_admin:
        cmd.extend(['-G', get_primary_admin_group()])
    
    cmd.append(username)
    
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        if password:
            subprocess.run(['chpasswd'], input=f"{username}:{password}".encode(), check=True)
        return True, _("User created successfully")
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr if e.stderr else str(e)
        return False, f"Error creating user: {error_msg}"



def modify_user(username, realname=None, groups=None, new_username=None):
    """
    Modifies an existing user.
    Modifies an existing user.
    groups: list of group names (strings) to set as secondary groups.
    new_username: str, if provided, renames the user.
    """
    cmd = ['usermod']
    if new_username and new_username != username:
        cmd.extend(['-l', new_username])
        # Move home directory to match new username
        # We assume standard home location /home/new_username
        new_home = os.path.join('/home', new_username)
        cmd.extend(['-d', new_home, '-m'])
    if realname is not None:
        cmd.extend(['-c', realname])
    
    if groups is not None:
        # -G sets the list of supplementary groups. 
        # If the list is empty, it removes all supplementary groups.
        cmd.extend(['-G', ",".join(groups)])
    
    cmd.append(username)
    
    try:
        subprocess.run(cmd, check=True)
        return True, _("User modified successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error modifying user: {e}"

def change_account_type(username, is_admin):
    """
    Changes the account type (Standard vs Administrator).
    """
    try:
        # Get current groups
        current_groups = [g.gr_name for g in grp.getgrall() if username in g.gr_mem]
        
        # Filter out primary group if it appears (usermod -G expects supplementary groups)
        # However, usermod -G replaces the list. We need to be careful.
        # Actually, let's just use gpasswd or usermod -aG / -G.
        # But modify_user uses usermod -G which REPLACES.
        
        # Let's stick to the pattern.
        if is_admin:
            # Add to primary admin group if not in any admin group
            is_already_admin = any(g in current_groups for g in ADMIN_GROUPS)
            if not is_already_admin:
                primary_admin = get_primary_admin_group()
                if primary_admin not in current_groups:
                    current_groups.append(primary_admin)
        else:
            # Remove from ALL admin groups
            for group in ADMIN_GROUPS:
                if group in current_groups:
                    current_groups.remove(group)
        
        cmd = ['usermod', '-G', ",".join(current_groups), username]
        subprocess.run(cmd, check=True)
        return True, _("Account type updated successfully")
    except Exception as e:
        return False, f"Error changing account type: {e}"

def get_available_groups():
    """
    Returns a list of all group names.
    """
    return [g.gr_name for g in grp.getgrall()]

def set_password(username, password):
    try:
        subprocess.run(['chpasswd'], input=f"{username}:{password}".encode(), check=True)
        return True, _("Password updated successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error setting password: {e}"

import ctypes
import ctypes.util

def get_shadow_hash(username):
    """
    Reads /etc/shadow manually to get the user's password hash.
    Replaces spwd module which is deprecated/removed.
    """
    try:
        with open('/etc/shadow', 'r') as f:
            for line in f:
                parts = line.strip().split(':')
                if parts[0] == username:
                    return parts[1]
    except Exception:
        pass
    return None

def crypt(word, salt):
    """
    Wrapper for C crypt function using ctypes.
    Replaces crypt module which is deprecated/removed.
    """
    try:
        libname = ctypes.util.find_library("crypt")
        if not libname:
            # Fallback for some systems
            libname = "libcrypt.so.1"
            
        lib = ctypes.CDLL(libname)
        lib.crypt.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        lib.crypt.restype = ctypes.c_char_p
        
        result = lib.crypt(word.encode('utf-8'), salt.encode('utf-8'))
        return result.decode('utf-8') if result else None
    except Exception:
        return None

def verify_password(username, password):
    """
    Verifies the user's password using manual shadow reading and ctypes crypt.
    """
    try:
        enc_passwd = get_shadow_hash(username)
        
        if not enc_passwd:
            return False, _("User not found")
            
        if enc_passwd in ["NP", "!", "*"]:
            return False, _("User has no password set or account is locked")
            
        # crypt(word, salt)
        # The salt is the first part of the hash (up to the 3rd $ for SHA-512)
        # Actually crypt takes the whole hash as salt and figures it out.
        calculated = crypt(password, enc_passwd)
        
        if calculated == enc_passwd:
            return True, _("Password correct")
        else:
            return False, _("The current password is incorrect")
            
    except Exception as e:
        return False, f"Error verifying password: {e}"

def get_home_contents(username):
    """
    Returns a list of file/folder names in the user's home directory.
    """
    try:
        home_dir = pwd.getpwnam(username).pw_dir
        # List all files/dirs, excluding . and ..
        # We might want to filter out hidden files or not. 
        # For now, let's return everything except . and ..
        items = []
        for item in os.listdir(home_dir):
            items.append(item)
        items.sort()
        return items
    except Exception:
        return []

def overwrite_user_home(src_username, dest_username, selection=None):
    """
    Overwrites the home directory of dest_username with the contents of src_username.
    WARNING: This deletes the existing content of dest_username's home if doing a full clone.
    If selection is provided (list of items), only those items are synced.
    """
    try:
        src_home = pwd.getpwnam(src_username).pw_dir
        dest_home = pwd.getpwnam(dest_username).pw_dir
        
        if selection is None:
            # Full clone
            # rsync -a --delete src_home/ dest_home
            # --delete ensures dest becomes an exact mirror
            cmd = ['rsync', '-a', '--delete', f'{src_home}/', dest_home]
            subprocess.run(cmd, check=True)
        else:
            # Selective clone
            # For each item in selection, rsync it.
            # We do NOT use --delete on the top level because we don't want to wipe dest_home,
            # but we might want to use --delete inside the folders being synced if we want them to be exact copies?
            # The user request implies "cloning", so making them exact copies of the source folders makes sense.
            # However, if we just want to "copy" them, maybe not delete?
            # Usually "clone" implies exact copy. Let's use --delete for the directories being synced.
            
            for item in selection:
                src_path = os.path.join(src_home, item)
                dest_path = os.path.join(dest_home, item)
                
                # If it's a directory, we want to sync its contents.
                # If it's a file, we just copy it.
                # rsync handles both gracefully.
                
                # Note: rsync source/ dest/  -> contents of source go into dest
                # rsync source dest/ -> source directory goes into dest (creating dest/source)
                
                # We want src_home/item to replace/be copied to dest_home/item
                
                # If we use: rsync -a --delete src_home/item dest_home/
                # It will create dest_home/item and sync contents.
                
                cmd = ['rsync', '-a', '--delete', src_path, dest_home]
                subprocess.run(cmd, check=True)

        # Fix ownership
        cmd_chown = ['chown', '-R', f'{dest_username}:{dest_username}', dest_home]
        subprocess.run(cmd_chown, check=True)
        
        return True, _("Home directory cloned successfully")
    except Exception as e:
        return False, f"Error cloning home: {e}"

def create_group(group_name):
    try:
        subprocess.run(['groupadd', group_name], check=True)
        return True, _("Group created successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error creating group: {e}"

def delete_group(group_name):
    try:
        subprocess.run(['groupdel', group_name], check=True)
        return True, _("Group deleted successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error deleting group: {e}"

def modify_group(old_name, new_name=None, new_gid=None):
    """
    Modifies a group (rename or change GID).
    """
    cmd = ['groupmod']
    if new_name and new_name != old_name:
        cmd.extend(['-n', new_name])
    
    if new_gid:
        cmd.extend(['-g', str(new_gid)])
        
    cmd.append(old_name)
    
    try:
        subprocess.run(cmd, check=True)
        return True, _("Group modified successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error modifying group: {e}"

def get_group_members(group_name):
    try:
        return grp.getgrnam(group_name).gr_mem
    except KeyError:
        return []

def update_group_members(group_name, members):
    """
    Updates the members of a group.
    members: list of usernames
    """
    try:
        # gpasswd -M user1,user2 group
        cmd = ['gpasswd', '-M', ",".join(members), group_name]
        subprocess.run(cmd, check=True)
        return True, _("Group members updated successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error updating group members: {e}"

def kill_user_processes(username):
    """
    Kills all processes owned by the user.
    """
    try:
        # pkill -KILL -u username (Force kill)
        subprocess.run(['pkill', '-KILL', '-u', username], check=False)
        # Give it a moment
        import time
        time.sleep(0.5)
        return True, _("Processes killed")
    except Exception as e:
        return False, f"Error killing processes: {e}"

def delete_user(username, remove_home=False):
    """
    Deletes a user.
    remove_home: bool, if True, deletes the home directory (-r)
    """
    try:
        cmd = ['userdel', '-f', username] # Force removal even if logged in
        if remove_home:
            cmd.append('-r')
        
        subprocess.run(cmd, check=True)
        return True, _("User deleted successfully")
    except subprocess.CalledProcessError as e:
        return False, f"Error deleting user: {e}"

def get_autologin_user():
    """
    Returns the username configured for autologin in LightDM, or None.
    """
    config_file = '/etc/lightdm/lightdm.conf'
    if not os.path.exists(config_file):
        return None
        
    try:
        with open(config_file, 'r') as f:
            lines = f.readlines()
            
        in_seat_section = False
        for line in lines:
            line = line.strip()
            if line.startswith('[Seat:*]'):
                in_seat_section = True
                continue
            elif line.startswith('[') and line.endswith(']'):
                in_seat_section = False
                continue
                
            if in_seat_section:
                if line.startswith('autologin-user='):
                    return line.split('=')[1].strip()
        return None
    except Exception:
        return None

def set_autologin_user(username, enable=True):
    """
    Enables or disables autologin for the given user in LightDM.
    """
    config_file = '/etc/lightdm/lightdm.conf'
    if not os.path.exists(config_file):
        return False, _("LightDM config file not found")
        
    try:
        with open(config_file, 'r') as f:
            lines = f.readlines()
            
        new_lines = []
        in_seat_section = False
        autologin_user_set = False
        autologin_timeout_set = False
        
        for line in lines:
            original_line = line
            line = line.strip()
            
            if line.startswith('[Seat:*]'):
                in_seat_section = True
                new_lines.append(original_line)
                continue
            elif line.startswith('[') and line.endswith(']'):
                in_seat_section = False
                # If we were in seat section and didn't set autologin yet (and we want to enable it),
                # we might need to append it before the new section starts? 
                # But usually it's better to replace existing lines or append to end of section.
                # Let's handle appending later if not found.
                
            if in_seat_section:
                if line.startswith('autologin-user='):
                    if enable:
                        new_lines.append(f"autologin-user={username}\n")
                        autologin_user_set = True
                    else:
                        # Comment it out or remove it
                        # new_lines.append(f"#autologin-user=\n") 
                        # Better to just remove it or comment it out to disable
                        pass 
                    continue
                elif line.startswith('autologin-user-timeout='):
                    if enable:
                        new_lines.append("autologin-user-timeout=0\n")
                        autologin_timeout_set = True
                    else:
                        pass
                    continue
            
            new_lines.append(original_line)
        
        # If enabling and we didn't find the lines to replace, we need to add them.
        # Finding the end of [Seat:*] section is tricky if it's not the last section.
        # We can just iterate again to find the insertion point.
        
        if enable and (not autologin_user_set or not autologin_timeout_set):
            # Re-process to insert if missing
            final_lines = []
            in_seat_section = False
            inserted = False
            
            for line in new_lines:
                stripped = line.strip()
                if stripped.startswith('[Seat:*]'):
                    in_seat_section = True
                    final_lines.append(line)
                    continue
                elif stripped.startswith('[') and stripped.endswith(']'):
                    if in_seat_section and not inserted:
                        # End of seat section, insert here
                        if not autologin_user_set:
                            final_lines.append(f"autologin-user={username}\n")
                        if not autologin_timeout_set:
                            final_lines.append("autologin-user-timeout=0\n")
                        inserted = True
                    in_seat_section = False
                
                final_lines.append(line)
            
            # If we reached the end and still haven't inserted (e.g. Seat is last section)
            if in_seat_section and not inserted:
                if not autologin_user_set:
                    final_lines.append(f"autologin-user={username}\n")
                if not autologin_timeout_set:
                    final_lines.append("autologin-user-timeout=0\n")
            
            new_lines = final_lines

        with open(config_file, 'w') as f:
            f.writelines(new_lines)
            
        return True, _("Autologin updated successfully")
    except Exception as e:
        return False, f"Error updating autologin: {e}"

def get_user_icon(username):
    """
    Returns the path to the user's icon if it exists, otherwise None.
    Checks /var/lib/AccountsService/icons/username and ~/.face
    """
    # Check AccountsService
    icon_path = os.path.join('/var/lib/AccountsService/icons', username)
    if os.path.exists(icon_path):
        return icon_path
        
    # Check ~/.face
    try:
        home_dir = pwd.getpwnam(username).pw_dir
        face_path = os.path.join(home_dir, '.face')
        if os.path.exists(face_path):
            return face_path
    except Exception:
        pass
        
    return None

def set_user_icon(username, image_path):
    """
    Sets the user's icon by copying the image to /var/lib/AccountsService/icons/username.
    """
    try:
        # Ensure the directory exists
        icons_dir = '/var/lib/AccountsService/icons'
        if not os.path.exists(icons_dir):
            os.makedirs(icons_dir, exist_ok=True)
            
        dest_path = os.path.join(icons_dir, username)
        
        # Copy the file
        import shutil
        shutil.copy2(image_path, dest_path)
        
        # Set permissions (readable by all, writable by root)
        os.chmod(dest_path, 0o644)
        
        return True, _("Icon updated successfully")
    except Exception as e:
        return False, f"Error setting icon: {e}"
