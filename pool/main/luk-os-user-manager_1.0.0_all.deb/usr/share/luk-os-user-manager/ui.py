import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, Pango, Gio, GLib
import threading
import backend
import config
import sys
import sys
import os
import grp
import secrets
import string
import pwd
import subprocess
import cairo
import math

# CSS Styling
# CSS Styling - Using system colors where possible
CSS = b"""
.user-row {
    padding: 6px;
    border-bottom: 1px solid alpha(@theme_fg_color, 0.1);
}
.user-row:selected {
    background-color: @theme_selected_bg_color;
    color: @theme_selected_fg_color;
}
.user-name {
    font-weight: bold;
    font-size: 13px;
}
.user-details {
    opacity: 0.7;
    font-size: 11px;
}
.admin-badge {
    background-color: #fce8e6;
    color: #c5221f;
    border-radius: 4px;
    padding: 1px 4px;
    font-size: 9px;
    font-weight: bold;
}
.desktop-badge {
    background-color: #e6f4ea;
    color: #137333;
    border-radius: 4px;
    padding: 1px 4px;
    font-size: 9px;
    font-weight: bold;
}
"""

# Constants
PASSWORD_RECOMMENDATIONS_TEXT = _("Password recommendations: Use at least 8 characters, including uppercase, lowercase, numbers, and symbols.")


def get_circular_pixbuf(pixbuf):
    if not pixbuf:
        return None
        
    width = pixbuf.get_width()
    height = pixbuf.get_height()
    
    # Create a surface to draw on
    surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, width, height)
    ctx = cairo.Context(surface)
    
    # Create the path for the circle
    ctx.arc(width / 2, height / 2, min(width, height) / 2, 0, 2 * math.pi)
    ctx.clip()
    
    # Draw the image
    Gdk.cairo_set_source_pixbuf(ctx, pixbuf, 0, 0)
    ctx.paint()
    
    # Get the pixbuf back from the surface
    return Gdk.pixbuf_get_from_surface(surface, 0, 0, width, height)

class UserRow(Gtk.ListBoxRow):
    def __init__(self, user_data):
        super().__init__()
        self.user_data = user_data
        self.get_style_context().add_class("user-row")

        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.add(hbox)

        # Avatar Icon
        icon_path = backend.get_user_icon(self.user_data['username'])
        pixbuf = None
        if icon_path:
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 32, 32, True)
            except Exception:
                pass
        
        if not pixbuf:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                pixbuf = icon_theme.load_icon("avatar-default", 32, 0)
            except Exception:
                pass

        if pixbuf:
            pixbuf = get_circular_pixbuf(pixbuf)
            avatar = Gtk.Image.new_from_pixbuf(pixbuf)
        else:
            # Fallback if everything fails
            avatar = Gtk.Image.new_from_icon_name("avatar-default", Gtk.IconSize.DND)
            avatar.set_pixel_size(32)
            
        hbox.pack_start(avatar, False, False, 0)

        # Info Box
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        hbox.pack_start(vbox, True, True, 0)

        # Top Row: Username + Badge
        top_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        vbox.pack_start(top_box, False, False, 0)

        username_label = Gtk.Label(label=self.user_data['username'])
        username_label.set_xalign(0)
        username_label.get_style_context().add_class("user-name")
        top_box.pack_start(username_label, False, False, 0)

        is_admin = any(g in self.user_data['groups'].split(", ") for g in backend.ADMIN_GROUPS)
        badge_label = Gtk.Label(label=_("ADMIN") if is_admin else _("USER"))
        badge_label.get_style_context().add_class("admin-badge" if is_admin else "desktop-badge")
        top_box.pack_start(badge_label, False, False, 0)

        # Bottom Row: Real Name
        realname = self.user_data['gecos']
        if not realname:
            realname = _("No Name")
        details_label = Gtk.Label(label=realname)
        details_label.set_xalign(0)
        details_label.get_style_context().add_class("user-details")
        vbox.pack_start(details_label, False, False, 0)

class ProgressDialog(Gtk.Window):
    def __init__(self, parent, message):
        super().__init__(title=_("Please Wait"), transient_for=parent, modal=True)
        self.set_default_size(300, 100)
        self.set_border_width(20)
        self.set_resizable(False)
        self.set_deletable(False)
        self.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.add(vbox)

        self.label = Gtk.Label(label=message)
        vbox.pack_start(self.label, True, True, 0)

        self.progressbar = Gtk.ProgressBar()
        vbox.pack_start(self.progressbar, True, True, 0)
        
        self.show_all()
        
        self._pulsing = False
        self._timeout_id = None

    def start_pulse(self):
        if not self._pulsing:
            self._pulsing = True
            self._timeout_id = GLib.timeout_add(100, self._pulse_callback)
            
    def stop_pulse(self):
        self._pulsing = False
        if self._timeout_id:
            GLib.source_remove(self._timeout_id)
            self._timeout_id = None
            
    def _pulse_callback(self):
        if not self._pulsing:
            return False
        self.progressbar.pulse()
        return True

    def pulse(self):
        self.progressbar.pulse()
        return True
        
    def destroy(self):
        self.stop_pulse()
        super().destroy()

class AboutDialog(Gtk.Dialog):
    def __init__(self, parent):
        super().__init__(title=_("About"), transient_for=parent, flags=0)
        self.set_default_size(400, 300)
        self.set_border_width(20)
        self.set_resizable(False)
        self.add_button(_("Close"), Gtk.ResponseType.CLOSE)
        
        box = self.get_content_area()
        box.set_spacing(15)
        box.set_halign(Gtk.Align.CENTER)
        
        # Logo/Icon - Use AssTest logo
        icon_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
        if os.path.exists(icon_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 64, 64, True)
                icon = Gtk.Image.new_from_pixbuf(pixbuf)
            except Exception as e:
                print(f"Failed to load logo for About dialog: {e}")
                icon = Gtk.Image.new_from_icon_name("system-users-symbolic", Gtk.IconSize.DIALOG)
                icon.set_pixel_size(64)
        else:
            icon = Gtk.Image.new_from_icon_name("system-users-symbolic", Gtk.IconSize.DIALOG)
            icon.set_pixel_size(64)
        box.pack_start(icon, False, False, 0)
        
        # Application Name
        name_label = Gtk.Label()
        name_label.set_markup(f"<span size='x-large' weight='bold'>{_('Luk-Os User Management')}</span>")
        box.pack_start(name_label, False, False, 0)
        
        # Version
        version_label = Gtk.Label()
        version_label.set_markup("<span size='small'>Version 1.0.0</span>")
        version_label.get_style_context().add_class("dim-label")
        box.pack_start(version_label, False, False, 0)
        
        # Description
        description_label = Gtk.Label()
        description_label.set_markup(
            "<span size='small'>" + 
            _("A modern and intuitive user management tool for Linux systems.\n"
              "Manage users, groups, and system permissions with ease.") +
            "</span>"
        )
        description_label.set_line_wrap(True)
        description_label.set_justify(Gtk.Justification.CENTER)
        description_label.set_max_width_chars(50)
        box.pack_start(description_label, False, False, 10)
        
        # Copyright/Credits
        credits_label = Gtk.Label()
        credits_label.set_markup(f"<span size='small'>{_('© 2026 Created by')} <a href='https://www.youtube.com/@AprendeConSthip'>Aprende con Sthip</a></span>")
        credits_label.get_style_context().add_class("dim-label")
        credits_label.connect("activate-link", self.on_activate_link)
        box.pack_start(credits_label, False, False, 0)
        
        self.show_all()

    def on_activate_link(self, label, uri):
        # We are running as root, so we need to drop privileges to open the browser
        # Try to get the original user from PKEXEC_UID or SUDO_UID
        uid = os.environ.get('PKEXEC_UID') or os.environ.get('SUDO_UID')
        
        if uid:
            try:
                user = pwd.getpwuid(int(uid)).pw_name
                # Run xdg-open as the user
                subprocess.Popen(['runuser', '-u', user, '--', 'xdg-open', uri])
                return True # Stop default handler
            except Exception as e:
                print(f"Failed to open link as user: {e}")
        
        # Fallback (might fail if root)
        return False # Let default handler try

class AddUserDialog(Gtk.Dialog):
    def __init__(self, parent):
        super().__init__(title=_("Add User"), transient_for=parent, flags=0)
        self.set_default_size(350, -1)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)

        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        box.add(grid)
        
        current_row = 0

        grid.attach(Gtk.Label(label=_("Name:"), xalign=1), 0, current_row, 1, 1)
        self.realname_entry = Gtk.Entry()
        grid.attach(self.realname_entry, 1, current_row, 1, 1)
        current_row += 1

        grid.attach(Gtk.Label(label=_("Username:"), xalign=1), 0, current_row, 1, 1)
        self.username_entry = Gtk.Entry()
        grid.attach(self.username_entry, 1, current_row, 1, 1)
        current_row += 1

        # Password Fields
        grid.attach(Gtk.Label(label=_("Password:"), xalign=1), 0, current_row, 1, 1)
        self.password_entry = Gtk.Entry(visibility=False)
        self.password_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.password_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.password_entry, 1, current_row, 1, 1)
        current_row += 1
        
        grid.attach(Gtk.Label(label=_("Confirm Password:"), xalign=1), 0, current_row, 1, 1)
        self.confirm_pass_entry = Gtk.Entry(visibility=False)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.confirm_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.confirm_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # Password Recommendations
        password_hint = Gtk.Label(label=_("Password recommendations: Use at least 8 characters, including uppercase, lowercase, numbers, and symbols."))
        password_hint.set_line_wrap(True)
        password_hint.set_max_width_chars(40)
        password_hint.set_xalign(0)
        password_hint.get_style_context().add_class("dim-label")
        grid.attach(password_hint, 0, current_row, 2, 1)
        current_row += 1
        
        # Generate Button
        self.generate_btn = Gtk.Button(label=_("Generate Random Password"))
        self.generate_btn.connect("clicked", self.on_generate_clicked)
        grid.attach(self.generate_btn, 1, current_row, 1, 1)
        current_row += 1

        grid.attach(Gtk.Label(label=_("Account Type:"), xalign=1), 0, current_row, 1, 1)
        self.account_type_combo = Gtk.ComboBoxText()
        self.account_type_combo.append_text(_("Desktop User"))
        self.account_type_combo.append_text(_("Administrator"))
        self.account_type_combo.set_active(0)
        grid.attach(self.account_type_combo, 1, current_row, 1, 1)

        self.show_all()

    def get_data(self):
        is_admin = self.account_type_combo.get_active_text() == _("Administrator")
        return (
            self.username_entry.get_text(),
            self.realname_entry.get_text(),
            self.password_entry.get_text(),
            is_admin
        )

    def on_password_icon_press(self, entry, icon_pos, event):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.set_visibility(not entry.get_visibility())
            icon_name = "view-conceal-symbolic" if entry.get_visibility() else "view-reveal-symbolic"
            entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, icon_name)
            
    def on_generate_clicked(self, btn):
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for i in range(12))
        
        self.password_entry.set_text(password)
        self.password_entry.set_visibility(True)
        self.password_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")
        
        self.confirm_pass_entry.set_text(password)
        self.confirm_pass_entry.set_visibility(True)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")

    def validate(self):
        username = self.username_entry.get_text()
        password = self.password_entry.get_text()
        confirm = self.confirm_pass_entry.get_text()
        
        if not username:
            return False, _("Username cannot be empty")
            
        if not password:
            return False, _("Password cannot be empty")
            
        if password != confirm:
            return False, _("Passwords do not match")
            
        return True, None



class UserGroupsDialog(Gtk.Dialog):
    def __init__(self, parent, username, current_groups):
        super().__init__(title=_("Manage Groups"), transient_for=parent, flags=0)
        self.set_default_size(300, 400)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        
        self.username = username
        self.current_groups = current_groups

        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Header
        label = Gtk.Label(label=f"{_('Groups for user')}: {username}")
        label.set_xalign(0)
        label.get_style_context().add_class("h3")
        box.pack_start(label, False, False, 0)

        # Scrollable List
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        box.pack_start(scroll, True, True, 0)

        self.groups_listbox = Gtk.ListBox()
        self.groups_listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        scroll.add(self.groups_listbox)
        
        self.populate_groups()
        self.show_all()

    def populate_groups(self):
        all_groups = backend.get_available_groups()
        all_groups.sort()

        for group in all_groups:


            row = Gtk.ListBoxRow()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.add(box)
            
            check = Gtk.CheckButton(label=group)
            check.set_active(group in self.current_groups)
            box.pack_start(check, True, True, 0)
            
            self.groups_listbox.add(row)

    def get_selected_groups(self):
        new_groups = []
        for row in self.groups_listbox.get_children():
            check = row.get_child().get_children()[0]
            if check.get_active():
                new_groups.append(check.get_label())
        return new_groups

class ChangePasswordDialog(Gtk.Dialog):
    def __init__(self, parent, username, show_current_password=True):
        super().__init__(title=_("Change Password"), transient_for=parent, flags=0)
        self.set_default_size(400, -1)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        
        self.username = username
        self.show_current_password = show_current_password
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        box.add(grid)
        
        current_row = 0
        
        # Current Password
        if self.show_current_password:
            grid.attach(Gtk.Label(label=_("Current Password:"), xalign=1), 0, current_row, 1, 1)
            self.current_pass_entry = Gtk.Entry(visibility=False)
            self.current_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
            self.current_pass_entry.connect("icon-press", self.on_password_icon_press)
            grid.attach(self.current_pass_entry, 1, current_row, 1, 1)
            current_row += 1
        else:
            self.current_pass_entry = None
        
        # New Password
        grid.attach(Gtk.Label(label=_("New Password:"), xalign=1), 0, current_row, 1, 1)
        self.new_pass_entry = Gtk.Entry(visibility=False)
        self.new_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.new_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.new_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # Confirm Password
        grid.attach(Gtk.Label(label=_("Confirm Password:"), xalign=1), 0, current_row, 1, 1)
        self.confirm_pass_entry = Gtk.Entry(visibility=False)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.confirm_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.confirm_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # Password Recommendations
        password_hint = Gtk.Label(label=_("Password recommendations: Use at least 8 characters, including uppercase, lowercase, numbers, and symbols."))
        password_hint.set_line_wrap(True)
        password_hint.set_max_width_chars(40)
        password_hint.set_xalign(0)
        password_hint.get_style_context().add_class("dim-label")
        grid.attach(password_hint, 0, current_row, 2, 1)
        current_row += 1
        
        # Generate Button
        self.generate_btn = Gtk.Button(label=_("Generate Random Password"))
        self.generate_btn.connect("clicked", self.on_generate_clicked)
        grid.attach(self.generate_btn, 1, current_row, 1, 1)
        
        self.show_all()
        
    def on_password_icon_press(self, entry, icon_pos, event):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.set_visibility(not entry.get_visibility())
            icon_name = "view-conceal-symbolic" if entry.get_visibility() else "view-reveal-symbolic"
            entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, icon_name)

    def on_generate_clicked(self, btn):
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for i in range(12))
        
        self.new_pass_entry.set_text(password)
        self.new_pass_entry.set_visibility(True)
        self.new_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")
        
        self.confirm_pass_entry.set_text(password)
        self.confirm_pass_entry.set_visibility(True)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")

    def get_data(self):
        current = self.current_pass_entry.get_text() if self.current_pass_entry else None
        new = self.new_pass_entry.get_text()
        return current, new
        
    def validate(self):
        if self.show_current_password:
            current = self.current_pass_entry.get_text()
            if not current:
                return False, _("Current password cannot be empty")
        
        new = self.new_pass_entry.get_text()
        confirm = self.confirm_pass_entry.get_text()
        
        if not new:
            return False, _("Password cannot be empty")
        
        if new != confirm:
            return False, _("Passwords do not match")
            
        return True, None

class UserDetailsPanel(Gtk.Box):
    def __init__(self, parent_window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.parent_window = parent_window
        self.user_data = None
        self.set_margin_top(15)
        self.set_margin_bottom(15)
        self.set_margin_start(15)
        self.set_margin_end(15)

        # Warning Label for Current User
        self.warning_label = Gtk.Label()
        self.warning_label.get_style_context().add_class("dim-label")
        self.warning_label.set_line_wrap(True)
        self.warning_label.set_xalign(0)
        self.pack_start(self.warning_label, False, False, 0)

        # Header: Avatar + Name
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        self.pack_start(header_box, False, False, 0)

        self.avatar_event_box = Gtk.EventBox()
        self.avatar_event_box.connect("button-press-event", self.on_avatar_clicked)
        self.avatar_event_box.set_tooltip_text(_("Click to change avatar"))
        header_box.pack_start(self.avatar_event_box, False, False, 0)

        self.avatar = Gtk.Image()
        # Initial default avatar
        icon_theme = Gtk.IconTheme.get_default()
        try:
            pixbuf = icon_theme.load_icon("avatar-default", 64, 0)
            pixbuf = get_circular_pixbuf(pixbuf)
            self.avatar.set_from_pixbuf(pixbuf)
        except Exception:
            self.avatar.set_from_icon_name("avatar-default", Gtk.IconSize.DIALOG)
            self.avatar.set_pixel_size(64)
            
        self.avatar_event_box.add(self.avatar)

        name_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        header_box.pack_start(name_box, True, True, 0)

        self.username_label = Gtk.Label()
        self.username_label.set_xalign(0)
        self.username_label.get_style_context().add_class("user-name")
        self.username_label.set_markup(f"<span size='x-large' weight='bold'>{_('Select a User')}</span>")
        name_box.pack_start(self.username_label, False, False, 0)

        self.realname_label = Gtk.Label()
        self.realname_label.set_xalign(0)
        self.realname_label.get_style_context().add_class("user-details")
        name_box.pack_start(self.realname_label, False, False, 0)

        # Rename Button
        self.rename_btn = Gtk.Button(label=_("Rename"))
        self.rename_btn.connect("clicked", self.on_rename_clicked)
        header_box.pack_end(self.rename_btn, False, False, 0)

        # Separator
        self.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 5)

        # Controls Grid
        self.grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        self.pack_start(self.grid, False, False, 0)

        # Account Type
        self.account_type_label = Gtk.Label(label=_("Account Type:"), xalign=1)
        self.grid.attach(self.account_type_label, 0, 0, 1, 1)
        self.account_type_combo = Gtk.ComboBoxText()
        self.account_type_combo.append_text(_("Desktop User"))
        self.account_type_combo.append_text(_("Administrator"))
        self.account_type_combo.connect("changed", self.on_account_type_changed)
        self.grid.attach(self.account_type_combo, 1, 0, 1, 1)

        # Password
        self.password_label = Gtk.Label(label=_("Password:"), xalign=1)
        self.grid.attach(self.password_label, 0, 1, 1, 1)
        self.change_pass_btn = Gtk.Button(label=_("Change Password..."))
        self.change_pass_btn.connect("clicked", self.on_change_password_clicked)
        self.grid.attach(self.change_pass_btn, 1, 1, 1, 1)

        # Manage Groups Button
        self.manage_groups_btn = Gtk.Button(label=_("Manage Groups"))
        self.manage_groups_btn.connect("clicked", self.on_manage_groups_clicked)
        self.grid.attach(self.manage_groups_btn, 1, 2, 1, 1)

        # Autologin Switch
        self.autologin_label = Gtk.Label(label=_("Autologin:"), xalign=1)
        self.grid.attach(self.autologin_label, 0, 3, 1, 1)
        self.autologin_switch = Gtk.Switch()
        self.autologin_switch.set_halign(Gtk.Align.START)
        self.autologin_handler_id = self.autologin_switch.connect("notify::active", self.on_autologin_toggled)
        self.grid.attach(self.autologin_switch, 1, 3, 1, 1)

        # Delete Button (Moved here)
        self.pack_end(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        self.delete_btn = Gtk.Button(label=_("Delete User"))
        self.delete_btn.get_style_context().add_class("destructive-action")
        self.delete_btn.connect("clicked", self.on_delete_clicked)
        self.pack_end(self.delete_btn, False, False, 0)

        # Initial State
        self.set_sensitive(False)

    def on_rename_clicked(self, btn):
        if not self.user_data:
            return
            
        dialog = RenameUserDialog(self.parent_window, self.user_data['username'], self.user_data['gecos'])
        if dialog.run() == Gtk.ResponseType.OK:
            new_username, new_realname = dialog.get_data()
            
            if new_username == self.user_data['username'] and new_realname == self.user_data['gecos']:
                dialog.destroy()
                return

            if new_username == self.user_data['username'] and new_realname == self.user_data['gecos']:
                dialog.destroy()
                return

            # Progress Dialog
            progress = ProgressDialog(self.parent_window, _("Renaming user..."))
            
            def target():
                # Kill processes first
                backend.kill_user_processes(self.user_data['username'])
                
                success, msg = backend.modify_user(
                    self.user_data['username'], 
                    realname=new_realname, 
                    new_username=new_username
                )
                GLib.idle_add(on_done, success, msg)

            def on_done(success, msg):
                progress.destroy()
                if success:
                    self.parent_window.refresh_users()
                else:
                    self.parent_window.show_error(msg)
                return False

            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            
            progress.start_pulse()
            
        dialog.destroy()

    def set_user(self, user_data):
        self.user_data = user_data
        if not user_data:
            self.set_sensitive(False)
            self.username_label.set_markup(f"<span size='x-large' weight='bold'>{_('Select a User')}</span>")
            self.realname_label.set_text("")
            
            # Default avatar for "Select a User"
            icon_theme = Gtk.IconTheme.get_default()
            try:
                pixbuf = icon_theme.load_icon("avatar-default", 64, 0)
                pixbuf = get_circular_pixbuf(pixbuf)
                self.avatar.set_from_pixbuf(pixbuf)
            except Exception:
                self.avatar.set_from_icon_name("avatar-default", Gtk.IconSize.DIALOG)
                self.avatar.set_pixel_size(64)
            return

        self.set_sensitive(True)
        
        # Check if this is the current user
        current_user = backend.get_current_user()
        is_current_user = (user_data['username'] == current_user)
        
        if is_current_user:
            self.delete_btn.set_sensitive(False)
            self.delete_btn.set_tooltip_text(_("You cannot delete the currently logged-in user."))
            self.rename_btn.set_sensitive(False)
            self.rename_btn.set_tooltip_text(_("You cannot rename the currently logged-in user."))
            self.account_type_combo.set_sensitive(False)
            self.account_type_combo.set_tooltip_text(_("You cannot change the account type of the currently logged-in user."))
            
            self.warning_label.set_markup(f"<span foreground='orange'>{_('Note: You cannot delete, rename, or change the account type of the currently logged-in user.')}</span>")
            self.warning_label.show()
        else:
            self.delete_btn.set_sensitive(True)
            self.delete_btn.set_tooltip_text("")
            self.rename_btn.set_sensitive(True)
            self.rename_btn.set_tooltip_text("")
            self.account_type_combo.set_sensitive(True)
            self.account_type_combo.set_tooltip_text("")
            self.warning_label.hide()

        self.username_label.set_markup(f"<span size='x-large' weight='bold'>{user_data['username']}</span>")
        self.realname_label.set_text(user_data['gecos'])
        
        # Load Avatar
        icon_path = backend.get_user_icon(user_data['username'])
        pixbuf = None
        if icon_path:
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 64, 64, True)
            except Exception:
                pass
        
        if not pixbuf:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                pixbuf = icon_theme.load_icon("avatar-default", 64, 0)
            except Exception:
                pass

        if pixbuf:
            pixbuf = get_circular_pixbuf(pixbuf)
            self.avatar.set_from_pixbuf(pixbuf)
        else:
            self.avatar.set_from_icon_name("avatar-default", Gtk.IconSize.DIALOG)
            self.avatar.set_pixel_size(64)
        
        # Set Account Type
        is_admin = any(g in user_data['groups'].split(", ") for g in backend.ADMIN_GROUPS)
        self.account_type_combo.set_active(1 if is_admin else 0)
        
        # Set Autologin State
        # Block signal to prevent triggering on_autologin_toggled
        self.autologin_switch.handler_block(self.autologin_handler_id)
        autologin_user = backend.get_autologin_user()
        self.autologin_switch.set_active(autologin_user == user_data['username'])
        self.autologin_switch.handler_unblock(self.autologin_handler_id)

        # Populate Groups - No longer needed here
        # self.populate_groups(user_data['groups'].split(", "))

    def on_manage_groups_clicked(self, btn):
        if not self.user_data:
            return
            
        current_groups = self.user_data['groups'].split(", ")
        dialog = UserGroupsDialog(self.parent_window, self.user_data['username'], current_groups)
        dialog.connect("response", self.on_manage_groups_response)
        dialog.show()
        
    def on_manage_groups_response(self, dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return

        new_groups = dialog.get_selected_groups()
        
        # Preserve Admin group if present
        current_groups = self.user_data['groups'].split(", ")
        for group in backend.ADMIN_GROUPS:
            if group in current_groups:
                new_groups.append(group)
        
        dialog.set_sensitive(False)
        progress = ProgressDialog(dialog, _("Updating groups..."))
        
        def target():
            success, msg = backend.modify_user(self.user_data['username'], groups=new_groups)
            GLib.idle_add(on_done, success, msg)

        def on_done(success, msg):
            progress.destroy()
            dialog.set_sensitive(True)
            
            if success:
                self.parent_window.refresh_users(keep_selection=True)
                dialog.destroy()
            else:
                self.parent_window.show_error(msg)
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        
        progress.start_pulse()

    def on_autologin_toggled(self, switch, gparam):
        if not self.user_data:
            return
            
        is_active = switch.get_active()
        username = self.user_data['username']
        
        # Confirmation
        action = _("enable") if is_active else _("disable")
        
        def on_confirmed(confirmed):
            if not confirmed:
                # Revert switch state without triggering signal
                switch.handler_block(self.autologin_handler_id)
                switch.set_active(not is_active)
                switch.handler_unblock(self.autologin_handler_id)
                return

            # Progress Dialog
            progress = ProgressDialog(self.parent_window, _("Updating autologin..."))
            
            def target():
                success, msg = backend.set_autologin_user(username, enable=is_active)
                GLib.idle_add(on_done, success, msg)

            def on_done(success, msg):
                progress.destroy()
                if not success:
                    self.parent_window.show_error(msg)
                    # Revert switch state without triggering signal
                    switch.handler_block(self.autologin_handler_id)
                    switch.set_active(not is_active)
                    switch.handler_unblock(self.autologin_handler_id)
                return False

            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            
            progress.start_pulse()

        self.parent_window.show_confirmation_dialog(
            f"{_('Are you sure you want to')} {action} {_('autologin for')} '{username}'?",
            on_confirmed
        )

    def on_account_type_changed(self, combo):
        if not self.user_data:
            return
        
        is_admin = combo.get_active_text() == _("Administrator")
        current_is_admin = any(g in self.user_data['groups'].split(", ") for g in backend.ADMIN_GROUPS)
        
        if is_admin != current_is_admin:
            def on_confirmed(confirmed):
                if not confirmed:
                    self.account_type_combo.set_active(1 if current_is_admin else 0)
                    return

                # Progress Dialog
                progress = ProgressDialog(self.parent_window, _("Updating account type..."))
                
                def target():
                    success, msg = backend.change_account_type(self.user_data['username'], is_admin)
                    GLib.idle_add(on_done, success, msg)

                def on_done(success, msg):
                    progress.destroy()
                    if success:
                        self.parent_window.refresh_users(keep_selection=True)
                    else:
                        self.parent_window.show_error(msg)
                        # Revert selection
                        self.account_type_combo.set_active(1 if current_is_admin else 0)
                    return False

                thread = threading.Thread(target=target)
                thread.daemon = True
                thread.start()
                
                progress.start_pulse()

            self.parent_window.show_confirmation_dialog(
                _("Are you sure you want to change the account type?"),
                on_confirmed
            )

    def on_change_password_clicked(self, btn):
        if not self.user_data:
            return
            
        dialog = ChangePasswordDialog(self.parent_window, self.user_data['username'], show_current_password=True)
        dialog.connect("response", self.on_change_password_response)
        dialog.show()

    def on_change_password_response(self, dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return
            
        valid, msg = dialog.validate()
        if not valid:
            self.parent_window.show_error(msg)
            return
            
        current_pass, new_pass = dialog.get_data()
        username = self.user_data['username']
        
        dialog.set_sensitive(False)
        progress = ProgressDialog(dialog, _("Updating password..."))
        
        def target():
            # Verify current password
            valid_current, msg_current = backend.verify_password(username, current_pass)
            if not valid_current:
                GLib.idle_add(on_fail, msg_current)
                return
            
            success, msg = backend.set_password(username, new_pass)
            if success:
                GLib.idle_add(on_success)
            else:
                GLib.idle_add(on_fail, msg)

        def on_fail(msg):
            progress.destroy()
            dialog.set_sensitive(True)
            self.parent_window.show_error(msg)
            return False
            
        def on_success():
            progress.destroy()
            dialog.destroy()
            msg_dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=_("Password updated successfully")
            )
            msg_dialog.run()
            msg_dialog.destroy()
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        
        progress.start_pulse()

    def on_avatar_clicked(self, widget, event):
        if not self.user_data:
            return
        
        # Create popover with "Change Photo" button
        popover = Gtk.Popover()
        popover.set_relative_to(widget)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.set_margin_top(6)
        vbox.set_margin_bottom(6)
        vbox.set_margin_start(6)
        vbox.set_margin_end(6)
        
        change_photo_btn = Gtk.ModelButton()
        change_photo_btn.set_label(_("Change Photo"))
        change_photo_btn.connect("clicked", self.on_change_photo_clicked, popover)
        vbox.pack_start(change_photo_btn, False, False, 0)
        
        popover.add(vbox)
        popover.show_all()
        popover.popup()
    
    def on_change_photo_clicked(self, button, popover):
        popover.popdown()
        
        if not self.user_data:
            return
            
        username = self.user_data['username']
        current_user = backend.get_current_user()
        
        # If we are editing the current user, try to launch mugshot
        if username == current_user:
            try:
                pw = pwd.getpwnam(username)
                uid = pw.pw_uid
                gid = pw.pw_gid
                home = pw.pw_dir
                
                def demote():
                    os.setgid(gid)
                    os.setuid(uid)
                    
                env = os.environ.copy()
                env['HOME'] = home
                env['USER'] = username
                env['LOGNAME'] = username
                
                # If we are root, we can demote. If not, we can't (but we should be root)
                if os.geteuid() == 0:
                    subprocess.Popen(['mugshot'], preexec_fn=demote, env=env)
                else:
                    subprocess.Popen(['mugshot'])
                return
            except FileNotFoundError:
                pass # Fallback to file chooser
            except Exception as e:
                print(f"Error launching mugshot: {e}")
                # Fallback to file chooser
        
        # Fallback: Show file chooser dialog
        self.show_avatar_chooser(username)

    def show_avatar_chooser(self, username):
        dialog = Gtk.FileChooserDialog(
            title=_("Select Avatar"),
            parent=self.parent_window,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        filter_image = Gtk.FileFilter()
        filter_image.set_name(_("Images"))
        filter_image.add_mime_type("image/png")
        filter_image.add_mime_type("image/jpeg")
        filter_image.add_mime_type("image/gif")
        dialog.add_filter(filter_image)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filename = dialog.get_filename()
            success, msg = backend.set_user_icon(username, filename)
            if success:
                # Refresh UI
                self.set_user(self.user_data)
                self.parent_window.refresh_users(keep_selection=True)
            else:
                self.parent_window.show_error(msg)
                
        dialog.destroy()

    def on_delete_clicked(self, widget):
        if not self.user_data:
            return
        
        username = self.user_data['username']
        
        # Custom Dialog for Deletion
        dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=f"{_('Are you sure you want to delete user')} '{username}'?"
        )
        dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(_("Keep Home"), 100)
        dialog.add_button(_("Delete Home"), 101)
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.CANCEL or response == Gtk.ResponseType.DELETE_EVENT:
            return

        remove_home = (response == 101)
        
        # Progress Dialog
        progress = ProgressDialog(self.parent_window, _("Deleting user..."))

        def target():
            # Kill processes
            backend.kill_user_processes(username)
            # Delete user
            success, msg = backend.delete_user(username, remove_home=remove_home)
            GLib.idle_add(on_done, success, msg)

        def on_done(success, msg):
            progress.destroy()
            if success:
                self.parent_window.refresh_users()
            else:
                self.parent_window.show_error(msg)
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

        progress.start_pulse()

    def retranslate_ui(self):
        self.avatar_event_box.set_tooltip_text(_("Click to change avatar"))
        if not self.user_data:
            self.username_label.set_markup(f"<span size='x-large' weight='bold'>{_('Select a User')}</span>")
        
        self.rename_btn.set_label(_("Rename"))
        
        self.account_type_label.set_text(_("Account Type:"))
        
        # Update Combo Box - Block signal to prevent triggering on_account_type_changed
        # We need to preserve selection
        active_id = self.account_type_combo.get_active()
        self.account_type_combo.handler_block_by_func(self.on_account_type_changed)
        self.account_type_combo.remove_all()
        self.account_type_combo.append_text(_("Desktop User"))
        self.account_type_combo.append_text(_("Administrator"))
        self.account_type_combo.set_active(active_id)
        self.account_type_combo.handler_unblock_by_func(self.on_account_type_changed)
        
        self.password_label.set_text(_("Password:"))
        self.change_pass_btn.set_label(_("Change Password..."))
        self.manage_groups_btn.set_label(_("Manage Groups"))
        self.autologin_label.set_text(_("Autologin:"))
        self.delete_btn.set_label(_("Delete User"))
        
        # Update warning label if visible
        if self.warning_label.get_visible():
             self.warning_label.set_markup(f"<span foreground='orange'>{_('Note: You cannot delete, rename, or change the account type of the currently logged-in user.')}</span>")

    def on_password_icon_press(self, entry, icon_pos, event):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.set_visibility(not entry.get_visibility())
            icon_name = "view-conceal-symbolic" if entry.get_visibility() else "view-reveal-symbolic"
            entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, icon_name)



class CloneUserPanel(Gtk.Box):
    def __init__(self, parent_window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.parent_window = parent_window
        self.set_margin_top(10)
        self.set_margin_bottom(10)
        self.set_margin_start(10)
        self.set_margin_end(10)
        
        self.selected_items = []

        # Title
        self.title = Gtk.Label(label=_("Clone User"))
        self.title.get_style_context().add_class("h2")
        self.pack_start(self.title, False, False, 0)

        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        grid.set_halign(Gtk.Align.CENTER)
        self.pack_start(grid, False, False, 0)

        # Source User
        self.source_label = Gtk.Label(label=_("Source User:"), xalign=1)
        grid.attach(self.source_label, 0, 0, 1, 1)
        self.source_combo = Gtk.ComboBoxText()
        grid.attach(self.source_combo, 1, 0, 1, 1)

        # Destination User
        self.dest_label = Gtk.Label(label=_("Destination User:"), xalign=1)
        grid.attach(self.dest_label, 0, 1, 1, 1)
        self.dest_combo = Gtk.ComboBoxText()
        grid.attach(self.dest_combo, 1, 1, 1, 1)

        # Buttons Box
        buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        buttons_box.set_halign(Gtk.Align.CENTER)
        self.pack_start(buttons_box, False, False, 20)

        # Clone Full Home Button
        self.clone_full_btn = Gtk.Button(label=_("Clone Full Home"))
        self.clone_full_btn.get_style_context().add_class("destructive-action")
        self.clone_full_btn.connect("clicked", self.on_clone_full_clicked)
        buttons_box.pack_start(self.clone_full_btn, True, True, 0)

        # Clone Specific Items Button
        self.clone_specific_btn = Gtk.Button(label=_("Clone Specific Items"))
        self.clone_specific_btn.connect("clicked", self.on_clone_specific_clicked)
        buttons_box.pack_start(self.clone_specific_btn, True, True, 0)
        
        self.refresh_sources()

    def retranslate_ui(self):
        self.title.set_text(_("Clone User"))
        self.source_label.set_text(_("Source User:"))
        self.dest_label.set_text(_("Destination User:"))
        self.clone_full_btn.set_label(_("Clone Full Home"))
        self.clone_specific_btn.set_label(_("Clone Specific Items"))


    def refresh_sources(self):
        self.source_combo.remove_all()
        self.dest_combo.remove_all()
        
        self.source_combo.append_text(_("Loading..."))
        self.source_combo.set_active(0)
        self.source_combo.set_sensitive(False)
        
        self.dest_combo.append_text(_("Loading..."))
        self.dest_combo.set_active(0)
        self.dest_combo.set_sensitive(False)
        
        def target():
            users = backend.get_users()
            GLib.idle_add(on_done, users)
            
        def on_done(users):
            self.source_combo.remove_all()
            self.dest_combo.remove_all()
            self.source_combo.set_sensitive(True)
            self.dest_combo.set_sensitive(True)
            
            for u in users:
                self.source_combo.append_text(u['username'])
                self.dest_combo.append_text(u['username'])
                
            if users:
                self.source_combo.set_active(0)
                if len(users) > 1:
                    self.dest_combo.set_active(1)
                else:
                    self.dest_combo.set_active(0)
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def on_clone_full_clicked(self, btn):
        """Clone the entire home directory"""
        src_user = self.source_combo.get_active_text()
        dest_user = self.dest_combo.get_active_text()

        if not src_user or not dest_user:
            self.parent_window.show_error(_("Please select both users"))
            return
            
        if src_user == dest_user:
            self.parent_window.show_error(_("Source and Destination cannot be the same"))
            return

        msg = f"{_('Are you sure you want to overwrite the home directory of')} '{dest_user}' {_('with data from')} '{src_user}'? {_('This cannot be undone.')}"

        if not self.parent_window.show_confirmation(msg):
            return

        self._perform_clone(src_user, dest_user, selection=None)

    def on_clone_specific_clicked(self, btn):
        """Open dialog to select specific items to clone"""
        src_user = self.source_combo.get_active_text()
        dest_user = self.dest_combo.get_active_text()

        if not src_user or not dest_user:
            self.parent_window.show_error(_("Please select both users"))
            return
            
        if src_user == dest_user:
            self.parent_window.show_error(_("Source and Destination cannot be the same"))
            return

        # Open selection dialog
        dialog = SelectItemsDialog(self.parent_window, src_user)
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            selected_items = dialog.get_selected_items()
            dialog.destroy()
            
            if not selected_items:
                self.parent_window.show_error(_("Please select at least one item to clone"))
                return
            
            msg = f"{_('Are you sure you want to clone selected items from')} '{src_user}' {_('to')} '{dest_user}'?"
            
            if not self.parent_window.show_confirmation(msg):
                return
            
            self._perform_clone(src_user, dest_user, selection=selected_items)
        else:
            dialog.destroy()

    def _perform_clone(self, src_user, dest_user, selection=None):
        """Perform the actual cloning operation"""
        # Progress Dialog
        progress = ProgressDialog(self.parent_window, _("Cloning data..."))
        
        def target():
            success, msg = backend.overwrite_user_home(src_user, dest_user, selection=selection)
            GLib.idle_add(on_done, success, msg)

        def on_done(success, msg):
            progress.destroy()
            if success:
                dialog = Gtk.MessageDialog(
                    transient_for=self.parent_window,
                    flags=0,
                    message_type=Gtk.MessageType.INFO,
                    buttons=Gtk.ButtonsType.OK,
                    text=_("Cloning completed successfully")
                )
                dialog.run()
                dialog.destroy()
            else:
                self.parent_window.show_error(msg)
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        
        progress.start_pulse()

class SelectItemsDialog(Gtk.Dialog):
    """Modal dialog for selecting specific items to clone"""
    def __init__(self, parent, source_user):
        super().__init__(title=_("Select Items to Clone"), transient_for=parent, flags=0)
        self.set_default_size(400, 450)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        
        self.source_user = source_user
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Header
        label = Gtk.Label(label=f"{_('Select items from')}: {source_user}")
        label.set_xalign(0)
        label.get_style_context().add_class("h3")
        box.pack_start(label, False, False, 0)

        # Search Entry
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Search items..."))
        self.search_entry.connect("search-changed", self.on_search_changed)
        box.pack_start(self.search_entry, False, False, 0)
        
        # Buttons for Select All / Deselect All
        buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        box.pack_start(buttons_box, False, False, 0)
        
        select_all_btn = Gtk.Button(label=_("Select All"))
        select_all_btn.connect("clicked", self.on_select_all_clicked)
        buttons_box.pack_start(select_all_btn, True, True, 0)
        
        deselect_all_btn = Gtk.Button(label=_("Deselect All"))
        deselect_all_btn.connect("clicked", self.on_deselect_all_clicked)
        buttons_box.pack_start(deselect_all_btn, True, True, 0)
        
        # Scrollable List
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        box.pack_start(scroll, True, True, 0)
        
        # TreeView for selection
        # Model: Name, Selected (bool)
        self.store = Gtk.ListStore(str, bool)
        
        # Filter
        self.filter = self.store.filter_new()
        self.filter.set_visible_func(self.filter_visible_func)
        
        self.tree = Gtk.TreeView(model=self.filter)
        
        renderer_toggle = Gtk.CellRendererToggle()
        renderer_toggle.connect("toggled", self.on_item_toggled)
        column_toggle = Gtk.TreeViewColumn(_("Clone"), renderer_toggle, active=1)
        self.tree.append_column(column_toggle)

        renderer_text = Gtk.CellRendererText()
        column_text = Gtk.TreeViewColumn(_("Item"), renderer_text, text=0)
        self.tree.append_column(column_text)

        scroll.add(self.tree)
        
        # Populate items
        self.populate_items()
        
        self.show_all()
    
    def on_select_all_clicked(self, button):
        """Select all items in the list"""
        for row in self.store:
            row[1] = True
    
    def on_deselect_all_clicked(self, button):
        """Deselect all items in the list"""
        for row in self.store:
            row[1] = False
    
    def populate_items(self):
        self.store.clear()
        
        # Add loading item
        self.store.append([_("Loading..."), False])
        self.tree.set_sensitive(False)
        
        def target():
            items = backend.get_home_contents(self.source_user)
            GLib.idle_add(on_done, items)
            
        def on_done(items):
            self.store.clear()
            self.tree.set_sensitive(True)
            for item in items:
                self.store.append([item, True])  # All selected by default
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
    
    def on_item_toggled(self, widget, path):
        # path is a string representing the path in the view's model (the filter)
        filter_path = Gtk.TreePath.new_from_string(path)
        filter_iter = self.filter.get_iter(filter_path)
        child_iter = self.filter.convert_iter_to_child_iter(filter_iter)
        self.store[child_iter][1] = not self.store[child_iter][1]

    def on_search_changed(self, entry):
        self.filter.refilter()

    def filter_visible_func(self, model, iter, data):
        search_text = self.search_entry.get_text().lower()
        if not search_text:
            return True
        item_text = model[iter][0].lower()
        return search_text in item_text
    
    def get_selected_items(self):
        selected = []
        for row in self.store:
            if row[1]:
                selected.append(row[0])
        return selected

class RenameUserDialog(Gtk.Dialog):
    def __init__(self, parent, username, realname):
        super().__init__(title=_("Rename User"), transient_for=parent, flags=0)
        self.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OK, Gtk.ResponseType.OK)
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        box.add(grid)
        
        grid.attach(Gtk.Label(label=_("New Username:"), xalign=1), 0, 0, 1, 1)
        self.username_entry = Gtk.Entry()
        self.username_entry.set_text(username)
        grid.attach(self.username_entry, 1, 0, 1, 1)

        grid.attach(Gtk.Label(label=_("Real Name:"), xalign=1), 0, 1, 1, 1)
        self.realname_entry = Gtk.Entry()
        self.realname_entry.set_text(realname)
        grid.attach(self.realname_entry, 1, 1, 1, 1)
        
        grid.attach(Gtk.Label(label=_("Note: Home directory will be moved."), xalign=0), 0, 2, 2, 1)
        
        warning_label = Gtk.Label(label=_("Warning: All processes owned by this user will be killed."), xalign=0)
        warning_label.get_style_context().add_class("dim-label") # Or a warning class if available
        # warning_label.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 0, 0, 1)) # Red color
        grid.attach(warning_label, 0, 3, 2, 1)

        self.show_all()

    def get_data(self):
        return self.username_entry.get_text(), self.realname_entry.get_text()

class RootPanel(Gtk.Box):
    def __init__(self, parent_window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.parent_window = parent_window
        self.set_margin_top(20)
        self.set_margin_bottom(20)
        self.set_margin_start(20)
        self.set_margin_end(20)
        
        self.title_label = Gtk.Label(label=_("Root Account Management"))
        self.title_label.get_style_context().add_class("h2")
        self.pack_start(self.title_label, False, False, 0)
        
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        grid.set_halign(Gtk.Align.CENTER)
        self.pack_start(grid, False, False, 0)
        
        current_row = 0
        
        # Current Password
        self.current_pass_label = Gtk.Label(label=_("Current Root Password:"), xalign=1)
        grid.attach(self.current_pass_label, 0, current_row, 1, 1)
        self.current_pass_entry = Gtk.Entry(visibility=False)
        self.current_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.current_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.current_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # New Password
        self.new_pass_label = Gtk.Label(label=_("New Root Password:"), xalign=1)
        grid.attach(self.new_pass_label, 0, current_row, 1, 1)
        self.new_pass_entry = Gtk.Entry(visibility=False)
        self.new_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.new_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.new_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # Confirm Password
        self.confirm_pass_label = Gtk.Label(label=_("Confirm New Password:"), xalign=1)
        grid.attach(self.confirm_pass_label, 0, current_row, 1, 1)
        self.confirm_pass_entry = Gtk.Entry(visibility=False)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.confirm_pass_entry.connect("icon-press", self.on_password_icon_press)
        grid.attach(self.confirm_pass_entry, 1, current_row, 1, 1)
        current_row += 1
        
        # Password Recommendations
        self.password_hint = Gtk.Label(label=_("Password recommendations: Use at least 8 characters, including uppercase, lowercase, numbers, and symbols."))
        self.password_hint.set_line_wrap(True)
        self.password_hint.set_max_width_chars(40)
        self.password_hint.set_xalign(0)
        self.password_hint.get_style_context().add_class("dim-label")
        grid.attach(self.password_hint, 0, current_row, 2, 1)
        current_row += 1
        
        # Generate Button
        self.generate_btn = Gtk.Button(label=_("Generate Random Password"))
        self.generate_btn.connect("clicked", self.on_generate_clicked)
        grid.attach(self.generate_btn, 1, current_row, 1, 1)
        current_row += 1
        
        self.update_btn = Gtk.Button(label=_("Update Password"))
        self.update_btn.get_style_context().add_class("destructive-action")
        self.update_btn.connect("clicked", self.on_update_clicked)
        grid.attach(self.update_btn, 1, current_row, 1, 1)
        
    def on_password_icon_press(self, entry, icon_pos, event):
        if icon_pos == Gtk.EntryIconPosition.SECONDARY:
            entry.set_visibility(not entry.get_visibility())
            icon_name = "view-conceal-symbolic" if entry.get_visibility() else "view-reveal-symbolic"
            entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, icon_name)

    def on_generate_clicked(self, btn):
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
        password = ''.join(secrets.choice(alphabet) for i in range(12))
        
        self.new_pass_entry.set_text(password)
        self.new_pass_entry.set_visibility(True)
        self.new_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")
        
        self.confirm_pass_entry.set_text(password)
        self.confirm_pass_entry.set_visibility(True)
        self.confirm_pass_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-conceal-symbolic")
        
    def on_update_clicked(self, btn):
        current_pass = self.current_pass_entry.get_text()
        new_pass = self.new_pass_entry.get_text()
        confirm_pass = self.confirm_pass_entry.get_text()
        
        if not current_pass:
            self.parent_window.show_error(_("Current password cannot be empty"))
            return
            
        if not new_pass:
            self.parent_window.show_error(_("New password cannot be empty"))
            return
            
        if new_pass != confirm_pass:
            self.parent_window.show_error(_("Passwords do not match"))
            return
            
        # Progress Dialog
        progress = ProgressDialog(self.parent_window, _("Updating root password..."))
        
        def target():
            # Verify current password
            valid_current, msg_current = backend.verify_password('root', current_pass)
            if not valid_current:
                GLib.idle_add(on_fail, msg_current)
                return
            
            success, msg = backend.set_password('root', new_pass)
            if success:
                GLib.idle_add(on_success)
            else:
                GLib.idle_add(on_fail, msg)

        def on_fail(msg):
            progress.destroy()
            self.parent_window.show_error(msg)
            return False
            
        def on_success():
            progress.destroy()
            self.current_pass_entry.set_text("")
            self.new_pass_entry.set_text("")
            self.confirm_pass_entry.set_text("")
            
            dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=_("Root password updated successfully")
            )
            dialog.run()
            dialog.destroy()
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        
        progress.start_pulse()

    def retranslate_ui(self):
        self.title_label.set_text(_("Root Account Management"))
        self.current_pass_label.set_text(_("Current Root Password:"))
        self.new_pass_label.set_text(_("New Root Password:"))
        self.confirm_pass_label.set_text(_("Confirm New Password:"))
        self.password_hint.set_text(_("Password recommendations: Use at least 8 characters, including uppercase, lowercase, numbers, and symbols."))
        self.generate_btn.set_label(_("Generate Random Password"))
        self.update_btn.set_label(_("Update Password"))

class EditGroupDialog(Gtk.Dialog):
    def __init__(self, parent, group_name):
        super().__init__(title=_("Edit Group"), transient_for=parent, flags=0)
        self.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OK, Gtk.ResponseType.OK)
        self.group_name = group_name
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        box.add(grid)
        
        # Get current GID
        try:
            current_gid = grp.getgrnam(group_name).gr_gid
        except KeyError:
            current_gid = ""

        grid.attach(Gtk.Label(label=_("Group Name:"), xalign=1), 0, 0, 1, 1)
        self.name_entry = Gtk.Entry()
        self.name_entry.set_text(group_name)
        grid.attach(self.name_entry, 1, 0, 1, 1)

        grid.attach(Gtk.Label(label=_("GID:"), xalign=1), 0, 1, 1, 1)
        self.gid_entry = Gtk.Entry()
        self.gid_entry.set_text(str(current_gid))
        grid.attach(self.gid_entry, 1, 1, 1, 1)

        self.show_all()

    def get_data(self):
        return self.name_entry.get_text(), self.gid_entry.get_text()

class GroupManagementPanel(Gtk.Box):
    def __init__(self, parent_window):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.parent_window = parent_window
        self.set_margin_top(10)
        self.set_margin_bottom(10)
        self.set_margin_start(10)
        self.set_margin_end(10)

        # Left: Groups List
        left_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        self.pack_start(left_vbox, False, False, 0)
        left_vbox.set_size_request(200, -1)
        
        self.groups_label = Gtk.Label(label=_("Groups"), xalign=0)
        left_vbox.pack_start(self.groups_label, False, False, 0)

        # Search Entry for Groups
        self.group_search_entry = Gtk.SearchEntry()
        self.group_search_entry.set_placeholder_text(_("Search Groups..."))
        self.group_search_entry.connect("search-changed", self.on_group_search_changed)
        left_vbox.pack_start(self.group_search_entry, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        left_vbox.pack_start(scroll, True, True, 0)

        self.groups_listbox = Gtk.ListBox()
        self.groups_listbox.connect("row-selected", self.on_group_selected)
        scroll.add(self.groups_listbox)

        # Add/Delete Group Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        left_vbox.pack_start(btn_box, False, False, 0)

        add_btn = Gtk.Button(label="+")
        add_btn.connect("clicked", self.on_add_group)
        btn_box.pack_start(add_btn, True, True, 0)

        del_btn = Gtk.Button(label="-")
        del_btn.connect("clicked", self.on_delete_group)
        btn_box.pack_start(del_btn, True, True, 0)

        edit_btn = Gtk.Button()
        edit_btn.add(Gtk.Image.new_from_icon_name("document-edit-symbolic", Gtk.IconSize.BUTTON))
        edit_btn.connect("clicked", self.on_edit_group)
        btn_box.pack_start(edit_btn, True, True, 0)

        # Right: Members
        right_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        self.pack_start(right_vbox, True, True, 0)

        self.group_label = Gtk.Label(label=_("Select a group"), xalign=0)
        self.group_label.get_style_context().add_class("h3")
        right_vbox.pack_start(self.group_label, False, False, 0)

        scroll_members = Gtk.ScrolledWindow()
        scroll_members.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        right_vbox.pack_start(scroll_members, True, True, 0)

        self.members_listbox = Gtk.ListBox()
        self.members_listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        scroll_members.add(self.members_listbox)

        self.apply_btn = Gtk.Button(label=_("Apply Membership Changes"))
        self.apply_btn.connect("clicked", self.on_apply_members)
        right_vbox.pack_start(self.apply_btn, False, False, 0)

        self.current_group = None
        self.refresh_groups()

    def refresh_groups(self, keep_selection=False):
        current_selection = self.current_group if keep_selection else None
        
        for child in self.groups_listbox.get_children():
            self.groups_listbox.remove(child)
            
        # Spinner
        spinner_row = Gtk.ListBoxRow()
        spinner = Gtk.Spinner()
        spinner.start()
        spinner_row.add(spinner)
        self.groups_listbox.add(spinner_row)
        self.groups_listbox.show_all()
        
        def target():
            groups = backend.get_available_groups()
            groups.sort()
            GLib.idle_add(on_done, groups)
            
        def on_done(groups):
            for child in self.groups_listbox.get_children():
                self.groups_listbox.remove(child)
        
            for g in groups:
                row = Gtk.ListBoxRow()
                lbl = Gtk.Label(label=g, xalign=0)
                lbl.set_margin_start(5)
                row.add(lbl)
                row.group_name = g
                self.groups_listbox.add(row)
                
                if current_selection and g == current_selection:
                    self.groups_listbox.select_row(row)
            
            self.groups_listbox.show_all()
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def on_group_selected(self, listbox, row):
        if not row:
            self.current_group = None
            self.group_label.set_text(_("Select a group"))
            self.clear_members()
            return
        
        self.current_group = row.group_name
        self.group_label.set_text(f"{_('Group')}: {self.current_group}")
        self.load_members()

    def clear_members(self):
        for child in self.members_listbox.get_children():
            self.members_listbox.remove(child)

    def load_members(self):
        self.clear_members()
        if not self.current_group:
            return

        # Spinner
        spinner_row = Gtk.ListBoxRow()
        spinner_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        spinner_box.set_halign(Gtk.Align.CENTER)
        spinner = Gtk.Spinner()
        spinner.start()
        spinner_box.pack_start(spinner, True, True, 0)
        spinner_box.pack_start(Gtk.Label(label=_("Loading members...")), False, False, 0)
        spinner_row.add(spinner_box)
        spinner_row.set_selectable(False)
        self.members_listbox.add(spinner_row)
        self.members_listbox.show_all()
        
        group_name = self.current_group

        def target():
            members = backend.get_group_members(group_name)
            all_users = backend.get_users()
            GLib.idle_add(on_done, members, all_users)

        def on_done(members, all_users):
            # Check if group changed while loading
            if self.current_group != group_name:
                return False

            self.clear_members()
            
            for u in all_users:
                username = u['username']
                row = Gtk.ListBoxRow()
                box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                row.add(box)
                
                check = Gtk.CheckButton(label=f"{username} ({u['gecos']})")
                check.set_active(username in members)
                box.pack_start(check, True, True, 0)
                
                self.members_listbox.add(row)
            
            self.members_listbox.show_all()
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def on_add_group(self, btn):
        dialog = Gtk.Dialog(title=_("Create Group"), transient_for=self.parent_window, flags=0)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OK, Gtk.ResponseType.OK)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        entry = Gtk.Entry()
        entry.set_placeholder_text(_("Group Name"))
        box.add(entry)
        box.show_all()
        
        if dialog.run() == Gtk.ResponseType.OK:
            group_name = entry.get_text()
            if group_name:
                dialog.set_sensitive(False)
                progress = ProgressDialog(dialog, _("Creating group..."))
                
                def target():
                    success, msg = backend.create_group(group_name)
                    GLib.idle_add(on_done, success, msg)
                    
                def on_done(success, msg):
                    progress.destroy()
                    dialog.set_sensitive(True)
                    if success:
                        self.refresh_groups()
                        dialog.destroy()
                    else:
                        self.parent_window.show_error(msg)
                    return False

                thread = threading.Thread(target=target)
                thread.daemon = True
                thread.start()
                progress.start_pulse()
            else:
                dialog.destroy()
        else:
            dialog.destroy()

    def on_delete_group(self, btn):
        if not self.current_group:
            return
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"{_('Delete group')} '{self.current_group}'?"
        )
        if dialog.run() == Gtk.ResponseType.YES:
            progress = ProgressDialog(self.parent_window, _("Deleting group..."))
            
            def target():
                success, msg = backend.delete_group(self.current_group)
                GLib.idle_add(on_done, success, msg)
                
            def on_done(success, msg):
                progress.destroy()
                if success:
                    self.refresh_groups()
                    self.current_group = None
                    self.clear_members()
                else:
                    self.parent_window.show_error(msg)
                return False

            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            progress.start_pulse()
        dialog.destroy()

    def on_edit_group(self, btn):
        if not self.current_group:
            return

        dialog = EditGroupDialog(self.parent_window, self.current_group)
        if dialog.run() == Gtk.ResponseType.OK:
            new_name, new_gid = dialog.get_data()
            
            # Check if changed
            if new_name == self.current_group and str(grp.getgrnam(self.current_group).gr_gid) == new_gid:
                dialog.destroy()
                return

            dialog.set_sensitive(False)
            progress = ProgressDialog(dialog, _("Modifying group..."))
            
            def target():
                success, msg = backend.modify_group(self.current_group, new_name, new_gid)
                GLib.idle_add(on_done, success, msg)
                
            def on_done(success, msg):
                progress.destroy()
                dialog.set_sensitive(True)
                if success:
                    self.refresh_groups()
                    # Reselect if renamed?
                    self.current_group = new_name
                    # Find and select... simpler to just refresh and clear for now or try to reselect
                    self.clear_members()
                    self.group_label.set_text(_("Select a group"))
                    dialog.destroy()
                else:
                    self.parent_window.show_error(msg)
                return False

            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            progress.start_pulse()
        else:
            dialog.destroy()

    def on_apply_members(self, btn):
        if not self.current_group:
            return
        
        new_members = []
        for row in self.members_listbox.get_children():
            check = row.get_child().get_children()[0]
            if check.get_active():
                # Extract username from label "username (Real Name)"
                label = check.get_label()
                username = label.split(" (")[0]
                new_members.append(username)
        
        if not self.parent_window.show_confirmation(_("Are you sure you want to apply these membership changes?")):
            return

        progress = ProgressDialog(self.parent_window, _("Updating group members..."))
        
        def target():
            success, msg = backend.update_group_members(self.current_group, new_members)
            GLib.idle_add(on_done, success, msg)
            
        def on_done(success, msg):
            progress.destroy()
            if not success:
                self.parent_window.show_error(msg)
            else:
                # Show success?
                pass
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        progress.start_pulse()

    def on_group_search_changed(self, search_entry):
        """Filter groups list based on search text"""
        search_text = search_entry.get_text().lower()
        for row in self.groups_listbox.get_children():
            if hasattr(row, 'group_name'):
                group_name = row.group_name.lower()
                if search_text in group_name:
                    row.show()
                else:
                    row.hide()


    def retranslate_ui(self):
        self.groups_label.set_text(_("Groups"))
        self.group_search_entry.set_placeholder_text(_("Search Groups..."))
        self.apply_btn.set_label(_("Apply Membership Changes"))
        
        if not self.current_group:
            self.group_label.set_text(_("Select a group"))
        else:
            self.group_label.set_text(f"{_('Group')}: {self.current_group}")
            
        # Refresh lists to update content if needed
        # self.refresh_groups() # This might be too much, but maybe needed for localized group names if any? 
        # Group names are usually system names, so not translated.


class MainWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title=_("Luk-Os User Management"))
        self.set_default_size(700, 450)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.connect("delete-event", self.on_delete_event)
        self.restart_app = False
        
        # Set window icon
        icon_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
        if os.path.exists(icon_path):
            try:
                self.set_icon_from_file(icon_path)
            except Exception as e:
                print(f"Failed to load icon: {e}")

        # Apply CSS
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        # HeaderBar
        self.header = Gtk.HeaderBar()
        self.header.set_show_close_button(True)
        self.header.set_title(_("Luk-Os User Management"))
        self.set_titlebar(self.header)

        # Toolbar Buttons (Only Refresh and Language remain in header)
        self.refresh_btn = Gtk.Button()
        self.refresh_btn.add(Gtk.Image.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.BUTTON))
        self.refresh_btn.set_tooltip_text(_("Refresh"))
        self.refresh_btn.connect("clicked", self.on_refresh_clicked)
        self.header.pack_end(self.refresh_btn)

        # Language Switcher
        self.lang_btn = Gtk.MenuButton()
        self.lang_btn.add(Gtk.Image.new_from_icon_name("preferences-desktop-locale-symbolic", Gtk.IconSize.BUTTON))
        self.lang_btn.set_tooltip_text(_("Change Language"))
        
        lang_popover = Gtk.Popover()
        lang_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        lang_popover.add(lang_vbox)
        
        languages = [
            ("System Default", "system"),
            ("English", "en"),
            ("Español", "es"),
            ("Français", "fr"),
            ("Deutsch", "de"),
            ("Italiano", "it"),
            ("Português", "pt")
        ]
        
        current_lang = config.get_language()
        


        group = None
        for label, code in languages:
            row = Gtk.RadioButton.new_with_label_from_widget(group, label)
            if group is None:
                group = row
            
            # Set active state
            if code == current_lang:
                row.set_active(True)
            
            row.connect("toggled", self.on_language_selected, code)
            lang_vbox.pack_start(row, False, False, 0)
            
        lang_vbox.show_all()
        self.lang_btn.set_popover(lang_popover)
        self.header.pack_end(self.lang_btn)

        # About Button
        self.about_btn = Gtk.Button()
        self.about_btn.add(Gtk.Image.new_from_icon_name("help-about-symbolic", Gtk.IconSize.BUTTON))
        self.about_btn.set_tooltip_text(_("About"))
        self.about_btn.connect("clicked", self.on_about_clicked)
        self.header.pack_end(self.about_btn)

        # Main Layout: Notebook
        self.notebook = Gtk.Notebook()
        self.add(self.notebook)

        # Tab 1: Users
        self.users_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        
        # Left: User List
        left_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_vbox.set_size_request(250, -1)
        self.users_paned.pack1(left_vbox, resize=False, shrink=False)

        self.user_search_entry = Gtk.SearchEntry()
        self.user_search_entry.set_placeholder_text(_("Search Users..."))
        self.user_search_entry.connect("search-changed", self.on_user_search_changed)
        left_vbox.pack_start(self.user_search_entry, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        left_vbox.pack_start(scroll, True, True, 0)

        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.connect("row-selected", self.on_row_selected)
        scroll.add(self.listbox)

        # Right: Details Panel
        self.details_panel = UserDetailsPanel(self)
        self.users_paned.pack2(self.details_panel, resize=True, shrink=False)
        
        # Add User Button (Moved to bottom of list or keep in header? 
        # Header is global. Let's keep Add User in Header but only visible on Tab 1?
        # Or just put a button at bottom of list.
        # Let's keep it in header for now, maybe disable it on other tabs.
        
        self.add_btn = Gtk.Button()
        self.add_btn.add(Gtk.Image.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON))
        self.add_btn.set_tooltip_text(_("Add User"))
        self.add_btn.connect("clicked", self.on_add_clicked)
        self.header.pack_start(self.add_btn)

        self.notebook.append_page(self.users_paned, Gtk.Label(label=_("Users")))

        # Tab 2: Clone User
        self.clone_panel = CloneUserPanel(self)
        self.notebook.append_page(self.clone_panel, Gtk.Label(label=_("Clone User")))

        # Tab 3: Groups
        self.groups_panel = GroupManagementPanel(self)
        self.notebook.append_page(self.groups_panel, Gtk.Label(label=_("Groups")))

        # Tab 4: Root
        self.root_panel = RootPanel(self)
        self.notebook.append_page(self.root_panel, Gtk.Label(label=_("Root")))

        self.notebook.connect("switch-page", self.on_tab_changed)

        # Loading Spinner for Users
        self.users_spinner = Gtk.Spinner()
        self.users_spinner.start()
        self.users_paned.pack1(self.users_spinner, resize=False, shrink=False) # Temporary placeholder
        # Actually, we should put the spinner in the listbox or overlay it.
        # Let's use a Stack for the left side: ListBox vs Spinner
        
        # Re-doing the left side layout slightly to support spinner
        # We need to remove the listbox from scroll temporarily or use a stack
        
        # Let's just call refresh_users which will handle the spinner logic if we implement it there
        self.refresh_users()
    
    def on_row_selected(self, listbox, row):
        if row:
            self.details_panel.set_user(row.user_data)
        else:
            self.details_panel.set_user(None)

    def on_user_search_changed(self, search_entry):
        search_text = search_entry.get_text().lower()
        for row in self.listbox.get_children():
            user_data = row.user_data
            username = user_data['username'].lower()
            realname = user_data['gecos'].lower()
            if search_text in username or search_text in realname:
                row.show()
            else:
                row.hide()

    def on_tab_changed(self, notebook, page, page_num):
        # Disable Add User button if not on Users tab
        self.add_btn.set_sensitive(page_num == 0)
        
        if page_num == 1: # Clone
            self.clone_panel.refresh_sources()
        elif page_num == 2: # Groups
            self.groups_panel.refresh_groups(keep_selection=True)

    def refresh_users(self, keep_selection=False):
        selected_username = None
        if keep_selection:
            row = self.listbox.get_selected_row()
            if row:
                selected_username = row.user_data['username']

        # Show loading state if not keeping selection (initial load or explicit refresh)
        # If keeping selection, we might want to be less intrusive, but for now let's be consistent.
        # Actually, if we clear the list, we lose selection anyway until we reload.
        
        # Clear existing rows
        for child in self.listbox.get_children():
            self.listbox.remove(child)
            
        # Add a spinner row
        spinner_row = Gtk.ListBoxRow()
        spinner_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        spinner_box.set_halign(Gtk.Align.CENTER)
        spinner_box.set_margin_top(10)
        spinner_box.set_margin_bottom(10)
        spinner = Gtk.Spinner()
        spinner.start()
        spinner_box.pack_start(spinner, True, True, 0)
        spinner_box.pack_start(Gtk.Label(label=_("Loading users...")), False, False, 0)
        spinner_row.add(spinner_box)
        spinner_row.set_selectable(False)
        self.listbox.add(spinner_row)
        self.listbox.show_all()
        
        # Disable refresh button
        self.refresh_btn.set_sensitive(False)

        def target():
            users = backend.get_users()
            GLib.idle_add(on_done, users)

        def on_done(users):
            # Remove spinner
            for child in self.listbox.get_children():
                self.listbox.remove(child)
            
            for u in users:
                row = UserRow(u)
                self.listbox.add(row)
                if selected_username and u['username'] == selected_username:
                    self.listbox.select_row(row)

            self.listbox.show_all()
            self.refresh_btn.set_sensitive(True)
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def on_add_clicked(self, widget):
        dialog = AddUserDialog(self)
        while True:
            if dialog.run() != Gtk.ResponseType.OK:
                break
            
            valid, msg = dialog.validate()
            if not valid:
                self.show_error(msg)
                continue
            
            username, realname, password, is_admin = dialog.get_data()
            
            # Progress Dialog
            progress = ProgressDialog(self, _("Creating user..."))
            
            # We need a container for the result because we are in a loop
            result = {'success': False, 'msg': ''}
            
            def target():
                success, msg = backend.add_user(username, realname, password, is_admin=is_admin)
                result['success'] = success
                result['msg'] = msg
                GLib.idle_add(on_done)

            def on_done():
                progress.destroy()
                if result['success']:
                    self.refresh_users()
                    dialog.destroy()
                else:
                    self.show_error(result['msg'])
                    # Dialog stays open
                return False

            thread = threading.Thread(target=target)
            thread.daemon = True
            thread.start()
            
            progress.start_pulse()
            
            # We need to break the loop here because the async operation will handle the rest.
            # But if it fails, we want the dialog to stay open.
            # The problem is dialog.run() blocks.
            # If we break here, the dialog object still exists but run() has returned.
            # We can't easily go back to run().
            
            # Alternative: Don't use while True loop with run().
            # Connect to "response" signal or just handle it differently.
            # But AddUserDialog is modal.
            
            # Actually, if we use a thread, we can't block the main loop with dialog.run() inside the thread.
            # The pattern here was: run -> validate -> add -> if success break else continue.
            
            # To support async add while keeping dialog open on failure:
            # 1. Hide the AddUserDialog (or make it insensitive)
            # 2. Show ProgressDialog
            # 3. Run thread
            # 4. On success: destroy AddUserDialog, refresh users.
            # 5. On failure: show error, re-show/sensitive AddUserDialog.
            
            # But we are already inside `if dialog.run() ...`.
            # So we have to return from this function to let the main loop run the progress dialog.
            # But if we return, we lose the loop context.
            
            # So we must NOT use `while True` loop with `dialog.run()`.
            # Instead, we should handle the OK button click in the dialog itself or use a different pattern.
            
            # Let's change the pattern:
            # We will break the loop. If failure, we just have to re-run the dialog? No that resets fields.
            # We need to keep the dialog instance.
            
            # Let's just return. The `on_done` will handle the logic.
            # But `dialog.run()` returns when a button is clicked.
            # If we want to keep it open, we shouldn't destroy it.
            # But `run()` creates a nested main loop.
            
            # Correct approach for async with modal dialog:
            # 1. User clicks OK. `run()` returns.
            # 2. We check validation.
            # 3. We show ProgressDialog (modal).
            # 4. We start thread.
            # 5. We return from `on_add_clicked`.
            # 6. `on_done` callback checks result.
            #    - Success: destroy `dialog`.
            #    - Failure: show error. Then what? The `dialog` is still there (we didn't destroy it).
            #      But `run()` has finished. We need to call `run()` again to wait for next input?
            #      Yes, we can call `dialog.run()` again.
            
            # So the loop structure is actually fine, IF we can wait for the thread.
            # But we can't wait for the thread in the main thread (that freezes UI).
            
            # So we CANNOT use the loop structure with async.
            
            # We have to refactor `on_add_clicked` to NOT use a blocking loop.
            # Or we can make `AddUserDialog` handle the async logic internally?
            # No, `MainWindow` handles the backend calls usually.
            
            # Let's try the "recursive run" approach or just manual handling.
            
            # Refactored approach:
            # We won't use the loop. We will handle the response manually.
            return # We will replace the whole method content.
            
    # New implementation of on_add_clicked
    def on_add_clicked(self, widget):
        dialog = AddUserDialog(self)
        
        def on_response(dialog, response_id):
            if response_id != Gtk.ResponseType.OK:
                dialog.destroy()
                return

            valid, msg = dialog.validate()
            if not valid:
                self.show_error(msg)
                # We need to stop the dialog from closing.
                # Since we are using run(), it returns.
                # If we use `g_signal_connect` for response, `run()` is not used?
                # No, `run()` is convenient.
                pass 
                
        # The issue is `run()` blocks until response.
        # If we want async, we can't use `run()` easily if we want to keep the dialog open.
        # Unless we just re-run it.
        
        # Let's stick to the re-run pattern but with async.
        # It's complicated.
        
        # Simpler approach:
        # Just use the existing loop but make the backend call synchronous? 
        # No, that's what we want to avoid.
        
        # Okay, let's look at how `RenameUserDialog` did it.
        # It used `dialog.run()`, then `progress = ProgressDialog(...)`, then `thread`.
        # And `dialog.destroy()` at the end.
        # But `RenameUserDialog` closes immediately after clicking OK. It doesn't wait for success/failure to decide whether to close.
        # If it fails, it shows error, but the dialog is already gone.
        # For `AddUserDialog`, if it fails (e.g. user exists), we probably want to keep the dialog open so user can fix it.
        
        # If we are okay with closing the dialog on failure (and user has to type again), then it's easy.
        # But that's bad UX.
        
        # So, we need to keep the dialog open.
        # We can use `dialog.show()` instead of `run()`, and handle signals.
        
        dialog.connect("response", self.on_add_user_response)
        dialog.show()
        
    def on_add_user_response(self, dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return

        valid, msg = dialog.validate()
        if not valid:
            self.show_error(msg)
            # Stop propagation so dialog doesn't close?
            # With `response` signal, the dialog doesn't automatically close/destroy unless we do it.
            # But `run()` would return. We are not using `run()`.
            return

        username, realname, password, is_admin = dialog.get_data()
        
        # Disable dialog while working
        dialog.set_sensitive(False)
        
        progress = ProgressDialog(dialog, _("Creating user..."))
        
        def target():
            success, msg = backend.add_user(username, realname, password, is_admin=is_admin)
            GLib.idle_add(on_done, success, msg)

        def on_done(success, msg):
            progress.destroy()
            dialog.set_sensitive(True)
            
            if success:
                self.refresh_users()
                dialog.destroy()
            else:
                self.show_error(msg)
                # Dialog stays open and sensitive
            return False

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        
        progress.start_pulse()
        
    # This requires adding `on_add_user_response` to the class.
    # And replacing `on_add_clicked`.


    def on_delete_clicked(self, widget):
        # Deprecated: Handled in UserDetailsPanel
        pass

    def on_refresh_clicked(self, widget):
        self.refresh_users()
        # Also refresh other tabs if active?
        self.clone_panel.refresh_sources()
        self.groups_panel.refresh_groups()

    def on_language_selected(self, widget, lang_code):
        if not widget.get_active():
            return

        current = config.get_language()
        if current == lang_code:
            return
            
        config.set_language(lang_code)
        
        # Update locale
        config.setup_locale()
        
        # Refresh UI
        self.retranslate_ui()

    def on_properties_clicked(self, widget):
        # Deprecated
        pass

    def on_about_clicked(self, widget):
        dialog = AboutDialog(self)
        dialog.run()
        dialog.destroy()

    def retranslate_ui(self):
        self.set_title(_("Luk-Os User Management"))
        self.header.set_title(_("Luk-Os User Management"))
        self.refresh_btn.set_tooltip_text(_("Refresh"))
        self.lang_btn.set_tooltip_text(_("Change Language"))
        self.about_btn.set_tooltip_text(_("About"))
        self.add_btn.set_tooltip_text(_("Add User"))
        
        # Update search entry placeholder
        self.user_search_entry.set_placeholder_text(_("Search Users..."))
        
        # Update Notebook Tabs
        self.notebook.set_tab_label_text(self.users_paned, _("Users"))
        self.notebook.set_tab_label_text(self.clone_panel, _("Clone User"))
        self.notebook.set_tab_label_text(self.groups_panel, _("Groups"))
        self.notebook.set_tab_label_text(self.root_panel, _("Root"))
        
        # Update Panels
        self.details_panel.retranslate_ui()
        self.clone_panel.retranslate_ui()
        self.groups_panel.retranslate_ui()
        self.root_panel.retranslate_ui()
        
        # Refresh lists to update content if needed (e.g. badges)
        self.refresh_users(keep_selection=True)

    def show_error(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def show_confirmation(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=message
        )
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.YES

    def show_confirmation_dialog(self, message, callback):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=message
        )
        
        def on_response(dlg, response_id):
            dlg.destroy()
            callback(response_id == Gtk.ResponseType.YES)
            
        dialog.connect("response", on_response)
        dialog.show()

    def on_delete_event(self, widget, event):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=Gtk.DialogFlags.MODAL,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Are you sure you want to quit?")
        )
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            Gtk.main_quit()
            return False  # Let the window close
        else:
            return True  # Prevent the window from closing
