import re
import os

def extract_strings(filename):
    with open(filename, 'r') as f:
        content = f.read()
    
    # Regex to find _("string") or _('string')
    # This is a simple regex and might miss some complex cases or catch false positives
    matches = re.findall(r'_\(["\'](.*?)["\']\)', content)
    return set(matches)

def extract_po_msgids(filename):
    msgids = set()
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    current_msgid = None
    for line in lines:
        line = line.strip()
        if line.startswith('msgid "'):
            current_msgid = line[7:-1]
            if current_msgid: # Skip empty msgid (header)
                msgids.add(current_msgid)
        elif line.startswith('"') and current_msgid is not None:
            # Continuation of msgid
            # This is a simplification, assumes msgid is always followed by msgstr
            pass 
            
    return msgids

def main():
    files_to_check = ['ui.py', 'backend.py', 'main.py']
    po_file = 'locale/es/LC_MESSAGES/luk-os-users.po'
    
    code_strings = set()
    for f in files_to_check:
        if os.path.exists(f):
            code_strings.update(extract_strings(f))
            
    po_strings = extract_po_msgids(po_file)
    
    missing = code_strings - po_strings
    
    print("Missing translations:")
    for s in sorted(missing):
        print(f'- "{s}"')

if __name__ == "__main__":
    main()
