import sys
import os

# Add current directory to path
sys.path.append(os.getcwd())

try:
    import backend
    print("Backend imported successfully")
    
    # Test get_shadow_hash (requires root)
    if os.geteuid() == 0:
        user = "root" # Assuming root exists
        hash_val = backend.get_shadow_hash(user)
        print(f"Shadow hash for {user}: {'Found' if hash_val else 'Not Found'}")
        
        # Test verify_password (we can't easily test true success without knowing a password, 
        # but we can test that it doesn't crash and returns False for bad password)
        success, msg = backend.verify_password(user, "wrongpassword123")
        print(f"Verify result: {success}, Message: {msg}")
        
        if not success and msg == "La contraseña actual es incorrecta":
             print("SUCCESS: Specific error message returned")
        elif not success and msg == "The current password is incorrect":
             print("SUCCESS: Specific error message returned (English)")
        else:
             print("FAILURE: Unexpected message or result")

    else:
        print("Not running as root, cannot test shadow reading fully.")
        # Test crypt function at least
        salt = "$6$rounds=656000$somesalt"
        hashed = backend.crypt("password", salt)
        print(f"Crypt test: {'Success' if hashed else 'Failure'}")

except Exception as e:
    print(f"Test failed with error: {e}")
