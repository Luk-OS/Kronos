import subprocess
import os
import pwd
import sys

def demote(user_uid, user_gid):
    def result():
        os.setgid(user_gid)
        os.setuid(user_uid)
    return result

def launch_mugshot(username):
    try:
        pw = pwd.getpwnam(username)
        uid = pw.pw_uid
        gid = pw.pw_gid
        home = pw.pw_dir
        
        env = os.environ.copy()
        env['HOME'] = home
        env['USER'] = username
        env['LOGNAME'] = username
        
        print(f"Launching mugshot for {username} (UID={uid}, GID={gid})...")
        
        p = subprocess.Popen(
            ['mugshot'], 
            preexec_fn=demote(uid, gid),
            env=env
        )
        p.wait()
        print("Mugshot exited.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        user = sys.argv[1]
    else:
        # Try to guess current desktop user
        user = os.environ.get('PKEXEC_UID')
        if user:
            user = pwd.getpwuid(int(user)).pw_name
        else:
            user = os.environ.get('SUDO_USER') or os.getlogin()
            
    launch_mugshot(user)
