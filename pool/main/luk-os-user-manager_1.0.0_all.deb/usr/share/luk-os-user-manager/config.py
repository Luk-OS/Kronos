import os
import json

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", "luk-os-users")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

# Capture original environment variables
ORIGINAL_LANG = os.environ.get('LANG')
ORIGINAL_LANGUAGE = os.environ.get('LANGUAGE')

DEFAULT_CONFIG = {
    "language": "system"
}

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return DEFAULT_CONFIG.copy()
    
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return DEFAULT_CONFIG.copy()

def save_config(config):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR, exist_ok=True)
    
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except OSError:
        return False

def get_language():
    config = load_config()
    return config.get("language", "system")

def set_language(lang_code):
    config = load_config()
    config["language"] = lang_code
    save_config(config)

def setup_locale():
    import gettext
    import locale
    
    LOCALE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'locale')
    lang = get_language()
    
    if lang != "system":
        # User has manually selected a language
        os.environ['LANGUAGE'] = lang
        os.environ['LANG'] = f'{lang}.UTF-8'
        try:
            locale.setlocale(locale.LC_ALL, f'{lang}.UTF-8')
        except locale.Error:
            try:
                locale.setlocale(locale.LC_ALL, lang)
            except locale.Error:
                pass
    else:
        # Use system locale - restore original environment variables
        if ORIGINAL_LANGUAGE is None:
            if 'LANGUAGE' in os.environ:
                del os.environ['LANGUAGE']
        else:
            os.environ['LANGUAGE'] = ORIGINAL_LANGUAGE

        if ORIGINAL_LANG is None:
            if 'LANG' in os.environ:
                del os.environ['LANG']
        else:
            os.environ['LANG'] = ORIGINAL_LANG
        
        try:
            # Reset to system default locale
            locale.setlocale(locale.LC_ALL, '')
        except locale.Error:
            pass
        
        # Detect system language using multiple methods
        detected_lang = None
        
        # Method 1: Try getdefaultlocale() first
        try:
            default_locale = locale.getdefaultlocale()
            if default_locale and default_locale[0]:
                detected_lang = default_locale[0].split('_')[0]
        except (ValueError, AttributeError):
            pass
        
        # Method 2: Try environment variables
        if not detected_lang:
            for env_var in ['LC_ALL', 'LC_MESSAGES', 'LANG']:
                if env_var in os.environ:
                    env_locale = os.environ[env_var]
                    if env_locale and env_locale != 'C' and env_locale != 'POSIX':
                        detected_lang = env_locale.split('_')[0].split('.')[0]
                        break
        
        # Method 3: Try getlocale()
        if not detected_lang:
            try:
                current_locale = locale.getlocale(locale.LC_MESSAGES)
                if current_locale and current_locale[0]:
                    detected_lang = current_locale[0].split('_')[0]
            except (ValueError, AttributeError):
                pass
        
        # Set LANGUAGE for gettext if we detected a language
        if detected_lang:
            os.environ['LANGUAGE'] = detected_lang

    # Force reload of translation
    languages = []
    if 'LANGUAGE' in os.environ:
        languages = os.environ['LANGUAGE'].split(':')
        
    print(f"DEBUG: Loading translation for languages: {languages} from {LOCALE_DIR}")
    try:
        t = gettext.translation('luk-os-users', LOCALE_DIR, languages=languages)
        t.install()
        print("DEBUG: Translation installed successfully")
    except FileNotFoundError:
        print("DEBUG: Translation file not found, falling back")
        gettext.install('luk-os-users', LOCALE_DIR)


