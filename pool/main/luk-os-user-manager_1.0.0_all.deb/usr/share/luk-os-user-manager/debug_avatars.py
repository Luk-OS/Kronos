import backend
import os

print("Checking user icons...")
users = backend.get_users()
for u in users:
    username = u['username']
    icon = backend.get_user_icon(username)
    print(f"User: {username}")
    print(f"  Icon path: {icon}")
    if icon:
        print(f"  Exists: {os.path.exists(icon)}")
        print(f"  Access: {os.access(icon, os.R_OK)}")
    
    # Check potential locations manually
    acc_icon = os.path.join('/var/lib/AccountsService/icons', username)
    print(f"  /var/lib/AccountsService/icons/{username}: {os.path.exists(acc_icon)}")
    
    home_face = os.path.join(u['home'], '.face')
    print(f"  {home_face}: {os.path.exists(home_face)}")
