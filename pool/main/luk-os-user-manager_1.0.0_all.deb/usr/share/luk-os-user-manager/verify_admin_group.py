import sys
import os

# Add current directory to path so we can import backend
sys.path.append(os.getcwd())

import backend
import grp
import subprocess

def test_admin_group_priority():
    print("Testing admin group priority...")
    
    # Check what groups exist on the system
    all_groups = [g.gr_name for g in grp.getgrall()]
    print(f"Available groups: {all_groups}")
    
    has_sudo = 'sudo' in all_groups
    has_wheel = 'wheel' in all_groups
    
    print(f"Has 'sudo': {has_sudo}")
    print(f"Has 'wheel': {has_wheel}")
    
    primary_admin = backend.get_primary_admin_group()
    print(f"backend.get_primary_admin_group() returned: '{primary_admin}'")
    
    if has_sudo:
        if primary_admin == 'sudo':
            print("SUCCESS: 'sudo' exists and was selected.")
        else:
            print(f"FAILURE: 'sudo' exists but '{primary_admin}' was selected.")
    elif has_wheel:
        if primary_admin == 'wheel':
            print("SUCCESS: 'sudo' does not exist, 'wheel' exists and was selected.")
        else:
            print(f"FAILURE: 'sudo' does not exist, 'wheel' exists but '{primary_admin}' was selected.")
    else:
        # Neither exists, backend should try to create wheel or return wheel
        if primary_admin == 'wheel':
             print("SUCCESS: Neither exists, defaulted to 'wheel'.")
        else:
             print(f"FAILURE: Neither exists, but returned '{primary_admin}'.")

if __name__ == "__main__":
    try:
        test_admin_group_priority()
    except Exception as e:
        print(f"An error occurred: {e}")
