import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf
import ui
import os

def test_circular_pixbuf():
    # Create a dummy pixbuf
    pixbuf = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True, 8, 100, 100)
    pixbuf.fill(0xFF0000FF) # Red
    
    try:
        round_pixbuf = ui.get_circular_pixbuf(pixbuf)
        print("Successfully created circular pixbuf")
        print(f"Original size: {pixbuf.get_width()}x{pixbuf.get_height()}")
        print(f"New size: {round_pixbuf.get_width()}x{round_pixbuf.get_height()}")
        
        # Check if it's not None
        if round_pixbuf:
            print("Result is not None")
        else:
            print("Result is None")
            
    except Exception as e:
        print(f"Failed to create circular pixbuf: {e}")

if __name__ == "__main__":
    test_circular_pixbuf()
