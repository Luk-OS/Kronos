
import gettext
import os

LOCALE_DIR = os.path.join(os.getcwd(), 'locale')
os.environ['LANGUAGE'] = 'es'
gettext.bindtextdomain('luk-os-users', LOCALE_DIR)
gettext.textdomain('luk-os-users')
_ = gettext.gettext

print(f"User created successfully -> {_('User created successfully')}")
print(f"User not found -> {_('User not found')}")
