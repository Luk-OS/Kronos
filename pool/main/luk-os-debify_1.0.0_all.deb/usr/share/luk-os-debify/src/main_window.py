import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GdkPixbuf, Gdk

import os
import shutil
import subprocess
import tempfile
import re
import json
from textwrap import dedent
import gettext
import locale
from datetime import datetime
import threading
import requests
import zipfile

from settings_dialog import SettingsDialog
from translation_dialog import TranslationDialog
from about_dialog import AboutDialog
from utils import crear_label_titulo, mostrar_error, mostrar_info

# --- Configuración de Traducción ---
APP_NAME = "empaquetador_deb"
LOCALE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'locales')

# Función para inicializar o cambiar el idioma
def init_language(lang=None):
    global _
    try:
        config_dir_temp = os.path.join(os.path.expanduser("~"), ".config", "EmpaquetadorDeb")
        config_file_temp = os.path.join(config_dir_temp, "config.json")
        
        if lang is None and os.path.exists(config_file_temp):
            with open(config_file_temp, 'r') as f:
                config_data_temp = json.load(f)
                lang = config_data_temp.get("language")

        # Si no se encontró en la configuración, intentar detectar el idioma del sistema
        if lang is None or lang == "system":
            system_locale = locale.getdefaultlocale()[0] # Ej: 'es_CO', 'en_US'
            if system_locale:
                lang = system_locale.split('_')[0] # Obtener solo el código de idioma, ej: 'es', 'en'
                print(f"Idioma del sistema detectado: {lang}")
            else:
                lang = 'en' # Fallback a inglés si no se puede detectar el sistema

        if lang:
            try:
                print(f"Intentando cargar idioma: {lang}")
                language = gettext.translation(APP_NAME, localedir=LOCALE_DIR, languages=[lang])
                language.install()
                _ = language.gettext
            except (FileNotFoundError, OSError): # OSError can also be raised by gettext.translation
                print(f"Traducción para '{lang}' no encontrada o inválida. Intentando con 'en'.")
                # Fallback a inglés si el idioma del sistema no está disponible
                try:
                    en_translation = gettext.translation(APP_NAME, localedir=LOCALE_DIR, languages=['en'])
                    en_translation.install()
                    _ = en_translation.gettext
                except (FileNotFoundError, OSError):
                    print("Traducción para 'en' tampoco encontrada. Usando texto original.")
                    _ = gettext.gettext # Usar texto original si no hay traducciones
            except Exception as e:
                print(f"Error inesperado al cargar traducción para '{lang}': {e}. Usando inglés por defecto.")
                try:
                    en_translation = gettext.translation(APP_NAME, localedir=LOCALE_DIR, languages=['en'])
                    en_translation.install()
                    _ = en_translation.gettext
                except (FileNotFoundError, OSError):
                    print("Traducción para 'en' tampoco encontrada. Usando texto original.")
                    _ = gettext.gettext # Usar texto original si no hay traducciones
        else:
            # Este bloque 'else' se ejecutará si 'lang' es None después de todos los intentos de detección.
            # Esto significa que ni la configuración del usuario ni el idioma del sistema pudieron ser determinados.
            print("No se pudo determinar el idioma, usando inglés por defecto.")
            try:
                en_translation = gettext.translation(APP_NAME, localedir=LOCALE_DIR, languages=['en'])
                en_translation.install()
                _ = en_translation.gettext
            except (FileNotFoundError, OSError):
                print("Traducción para 'en' tampoco encontrada. Usando texto original.")
                _ = gettext.gettext # Usar texto original si no hay traducciones

    except FileNotFoundError:
        print(f"Directorio de locales no encontrado en {LOCALE_DIR}. Usando texto por defecto.")
        _ = gettext.gettext # Usar texto original si no hay traducciones
    except Exception as e:
        print(f"Error al cargar gettext: {e}")
        _ = gettext.gettext

# Inicializar el idioma al inicio de la aplicación
init_language()

class EmpaquetadorApp(Gtk.Window):

    def __init__(self):
        # Asegurarse de que self._ esté disponible desde el principio
        global _
        self._ = _ 
        super().__init__(title="") # Se elimina el texto del título de la ventana
        self.set_position(Gtk.WindowPosition.CENTER) # Centrar la ventana en la pantalla

        # --- Establecer Icono por Defecto ---
        try:
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'logo.png')
            if os.path.exists(icon_path):
                Gtk.Window.set_default_icon_from_file(icon_path)
        except Exception as e:
            print(f"No se pudo establecer el icono por defecto: {e}")
            
        self.set_border_width(10)
        self.set_default_size(850, 600)
        self.set_resizable(True) # Allow resizing to enable maximize button
        
        # Conectar señal de cierre
        self.connect("delete-event", self.on_delete_event)

        # --- Cargar información de la app ---
        self.app_info = {}
        try:
            with open(os.path.join(os.path.dirname(__file__), 'app_info.json'), 'r') as f:
                self.app_info = json.load(f)
        except Exception as e:
            print(f"Error al cargar app_info.json: {e}")

        # --- Rutas de Configuración ---
        self.config_dir = os.path.join(os.path.expanduser("~"), ".config", "EmpaquetadorDeb")
        self.config_file = os.path.join(self.config_dir, "config.json")
        self.config_data = {}
        self.active_dialog = None # To keep track of open modal dialogs

        # --- Datos Internos ---
        self.traducciones_list = [] # Almacena tuplas (lang, name, comment)
        self.screenshots_list = [] # Almacena rutas a capturas de pantalla
        
        self.mapa_conversiones_py = {
            "beautifulsoup4": "python3-bs4",
            "pillow": "python3-pil",
            "pygobject": "python3-gi",
            "pycairo": "python3-cairo",
            "requests": "python3-requests",
            "numpy": "python3-numpy",
            "scipy": "python3-scipy",
            "pandas": "python3-pandas",
            "matplotlib": "python3-matplotlib",
            "sqlalchemy": "python3-sqlalchemy",
            "flask": "python3-flask",
            "django": "python3-django",
            "pyqt5": "python3-pyqt5",
            "lxml": "python3-lxml",
            "reportlab": "python3-reportlab",
            "pyserial": "python3-serial",
            "psycopg2": "python3-psycopg2",
            "yaml": "python3-yaml",
            "pyyaml": "python3-yaml",
        }
        self.mapa_conversiones_py_rpm = {
            "beautifulsoup4": "python3-beautifulsoup4",
            "pillow": "python3-pillow",
            "pygobject": "python3-gobject",
            "pycairo": "python3-cairo",
            "requests": "python3-requests",
            "numpy": "python3-numpy",
            "scipy": "python3-scipy",
            "pandas": "python3-pandas",
            "matplotlib": "python3-matplotlib",
            "sqlalchemy": "python3-sqlalchemy",
            "flask": "python3-flask",
            "django": "python3-django",
            "pyqt5": "python3-qt5",
            "lxml": "python3-lxml",
            "reportlab": "python3-reportlab",
            "pyserial": "python3-pyserial",
            "psycopg2": "python3-psycopg2",
            "yaml": "python3-pyyaml",
            "pyyaml": "python3-pyyaml",
        }

        # --- HeaderBar ---
        self.header_bar = Gtk.HeaderBar()
        self.header_bar.set_show_close_button(True)
        self.header_bar.set_decoration_layout(":minimize,maximize,close") # Standard controls
        self.header_bar.props.title = "" # Se elimina el texto del título de la barra de encabezado
        self.set_titlebar(self.header_bar)

        # --- CSS Provider ---
        self.css_provider = Gtk.CssProvider()
        css_path = os.path.join(os.path.dirname(__file__), 'style.css')
        try:
            self.css_provider.load_from_path(css_path)
        except Exception as e:
            print(f"Error loading CSS from {css_path}: {e}")
            # Fallback simple CSS if file fails
            self.css_provider.load_from_data(b"""
            .placeholder { color: gray; font-style: italic; }
            """)
            
        screen = Gdk.Screen.get_default()
        style_context = Gtk.StyleContext()
        style_context.add_provider_for_screen(screen, self.css_provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        # --- Botón de Configuración ---
        self.btn_settings = Gtk.Button.new_from_icon_name("preferences-system-symbolic", Gtk.IconSize.BUTTON)
        self.btn_settings.set_tooltip_text(_("Configuración"))
        self.btn_settings.connect("clicked", self.on_settings_clicked)
        self.header_bar.pack_start(self.btn_settings) # Al inicio

        # --- NUEVO: Botón "Acerca de" ---
        # Se reduce el tamaño del icono "Acerca de" a Gtk.IconSize.MENU
        self.btn_about = Gtk.Button.new_from_icon_name("help-about-symbolic", Gtk.IconSize.MENU)
        self.btn_about.set_tooltip_text(_("Acerca de..."))
        self.btn_about.connect("clicked", self.on_about_clicked)
        self.header_bar.pack_start(self.btn_about) # Al lado de configuración

        # --- Botón de Traducciones (Movido al formulario) ---
        # self.btn_translations = Gtk.Button.new_from_icon_name("document-edit-symbolic", Gtk.IconSize.MENU)
        # self.btn_translations.set_tooltip_text(_("Añadir Traducciones para .desktop"))
        # self.btn_translations.connect("clicked", self.on_add_translation_clicked)
        # self.header_bar.pack_start(self.btn_translations) # Al lado de "Acerca de"

        # --- Menú de Idioma ---
        # Remove existing language menu button if it exists
        if hasattr(self, 'lang_menu_button') and self.lang_menu_button.get_parent():
            self.header_bar.remove(self.lang_menu_button)
        
        # Re-create and pack the language menu button
        self.lang_menu_button = self.crear_menu_idioma()
        self.header_bar.pack_start(self.lang_menu_button)
        self.lang_menu_button.show_all() # Ensure the new button and its menu are shown

        # --- Menú de Plantillas ---
        self.btn_templates = Gtk.MenuButton()
        self.btn_templates.set_image(Gtk.Image.new_from_icon_name("document-save-symbolic", Gtk.IconSize.BUTTON))
        self.btn_templates.set_tooltip_text(self._("Plantillas"))
        
        templates_menu = Gtk.Menu()
        
        self.item_save = Gtk.MenuItem(label=self._("Guardar Plantilla"))
        self.item_save.connect("activate", self.on_save_template_clicked)
        templates_menu.append(self.item_save)
        
        self.item_load = Gtk.MenuItem(label=self._("Cargar Plantilla"))
        self.item_load.connect("activate", self.on_load_template_clicked)
        templates_menu.append(self.item_load)
        
        templates_menu.show_all()
        self.btn_templates.set_popup(templates_menu)
        self.header_bar.pack_start(self.btn_templates)

        # --- Botón Crear Paquete ---
        self.btn_paquete = Gtk.Button.new_with_label(_("Crear Paquete"))
        self.btn_paquete.get_style_context().add_class("suggested-action")
        self.btn_paquete.connect("clicked", self.on_package_clicked)
        self.header_bar.pack_end(self.btn_paquete)

        # --- Layout Principal (Horizontal) ---
        self.main_hpaned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        self.main_hpaned.set_position(200) # Ancho inicial del sidebar
        self.add(self.main_hpaned)

        # --- Sidebar y Stack ---
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_UP_DOWN)
        
        self.stack_sidebar = Gtk.StackSidebar()
        self.stack_sidebar.set_stack(self.stack)
        self.stack_sidebar.set_size_request(150, -1)
        
        # Contenedor para el Sidebar (para darle estilo/margen si es necesario)
        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sidebar_box.pack_start(self.stack_sidebar, True, True, 0)
        self.main_hpaned.pack1(sidebar_box, False, False)

        # Contenedor para el Contenido (Stack + Preview)
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.main_hpaned.pack2(content_box, True, False)
        
        # --- Stack (Centro) ---
        stack_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        stack_container.get_style_context().add_class("content-area")
        stack_container.pack_start(self.stack, True, True, 0)
        content_box.pack_start(stack_container, True, True, 0)

        # --- Pestaña 1: Formulario Principal ---
        form_scrolled_window = Gtk.ScrolledWindow()
        form_scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.grid = Gtk.Grid()
        self.grid.set_column_spacing(8) # Reducido espaciado
        self.grid.set_row_spacing(6)    # Reducido espaciado
        self.grid.set_margin_start(5)
        self.grid.set_margin_end(5)
        self.grid.set_margin_top(5)
        self.grid.set_margin_bottom(5)
        form_scrolled_window.add(self.grid)
        self.stack.add_titled(form_scrolled_window, "formulario", self._("Formulario"))

        # --- Pestaña 2: AppStream ---
        self.appstream_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.appstream_page.set_margin_start(5)
        self.appstream_page.set_margin_end(5)
        self.appstream_page.set_margin_top(5)
        self.appstream_page.set_margin_bottom(5)
        
        appstream_scroll = Gtk.ScrolledWindow()
        appstream_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        appstream_scroll.add(self.appstream_page)
        
        # self.stack.add_titled(appstream_scroll, "appstream", self._("AppStream"))

        # --- Pestaña 3: Traducciones ---
        self.translations_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.translations_page.set_margin_start(5)
        self.translations_page.set_margin_end(5)
        self.translations_page.set_margin_top(5)
        self.translations_page.set_margin_bottom(5)
        self.stack.add_titled(self.translations_page, "traducciones", self._("Traducciones"))
        
        # --- Panel Derecho: Vista Previa, Dependencias y Progreso ---
        right_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        right_vbox.set_size_request(250, -1)
        right_vbox.set_hexpand(False)

        self.preview_box = self.crear_preview()
        right_vbox.pack_start(self.preview_box, False, False, 0)

        self.label_deps = crear_label_titulo("Dependencias (una por línea):", self._)
        self.label_deps.set_margin_top(10)
        
        hbox_deps_label = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox_deps_label.pack_start(self.label_deps, False, False, 0)
        
        self.btn_scan_deps = Gtk.Button.new_from_icon_name("system-search-symbolic", Gtk.IconSize.MENU)
        self.btn_scan_deps.set_tooltip_text(self._("Escanear dependencias con Gemini"))
        self.btn_scan_deps.connect("clicked", self.on_scan_deps_gemini_clicked)
        hbox_deps_label.pack_end(self.btn_scan_deps, False, False, 0)
        
        right_vbox.pack_start(hbox_deps_label, False, False, 0)

        deps_scrolled_window = Gtk.ScrolledWindow()
        deps_scrolled_window.set_shadow_type(Gtk.ShadowType.NONE)
        deps_scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        deps_scrolled_window.set_vexpand(True)
        deps_scrolled_window.set_min_content_height(100)
        
        self.textview_deps = Gtk.TextView()
        self.textview_deps.set_wrap_mode(Gtk.WrapMode.WORD)
        self.buffer_deps = self.textview_deps.get_buffer()
        
        # --- CAMBIO: Lógica de placeholder para dependencias ---
        self.placeholder_deps = (
            self._("Dependencias del sistema, ej:\n") +
            "python3-gi\n" +
            "gstreamer1.0-plugins-good"
        )
        self.buffer_deps.set_text(self.placeholder_deps)
        self.textview_deps.get_style_context().add_class("placeholder")
        self.textview_deps.connect("focus-in-event", self.on_textview_focus_in, self.placeholder_deps)
        self.textview_deps.connect("focus-out-event", self.on_textview_focus_out, self.placeholder_deps)
        # --- FIN CAMBIO ---

        deps_scrolled_window.add(self.textview_deps)
        right_vbox.pack_start(deps_scrolled_window, True, True, 0)

        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(True)  # Mostrar el texto en la barra de progreso
        self.progress_bar.set_visible(False)
        self.progress_bar.set_margin_top(5)
        right_vbox.pack_start(self.progress_bar, False, False, 5)

        right_vbox.get_style_context().add_class("preview-panel")
        content_box.pack_start(right_vbox, False, True, 0)
        
        # --- Rellenar Formulario y Mostrar ---
        self.crear_formulario()
        self.load_config()
        self._refresh_translations_list() # Actualizar la lista de traducciones
        self.update_ui_for_language() # Actualizar textos después de crear widgets
        self.show_all()
        self.on_preview_update(None)

    # --- Lógica de Placeholder para Gtk.TextView ---
    def on_textview_focus_in(self, textview, event, placeholder_text):
        buffer = textview.get_buffer()
        if buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False) == placeholder_text:
            buffer.set_text("")
            textview.get_style_context().remove_class("placeholder")
        return False

    def on_textview_focus_out(self, textview, event, placeholder_text):
        buffer = textview.get_buffer()
        if buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False) == "":
            buffer.set_text(placeholder_text)
            textview.get_style_context().add_class("placeholder")
        return False
    
    def get_buffer_text_or_empty(self, buffer, placeholder_text):
        """Devuelve el texto del buffer, o "" si es el placeholder."""
        text = buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False)
        if text == placeholder_text:
            return ""
        return text

    # --- Fin Lógica Placeholder ---

    def _create_translation_row(self, translation_data):
        """Crea una fila para la ListBox de traducciones."""
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        hbox.set_margin_start(5)
        hbox.set_margin_end(5)
        hbox.set_margin_top(2)
        hbox.set_margin_bottom(2)

        # Obtener el nombre traducido del idioma
        # Obtener el nombre traducido del idioma
        lang_display_name_map = {
            "es": self._("Español"),
            "en": self._("English"),
            "fr": self._("Français"),
            "pt": self._("Português"),
            "it": self._("Italiano"),
        }
        lang_display_name = lang_display_name_map.get(translation_data['lang'], translation_data['lang'].upper())

        lang_label = Gtk.Label(label=f"<b>{lang_display_name}</b>", use_markup=True)
        lang_label.set_halign(Gtk.Align.START)
        lang_label.set_hexpand(False)
        hbox.pack_start(lang_label, False, False, 0)

        name_comment_label = Gtk.Label(label=f"{translation_data['name']} ({translation_data['comment']})")
        name_comment_label.set_halign(Gtk.Align.START)
        name_comment_label.set_hexpand(True)
        hbox.pack_start(name_comment_label, True, True, 0)

        row = Gtk.ListBoxRow()
        row.add(hbox)
        row.lang_code = translation_data['lang'] # Store the original language code
        return row

    def _refresh_translations_list(self):
        """Actualiza la ListBox de traducciones con los datos actuales."""
        # Limpiar la lista existente
        for row in self.listbox_traducciones.get_children():
            self.listbox_traducciones.remove(row)

        # Añadir las traducciones actuales
        if not self.traducciones_list:
            empty_label = Gtk.Label(label=self._("No hay traducciones añadidas."))
            empty_label.set_margin_top(5)
            empty_label.set_margin_bottom(5)
            empty_row = Gtk.ListBoxRow() # Wrap the label in a ListBoxRow
            empty_row.add(empty_label)
            self.listbox_traducciones.add(empty_row)
            self.btn_remove_selected_translation.set_sensitive(False) # Deshabilitar si no hay elementos
        else:
            for trad_data in self.traducciones_list:
                row_widget = self._create_translation_row(trad_data)
                self.listbox_traducciones.add(row_widget)
        
        self.listbox_traducciones.show_all()

    def _on_translation_row_selected(self, listbox, row):
        """Habilita/deshabilita el botón de eliminar según la selección."""
        self.btn_remove_selected_translation.set_sensitive(row is not None)

    def _on_remove_selected_translation_clicked(self, widget):
        """Elimina la traducción seleccionada de la lista y refresca la UI."""
        selected_row = self.listbox_traducciones.get_selected_row()
        if selected_row:
            # Retrieve the original language code directly from the row's custom attribute
            lang_code_to_remove = selected_row.lang_code
            
            self.traducciones_list = [
                t for t in self.traducciones_list if t['lang'] != lang_code_to_remove
            ]
            self._refresh_translations_list()
            print(f"Traducción para '{lang_code_to_remove}' eliminada. Lista actual: {self.traducciones_list}")

    def crear_preview(self):
        """Crea el panel de vista previa."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)
        box.set_margin_start(5)
        box.set_margin_end(5)

        self.preview_label_titulo = Gtk.Label(label=self._("Vista Previa"))
        self.preview_label_titulo.get_style_context().add_class("title-3")
        box.pack_start(self.preview_label_titulo, False, False, 0)

        self.preview_image = Gtk.Image()
        self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
        self.preview_image.set_pixel_size(64) # Más compacto
        box.pack_start(self.preview_image, False, False, 5)

        self.preview_label_name = Gtk.Label(label=self._("Nombre App"))
        self.preview_label_name.get_style_context().add_class("title-4")
        self.preview_label_name.set_selectable(True)
        box.pack_start(self.preview_label_name, False, False, 0)

        self.preview_label_comment = Gtk.Label(label=self._("Descripción corta..."))
        self.preview_label_comment.set_selectable(True)
        self.preview_label_comment.set_max_width_chars(30)
        self.preview_label_comment.set_line_wrap(True)
        box.pack_start(self.preview_label_comment, False, False, 0)

        return box

    def crear_formulario(self):
        """Crea todos los widgets del formulario."""
        
        y = 0 # Contador de fila

        # --- 1. Directorio del Proyecto ---
        self.label_proyecto = crear_label_titulo("Directorio del Proyecto:", self._)
        self.grid.attach(self.label_proyecto, 0, y, 4, 1) # Ocupa 4 columnas
        y += 1
        
        # Se reemplaza Gtk.FileChooserButton por un Gtk.Button y se implementa la lógica para abrir Thunar
        self.entry_proyecto_path = Gtk.Entry()
        self.entry_proyecto_path.set_placeholder_text(self._("Selecciona el directorio de tu proyecto"))
        self.entry_proyecto_path.set_hexpand(True)
        self.entry_proyecto_path.set_editable(False) # No permitir edición manual

        self.btn_select_proyecto = Gtk.Button.new_from_icon_name("folder-open-symbolic", Gtk.IconSize.BUTTON)
        self.btn_select_proyecto.set_tooltip_text(self._("Seleccionar Directorio del Proyecto"))
        self.btn_select_proyecto.connect("clicked", self.on_select_proyecto_clicked)

        hbox_proyecto = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        hbox_proyecto.pack_start(self.entry_proyecto_path, True, True, 0)
        hbox_proyecto.pack_start(self.btn_select_proyecto, False, False, 0)
        self.grid.attach(hbox_proyecto, 0, y, 4, 1)
        y += 1
        
        # --- 2. Archivo Principal ---
        self.label_principal = crear_label_titulo("Archivo Principal (Ejecutable):", self._)
        self.grid.attach(self.label_principal, 0, y, 2, 1) # Mitad

        # --- 3. Icono ---
        self.label_icono = crear_label_titulo("Icono de la Aplicación:", self._)
        self.grid.attach(self.label_icono, 2, y, 2, 1) # Mitad
        y += 1

        self.combo_main_file = Gtk.ComboBoxText()
        self.combo_main_file.set_entry_text_column(0)
        self.combo_main_file.connect("changed", self.on_main_file_changed)
        self.grid.attach(self.combo_main_file, 0, y, 2, 1)
        
        self.chooser_icono = Gtk.FileChooserButton(
            title=self._("Selecciona un archivo de icono (.png o .svg)"),
            action=Gtk.FileChooserAction.OPEN
        )
        filter_img = Gtk.FileFilter()
        filter_img.set_name(self._("Imágenes"))
        filter_img.add_mime_type("image/png")
        filter_img.add_mime_type("image/svg+xml")
        self.chooser_icono.add_filter(filter_img)
        self.chooser_icono.connect("file-set", self.on_preview_update)
        self.grid.attach(self.chooser_icono, 2, y, 2, 1)
        y += 1

        self.grid.attach(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), 0, y, 4, 1)
        y += 1

        # --- 4. Nombre Paquete y Versión (Lado a lado) ---
        self.label_pkg_name = crear_label_titulo("Nombre del Paquete (ID):", self._)
        self.grid.attach(self.label_pkg_name, 0, y, 2, 1)
        
        self.label_version = crear_label_titulo("Versión:", self._)
        self.grid.attach(self.label_version, 2, y, 2, 1)
        y += 1
        
        self.entry_pkg_name = Gtk.Entry()
        self.entry_pkg_name.set_placeholder_text(self._("solo-minusculas-y-guiones"))
        self.grid.attach(self.entry_pkg_name, 0, y, 2, 1)
        
        self.entry_version = Gtk.Entry()
        self.entry_version.set_placeholder_text(self._("1.0.0"))
        self.grid.attach(self.entry_version, 2, y, 2, 1)
        y += 1

        # --- Arquitectura ---
        self.label_architecture = crear_label_titulo(self._("Arquitectura:"), self._)
        self.grid.attach(self.label_architecture, 0, y, 4, 1)
        y += 1

        self.combo_architecture = Gtk.ComboBoxText()
        for arch in ["all", "amd64", "i386", "arm64", "armhf"]:
            self.combo_architecture.append(arch, arch)
        self.combo_architecture.set_active_id("all") # Default to 'all'
        self.grid.attach(self.combo_architecture, 0, y, 4, 1)
        y += 1

        # --- AppStream Metadata ---
        # self.check_appstream = Gtk.CheckButton(label=self._("Añadir metadatos de AppStream (para tiendas de software)"))
        # self.check_appstream.set_active(True) # Habilitar por defecto
        # self.check_appstream.connect("toggled", self.on_appstream_toggled)
        # self.grid.attach(self.check_appstream, 0, y, 4, 1)
        # y += 1

        # --- 5. Categoría Unificada (NUEVO) ---
        self.label_categoria_unificada = crear_label_titulo("Categoría Principal:", self._)
        self.grid.attach(self.label_categoria_unificada, 0, y, 4, 1)
        y += 1
        
        # (Display Name, Section Value, Category Value)
        self.unified_categories_map = [
            (self._("Utilidad (General)"), "utils", "Utility;Application;"),
            (self._("Juego"), "games", "Game;"),
            (self._("Desarrollo"), "devel", "Development;"),
            (self._("Gráficos"), "graphics", "Graphics;"),
            (self._("Oficina"), "office", "Office;"),
            (self._("Red"), "net", "Network;"),
            (self._("Audio/Video"), "sound", "AudioVideo;Audio;Video;"),
            (self._("Ciencia"), "science", "Science;"),
            (self._("Sistema / Configuración"), "admin", "System;Settings;"),
            (self._("Educación"), "education", "Education;"),
            (self._("Web"), "web", "WebBrowser;"), # Ejemplo
        ]
        
        self.unified_category_store = Gtk.ListStore(str, str, str)
        for disp, sect, cat in self.unified_categories_map:
            self.unified_category_store.append([disp, sect, cat])

        self.combo_categoria_unificada = Gtk.ComboBox.new_with_model(self.unified_category_store)
        renderer_text = Gtk.CellRendererText()
        self.combo_categoria_unificada.pack_start(renderer_text, True)
        self.combo_categoria_unificada.add_attribute(renderer_text, "text", 0) # Columna 0 (Display)
        self.combo_categoria_unificada.set_active(0) # Default a "Utilidad (General)"
        
        self.grid.attach(self.combo_categoria_unificada, 0, y, 4, 1)
        y += 1

        # --- Checkbox: Mostrar en Configuración del Sistema ---
        self.check_system_settings = Gtk.CheckButton(label=self._("Mostrar en Configuración del Sistema (XFCE, GNOME, etc.)"))
        self.check_system_settings.set_active(False)
        self.grid.attach(self.check_system_settings, 0, y, 4, 1)
        y += 1

        # --- Argumentos Exec (NUEVO) ---
        # --- Argumentos Exec (NUEVO) ---
        self.label_exec_args = crear_label_titulo(self._("Argumentos de Ejecución (Opcional):"), self._)
        self.grid.attach(self.label_exec_args, 0, y, 4, 1)
        y += 1
        
        self.entry_exec_args = Gtk.Entry()
        self.entry_exec_args.set_placeholder_text(self._("--window --settings (ejemplo)"))
        self.grid.attach(self.entry_exec_args, 0, y, 4, 1)
        y += 1
        
        # --- 6. Mantenedor (Lado a lado) ---
        self.label_maintainer_name = crear_label_titulo("Nombre del Mantenedor:", self._)
        self.grid.attach(self.label_maintainer_name, 0, y, 2, 1)
        
        self.label_maintainer_email = crear_label_titulo("Correo del Mantenedor:", self._)
        self.grid.attach(self.label_maintainer_email, 2, y, 2, 1)
        y += 1

        self.entry_maintainer_name = Gtk.Entry()
        self.grid.attach(self.entry_maintainer_name, 0, y, 2, 1)
        
        self.entry_maintainer_email = Gtk.Entry()
        self.grid.attach(self.entry_maintainer_email, 2, y, 2, 1)
        y += 1

        self.grid.attach(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), 0, y, 4, 1)
        y += 1

        # --- 7. Nombre y Descripción (Vertical) ---
        self.label_display_name = crear_label_titulo("Nombre (para el Menú):", self._)
        self.grid.attach(self.label_display_name, 0, y, 4, 1)
        y += 1
        
        self.entry_display_name = Gtk.Entry()
        self.entry_display_name.set_placeholder_text(self._("Mi Aplicación"))
        self.entry_display_name.connect("changed", self.on_preview_update)
        self.grid.attach(self.entry_display_name, 0, y, 4, 1)
        y += 1

        self.label_desc_corta = crear_label_titulo("Descripción Corta:", self._)
        self.grid.attach(self.label_desc_corta, 0, y, 4, 1)
        y += 1

        scrolled_window_corta = Gtk.ScrolledWindow()
        scrolled_window_corta.set_shadow_type(Gtk.ShadowType.NONE)
        scrolled_window_corta.set_hexpand(True)
        scrolled_window_corta.set_vexpand(False) # No expandir verticalmente
        scrolled_window_corta.set_min_content_height(38) # Altura similar a un Gtk.Entry
        self.grid.attach(scrolled_window_corta, 0, y, 4, 1)

        self.textview_desc_corta = Gtk.TextView()
        self.textview_desc_corta.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.placeholder_desc_corta = self._("Un resumen corto")
        self.buffer_desc_corta = self.textview_desc_corta.get_buffer()
        self.buffer_desc_corta.set_text(self.placeholder_desc_corta)
        self.textview_desc_corta.get_style_context().add_class("placeholder")
        self.textview_desc_corta.get_style_context().add_class("entry")
        self.textview_desc_corta.connect("focus-in-event", self.on_textview_focus_in, self.placeholder_desc_corta)
        self.textview_desc_corta.connect("focus-out-event", self.on_textview_focus_out, self.placeholder_desc_corta)
        self.buffer_desc_corta.connect("changed", self.on_preview_update) # Conectar al buffer
        scrolled_window_corta.add(self.textview_desc_corta)
        y += 1

        # --- 8. Descripción Larga ---
        self.label_desc_larga = crear_label_titulo("Descripción Larga (para el gestor de paquetes):", self._)
        self.label_desc_larga.set_margin_top(15) # Separación visual
        self.grid.attach(self.label_desc_larga, 0, y, 4, 1)
        y += 1

        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_shadow_type(Gtk.ShadowType.NONE)
        scrolled_window.set_hexpand(True)
        scrolled_window.set_vexpand(True)
        scrolled_window.set_min_content_height(80)
        self.grid.attach(scrolled_window, 0, y, 4, 1)

        self.textview_desc_larga = Gtk.TextView()
        self.textview_desc_larga.set_wrap_mode(Gtk.WrapMode.WORD)
        self.placeholder_desc_larga = (
            self._("Escribe una descripción más detallada aquí.\n") +
            self._("Puede tener múltiples líneas.")
        )
        self.buffer_desc_larga = self.textview_desc_larga.get_buffer()
        self.buffer_desc_larga.set_text(self.placeholder_desc_larga)
        self.textview_desc_larga.get_style_context().add_class("placeholder")
        self.textview_desc_larga.get_style_context().add_class("entry")
        self.textview_desc_larga.connect("focus-in-event", self.on_textview_focus_in, self.placeholder_desc_larga)
        self.textview_desc_larga.connect("focus-out-event", self.on_textview_focus_out, self.placeholder_desc_larga)
        scrolled_window.add(self.textview_desc_larga)
        y += 1

        # --- Contenido de la Pestaña Traducciones ---
        translations_widgets_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.translations_page.pack_start(translations_widgets_box, True, True, 0)

        hbox_traducciones_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        self.label_traducciones = crear_label_titulo(self._("Traducciones .Desktop (para .desktop):"), self._)
        hbox_traducciones_header.pack_start(self.label_traducciones, False, False, 0)

        self.btn_add_translation_form = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.MENU)
        self.btn_add_translation_form.set_tooltip_text(self._("Añadir nueva traducción"))
        self.btn_add_translation_form.connect("clicked", self.on_add_translation_clicked)
        hbox_traducciones_header.pack_end(self.btn_add_translation_form, False, False, 0)

        self.btn_remove_selected_translation = Gtk.Button.new_from_icon_name("list-remove-symbolic", Gtk.IconSize.MENU)
        self.btn_remove_selected_translation.set_tooltip_text(self._("Eliminar traducción seleccionada"))
        self.btn_remove_selected_translation.connect("clicked", self._on_remove_selected_translation_clicked)
        self.btn_remove_selected_translation.set_sensitive(False) # Deshabilitado por defecto
        hbox_traducciones_header.pack_end(self.btn_remove_selected_translation, False, False, 0)

        self.btn_batch_translate = Gtk.Button.new_from_icon_name("system-search-symbolic", Gtk.IconSize.MENU)
        self.btn_batch_translate.set_tooltip_text(self._("Traducir a múltiples idiomas con Gemini"))
        self.btn_batch_translate.connect("clicked", self.on_batch_translate_clicked)
        hbox_traducciones_header.pack_end(self.btn_batch_translate, False, False, 0)
        
        translations_widgets_box.pack_start(hbox_traducciones_header, False, False, 0)

        self.listbox_traducciones = Gtk.ListBox()
        self.listbox_traducciones.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox_traducciones.connect("row-selected", self._on_translation_row_selected)
        self.listbox_traducciones.set_vexpand(True)
        translations_widgets_box.pack_start(self.listbox_traducciones, True, True, 0)

        # --- Contenido de la Pestaña AppStream ---
        appstream_widgets_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.appstream_page.pack_start(appstream_widgets_box, True, True, 0)

        # AppStream Name and Summary for default language
        self.label_appstream_name_main = crear_label_titulo(self._("Nombre AppStream (idioma principal):"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_name_main, False, False, 0)
        self.entry_appstream_name_main = Gtk.Entry()
        self.entry_appstream_name_main.set_placeholder_text(self._("Mi App (AppStream)"))
        appstream_widgets_box.pack_start(self.entry_appstream_name_main, False, False, 0)

        self.label_appstream_comment_main = crear_label_titulo(self._("Resumen AppStream (idioma principal):"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_comment_main, False, False, 0)
        self.entry_appstream_comment_main = Gtk.Entry()
        self.entry_appstream_comment_main.set_placeholder_text(self._("Un resumen corto para AppStream"))
        appstream_widgets_box.pack_start(self.entry_appstream_comment_main, False, False, 0)

        # Developer Name
        self.label_appstream_developer_name = crear_label_titulo(self._("Nombre del Desarrollador (Creator):"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_developer_name, False, False, 0)
        self.entry_appstream_developer_name = Gtk.Entry()
        self.entry_appstream_developer_name.set_placeholder_text(self._("Nombre del Desarrollador o Equipo"))
        appstream_widgets_box.pack_start(self.entry_appstream_developer_name, False, False, 0)

        # Project License
        self.label_appstream_license = crear_label_titulo(self._("Licencia del Proyecto (SPDX):"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_license, False, False, 0)
        self.entry_appstream_license = Gtk.Entry()
        self.entry_appstream_license.set_placeholder_text("GPL-3.0-or-later")
        self.entry_appstream_license.set_text("GPL-3.0-or-later") # Default
        appstream_widgets_box.pack_start(self.entry_appstream_license, False, False, 0)

        # Homepage URL
        self.label_appstream_homepage = crear_label_titulo(self._("URL del Sitio Web:"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_homepage, False, False, 0)
        self.entry_appstream_homepage = Gtk.Entry()
        self.entry_appstream_homepage.set_placeholder_text("https://example.com")
        appstream_widgets_box.pack_start(self.entry_appstream_homepage, False, False, 0)

        # Bugtracker URL
        self.label_appstream_bugtracker = crear_label_titulo(self._("URL de Reporte de Errores:"), self._)
        appstream_widgets_box.pack_start(self.label_appstream_bugtracker, False, False, 0)
        self.entry_appstream_bugtracker = Gtk.Entry()
        self.entry_appstream_bugtracker.set_placeholder_text("https://example.com/issues")
        appstream_widgets_box.pack_start(self.entry_appstream_bugtracker, False, False, 0)

        appstream_widgets_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)

        hbox_screenshots_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        self.label_screenshots = crear_label_titulo(self._("Capturas de pantalla:"), self._)
        hbox_screenshots_header.pack_start(self.label_screenshots, False, False, 0)

        self.btn_add_screenshot = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.MENU)
        self.btn_add_screenshot.set_tooltip_text(self._("Añadir captura de pantalla"))
        self.btn_add_screenshot.connect("clicked", self.on_add_screenshot_clicked)
        hbox_screenshots_header.pack_end(self.btn_add_screenshot, False, False, 0)

        self.btn_remove_screenshot = Gtk.Button.new_from_icon_name("list-remove-symbolic", Gtk.IconSize.MENU)
        self.btn_remove_screenshot.set_tooltip_text(self._("Eliminar captura seleccionada"))
        self.btn_remove_screenshot.connect("clicked", self.on_remove_screenshot_clicked)
        self.btn_remove_screenshot.set_sensitive(False)
        hbox_screenshots_header.pack_end(self.btn_remove_screenshot, False, False, 0)
        appstream_widgets_box.pack_start(hbox_screenshots_header, False, False, 0)

        scrolled_window_screenshots = Gtk.ScrolledWindow()
        scrolled_window_screenshots.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled_window_screenshots.set_vexpand(True)
        
        self.flowbox_screenshots = Gtk.FlowBox()
        self.flowbox_screenshots.set_valign(Gtk.Align.START)
        self.flowbox_screenshots.set_max_children_per_line(4)
        self.flowbox_screenshots.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.flowbox_screenshots.connect("selected-children-changed", self.on_screenshot_selection_changed)
        
        scrolled_window_screenshots.add(self.flowbox_screenshots)
        appstream_widgets_box.pack_start(scrolled_window_screenshots, True, True, 0)

        # Ocultar la pestaña de AppStream inicialmente si es necesario
        # self.on_appstream_toggled(self.check_appstream)

    def on_appstream_toggled(self, widget):
        is_active = widget.get_active()
        # self.notebook.get_nth_page(1).set_visible(is_active)
        # En Gtk.Stack, ocultamos el hijo y también el título en el sidebar si es posible,
        # pero set_visible en el hijo debería funcionar para que el StackSwitcher (Sidebar) lo oculte/muestre.
        appstream_widget = self.stack.get_child_by_name("appstream")
        if appstream_widget:
            appstream_widget.set_visible(is_active)
        # También podrías querer deshabilitar los widgets dentro de la pestaña
        # self.appstream_page.set_sensitive(is_active)

    def on_screenshot_selection_changed(self, flowbox):
        """Habilita el botón de eliminar cuando cambia la selección."""
        selected_children = flowbox.get_selected_children()
        self.btn_remove_screenshot.set_sensitive(len(selected_children) > 0)

    # --- Callbacks de Configuración y Acerca de ---

    def on_settings_clicked(self, widget):
        """Muestra el diálogo de configuración."""
        dialog = SettingsDialog(
            self,
            self.config_data.get("maintainer_name", ""),
            self.config_data.get("maintainer_email", ""),
            self.config_data.get("gemini_api_key", ""),
            self._
        )
        self.active_dialog = dialog # Set active dialog
        response = dialog.run()
        self.active_dialog = None # Clear active dialog

        if response == Gtk.ResponseType.OK:
            name, email, api_key = dialog.get_settings()
            self.config_data["maintainer_name"] = name
            self.config_data["maintainer_email"] = email
            self.config_data["gemini_api_key"] = api_key
            self.save_config()
            # Actualizar la UI si está vacía
            if not self.entry_maintainer_name.get_text():
                self.entry_maintainer_name.set_text(name)
            if not self.entry_maintainer_email.get_text():
                self.entry_maintainer_email.set_text(email)
                
        dialog.destroy()

    def on_add_translation_clicked(self, widget):
        """Muestra el diálogo para añadir una traducción."""
        original_name = self.entry_display_name.get_text()
        original_comment = self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta)
        original_appstream_name = self.entry_appstream_name_main.get_text()
        original_appstream_comment = self.entry_appstream_comment_main.get_text()
        
        dialog = TranslationDialog(
            self, 
            self.config_data.get("gemini_api_key", ""), 
            original_name,
            original_comment,
            self._
        )
        self.active_dialog = dialog # Set active dialog
        response = dialog.run()
        self.active_dialog = None # Clear active dialog

        if response == Gtk.ResponseType.OK:
            trans_data = dialog.get_translation()
            lang = trans_data.get('lang')
            
            if lang:
                # Reemplazar si ya existe, añadir si es nuevo
                found = False
                for i, existing_data in enumerate(self.traducciones_list):
                    if existing_data['lang'] == lang:
                        self.traducciones_list[i] = trans_data
                        found = True
                        break
                if not found:
                    self.traducciones_list.append(trans_data)
                print(f"Traducción añadida/actualizada: {self.traducciones_list}")
                self.traducciones_list.sort(key=lambda x: x['lang']) # Keep sorted
                self._refresh_translations_list() # Refresh the listbox
            else:
                mostrar_error(self, self._("Error"), self._("El código de idioma no puede estar vacío."), self._)
        
        dialog.destroy()

    # --- Lógica de Idioma ---
    def crear_menu_idioma(self):
        """Crea y devuelve el Gtk.MenuButton para seleccionar idioma."""
        menu = Gtk.Menu()
        
        # Grupo para los radio buttons
        group = []
        
        # Idiomas soportados (codigo, nombre_mostrado)
        # The displayed name will be translated
        supported_langs = [
            ("system", self._("Predeterminado del Sistema")),
            ("es", self._("Español")),
            ("en", self._("English")),
            ("fr", self._("Français")),
            ("pt", self._("Português")),
            ("it", self._("Italiano"))
        ]
        
        current_lang = self.config_data.get("language", "system")

        for lang_code, lang_name_translated in supported_langs:
            item = Gtk.RadioMenuItem.new_with_label(group, lang_name_translated)
            group = item.get_group()
            item.set_active(lang_code == current_lang)
            item.connect("toggled", self.on_language_changed, lang_code)
            menu.append(item)
            
        menu.show_all()
        
        button = Gtk.MenuButton.new()
        button.set_popup(menu)
        button.set_tooltip_text(self._("Cambiar idioma"))
        
        # Icono para el botón
        icon = Gtk.Image.new_from_icon_name("preferences-desktop-locale-symbolic", Gtk.IconSize.BUTTON)
        button.add(icon)
        
        return button

    def on_language_changed(self, widget, lang_code):
        """Se llama cuando se selecciona un nuevo idioma."""
        if not widget.get_active():
            return

        current_lang = self.config_data.get("language", "es")
        if current_lang == lang_code:
            return

        self.config_data["language"] = lang_code
        self.save_config()

        # Reinstalar la traducción y actualizar la UI
        init_language(lang_code) # Usar la nueva función para cambiar el idioma
        self._ = _ # Actualizar la referencia en la instancia
        print(f"Idioma cambiado dinámicamente a: {lang_code}")

        self.update_ui_for_language()

    def update_ui_for_language(self):
        """Actualiza todos los textos de la UI al idioma actual."""
        self._ = _ # Actualizar la función de traducción en la instancia
        self.set_title("") # Se elimina el texto del título de la ventana al cambiar el idioma

        # --- HeaderBar ---
        self.header_bar.props.title = self._("Luk-Os Debify") # Se elimina el texto del título de la barra de encabezado
        self.btn_settings.set_tooltip_text(self._("Configuración"))
        self.btn_about.set_tooltip_text(self._("Acerca de..."))
        
        # Remove existing language menu button if it exists
        if hasattr(self, 'lang_menu_button') and self.lang_menu_button.get_parent():
            self.header_bar.remove(self.lang_menu_button)
        
        # Re-create and pack the language menu button
        self.lang_menu_button = self.crear_menu_idioma()
        self.header_bar.pack_start(self.lang_menu_button)
        self.lang_menu_button.show_all() # Ensure the new button and its menu are shown

        self.btn_paquete.set_label(self._("Crear Paquete"))

        # --- Templates Menu ---
        self.btn_templates.set_tooltip_text(self._("Plantillas"))
        self.item_save.set_label(self._("Guardar Plantilla"))
        self.item_load.set_label(self._("Cargar Plantilla"))

        # --- Formulario ---
        self.label_proyecto.set_label(self._("Directorio del Proyecto:"))
        self.entry_proyecto_path.set_placeholder_text(self._("Selecciona el directorio de tu proyecto"))
        self.btn_select_proyecto.set_tooltip_text(self._("Seleccionar Directorio del Proyecto"))
        self.label_principal.set_label(self._("Archivo Principal (Ejecutable):"))
        self.label_icono.set_label(self._("Icono de la Aplicación:"))
        self.chooser_icono.set_title(self._("Selecciona un archivo de icono (.png o .svg)"))
        # Asegurarse de que el filtro exista antes de intentar actualizarlo
        if self.chooser_icono.get_filter():
            self.chooser_icono.get_filter().set_name(self._("Imágenes"))
        self.label_pkg_name.set_label(self._("Nombre del Paquete (ID):"))
        self.label_version.set_label(self._("Versión:"))
        self.label_version.set_label(self._("Versión:"))
        # self.label_package_type.set_label(self._("Tipo de Paquete:")) # Removed
        # self.check_appstream.set_label(self._("Añadir metadatos de AppStream (para tiendas de software)"))
        self.label_categoria_unificada.set_label(self._("Categoría Principal:"))
        self.label_maintainer_name.set_label(self._("Nombre del Mantenedor:"))
        self.label_maintainer_email.set_label(self._("Correo del Mantenedor:"))
        self.label_display_name.set_label(self._("Nombre (para el Menú):"))
        self.label_desc_corta.set_label(self._("Descripción Corta:"))
        self.label_desc_larga.set_label(self._("Descripción Larga (para el gestor de paquetes):"))

        # Update the text of the tabs
        self.stack.child_set_property(self.stack.get_child_by_name("formulario"), "title", self._("Formulario"))
        appstream_child = self.stack.get_child_by_name("appstream")
        if appstream_child:
            self.stack.child_set_property(appstream_child, "title", self._("AppStream"))
        self.stack.child_set_property(self.stack.get_child_by_name("traducciones"), "title", self._("Traducciones"))
        
        # Update Architecture label
        self.label_architecture.set_label(self._("Arquitectura:"))
        
        # Update System Settings checkbox
        self.check_system_settings.set_label(self._("Mostrar en Configuración del Sistema (XFCE, GNOME, etc.)"))
        self.label_exec_args.set_label(self._("Argumentos de Ejecución (Opcional):"))
        self.entry_exec_args.set_placeholder_text(self._("--window --settings (ejemplo)"))
        
        # Re-crear el ListStore para las categorías unificadas con los textos traducidos
        self.unified_categories_map = [
            (self._("Utilidad (General)"), "utils", "Utility;Application;"),
            (self._("Juego"), "games", "Game;"),
            (self._("Desarrollo"), "devel", "Development;"),
            (self._("Gráficos"), "graphics", "Graphics;"),
            (self._("Oficina"), "office", "Office;"),
            (self._("Red"), "net", "Network;"),
            (self._("Audio/Video"), "sound", "AudioVideo;Audio;Video;"),
            (self._("Ciencia"), "science", "Science;"),
            (self._("Sistema / Configuración"), "admin", "System;Settings;"),
            (self._("Educación"), "education", "Education;"),
            (self._("Web"), "web", "WebBrowser;"), # Ejemplo
        ]
        
        self.unified_category_store.clear()
        for disp, sect, cat in self.unified_categories_map:
            self.unified_category_store.append([disp, sect, cat])
        
        # Restaurar la selección si es posible, o establecer un valor por defecto
        # (Esto es un poco más complejo, por ahora simplemente se reestablece a 0)
        self.combo_categoria_unificada.set_active(0)

        # --- Traducciones Adicionales ---
        self.label_traducciones.set_label(self._("Traducciones .Desktop (para .desktop):"))
        self.btn_add_translation_form.set_tooltip_text(self._("Añadir nueva traducción"))
        self.btn_remove_selected_translation.set_tooltip_text(self._("Eliminar traducción seleccionada"))
        if hasattr(self, 'btn_batch_translate'):
            self.btn_batch_translate.set_tooltip_text(self._("Traducir a múltiples idiomas con Gemini"))

        # --- AppStream Page ---
        self.label_screenshots.set_label(self._("Capturas de pantalla:"))
        self.btn_add_screenshot.set_tooltip_text(self._("Añadir captura de pantalla"))
        self.btn_remove_screenshot.set_tooltip_text(self._("Eliminar captura seleccionada"))

        # --- Placeholders para Gtk.Entry ---
        self.entry_proyecto_path.set_placeholder_text(self._("Selecciona el directorio de tu proyecto"))
        self.entry_pkg_name.set_placeholder_text(self._("solo-minusculas-y-guiones"))
        self.entry_version.set_placeholder_text(self._("1.0.0"))
        self.entry_maintainer_name.set_placeholder_text(self._("Tu Nombre"))
        self.entry_maintainer_email.set_placeholder_text(self._("tu@email.com"))
        self.entry_display_name.set_placeholder_text(self._("Mi Aplicación"))
        # Actualizar placeholder para el nuevo textview de descripción corta
        is_desc_corta_modified = self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta) != ""
        self.placeholder_desc_corta = self._("Un resumen corto")
        if not is_desc_corta_modified:
            self.buffer_desc_corta.set_text(self.placeholder_desc_corta)
            self.textview_desc_corta.get_style_context().add_class("placeholder")


        # --- Panel Derecho ---
        self.label_deps.set_label(self._("Dependencias (una por línea):"))
        if hasattr(self, 'btn_scan_deps'):
            self.btn_scan_deps.set_tooltip_text(self._("Escanear dependencias con Gemini"))
        self.preview_label_titulo.set_label(self._("Vista Previa"))
        self.preview_label_name.set_text(self._("Nombre App")) # Update default text
        self.preview_label_comment.set_text(self._("Descripción corta...")) # Update default text

        # --- Placeholders para Gtk.TextView ---
        # Guardar el estado actual para saber si el usuario ha escrito algo
        is_deps_modified = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps) != ""
        is_desc_modified = self.get_buffer_text_or_empty(self.buffer_desc_larga, self.placeholder_desc_larga) != ""

        # Actualizar el texto del placeholder
        self.placeholder_deps = self._(
            "Dependencias del sistema, ej:\n"
            "python3-gi\n"
            "gstreamer1.0-plugins-good"
        )
        self.placeholder_desc_larga = self._(
            "Escribe una descripción más detallada aquí.\n"
            "Puede tener múltiples líneas."
        )

        # Volver a aplicar el placeholder solo si el campo estaba vacío
        if not is_deps_modified:
            self.buffer_deps.set_text(self.placeholder_deps)
            self.textview_deps.get_style_context().add_class("placeholder")

        if not is_desc_modified:
            self.buffer_desc_larga.set_text(self.placeholder_desc_larga)
            self.textview_desc_larga.get_style_context().add_class("placeholder")

        print("UI actualizada para el nuevo idioma.")
        self._refresh_translations_list() # Refresh the translations list with new language

        # Update active dialog if any
        if self.active_dialog and hasattr(self.active_dialog, 'update_ui_for_language'):
            self.active_dialog.update_ui_for_language(self._)
            print(f"Active dialog ({type(self.active_dialog).__name__}) UI updated for new language.")


    def on_about_clicked(self, widget):
        """Muestra el diálogo "Acerca de" personalizado."""
        dialog = AboutDialog(self, self.app_info, self.config_data, self._)
        dialog.run()
        dialog.destroy()


    def load_config(self):
        """Carga el mantenedor por defecto desde el archivo JSON."""
        try:
            if not os.path.exists(self.config_file):
                return # No hacer nada si no existe
                
            with open(self.config_file, 'r') as f:
                self.config_data = json.load(f)
            
            name = self.config_data.get("maintainer_name", "")
            email = self.config_data.get("maintainer_email", "")
            
            # --- CORRECCIÓN: Los campos deben existir antes de llamarlos ---
            # (Asegurado por el orden de llamadas en __init__)
            self.entry_maintainer_name.set_text(name)
            self.entry_maintainer_email.set_text(email)

        except Exception as e:
            print(f"Error al cargar la configuración: {e}")
            # Poner placeholders si falla
            self.entry_maintainer_name.set_placeholder_text(self._("Tu Nombre"))
            self.entry_maintainer_email.set_placeholder_text(self._("tu@email.com"))

    def save_config(self):
        """Guarda la configuración actual en el archivo JSON."""
        try:
            # Asegurarse de que el directorio exista
            os.makedirs(self.config_dir, exist_ok=True)
            
            with open(self.config_file, 'w') as f:
                json.dump(self.config_data, f, indent=4)
                
        except Exception as e:
            print(f"Error al guardar la configuración: {e}")

    # --- Callbacks del Formulario ---

    def on_select_proyecto_clicked(self, widget):
        """Abre un diálogo de selección de carpeta para el directorio del proyecto."""
        dialog = Gtk.FileChooserDialog(
            title=self._("Selecciona el directorio de tu proyecto"),
            parent=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        dialog.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(self._("Cancelar"))
        dialog.get_widget_for_response(Gtk.ResponseType.OK).set_label(self._("Seleccionar"))

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            dir_path = dialog.get_filename()
            self.entry_proyecto_path.set_text(dir_path)
            self.on_proyecto_changed(dir_path) # Llamar a la lógica existente
        dialog.destroy()

    def on_proyecto_changed(self, dir_path):
        """Se activa al seleccionar un directorio de proyecto (ahora recibe la ruta directamente)."""
        self.combo_main_file.remove_all()
        
        if not dir_path:
            return

        try:
            # Escanear el directorio (no recursivo por simplicidad, pero podría serlo)
            archivos = []
            for root, dirs, files in os.walk(dir_path):
                for file in files:
                    # Obtener ruta relativa
                    full_path = os.path.join(root, file)
                    relative_path = os.path.relpath(full_path, dir_path)
                    archivos.append(relative_path)
            
            if not archivos:
                self.combo_main_file.append_text(self._("No se encontraron archivos"))
                self.combo_main_file.set_active(0)
                return

            # Rellenar el ComboBox
            for f in sorted(archivos):
                self.combo_main_file.append(f, f) # Use append(id, text)
            
            self.combo_main_file.set_active(0) # Seleccionar el primero
            
            # Auto-detectar 'main.py' si existe
            if 'main.py' in archivos:
                self.combo_main_file.set_active_id('main.py')
            
            # Actualizar la vista previa (por si cambia el icono)
            self.on_preview_update(None)

        except Exception as e:
            print(f"Error al escanear directorio: {e}")
            self.combo_main_file.append_text(self._("Error al leer directorio"))
            self.combo_main_file.set_active(0)
    
    def on_main_file_changed(self, combo):
        """Callback cuando cambia el archivo principal seleccionado."""
        filename = combo.get_active_text()
        if filename:
            self.detectar_dependencias(filename)

    def on_package_type_changed(self, combo):
        """Deprecated: Package type is always deb."""
        pass

    def detectar_dependencias(self, main_file):
        """Detecta dependencias basadas en el archivo principal."""
        if main_file.endswith(".py"):
            package_type = "deb" # Always deb
            
            try:
                with open(os.path.join(self.entry_proyecto_path.get_text(), main_file), 'r') as f:
                    content = f.read()
                    
                imports = set(re.findall(r'^import (\w+)|^from (\w+) import', content, re.MULTILINE))
                detected_deps = set()
                
                for imp in imports:
                    module = imp[0] or imp[1]
                    if module in self.mapa_conversiones_py:
                        detected_deps.add(self.mapa_conversiones_py[module])
                
                if detected_deps:
                    current_text = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
                    new_deps = ", ".join(detected_deps)
                    if current_text:
                        self.buffer_deps.set_text(current_text + ", " + new_deps)
                    else:
                        self.buffer_deps.set_text(new_deps)
                    self.textview_deps.get_style_context().remove_class("placeholder")
                    
            except Exception as e:
                print(f"Error detectando dependencias: {e}")
            dir_path = self.entry_proyecto_path.get_text() # Usar el nuevo Entry
            if dir_path:
                # Intentar buscar iconos comunes
                for nombre_icono in ["icon.png", "logo.png", "icon.svg", "logo.svg"]:
                    ruta_intento = os.path.join(dir_path, nombre_icono)
                    if os.path.exists(ruta_intento):
                        icon_path = ruta_intento
                        # Actualizar el chooser para reflejar esto
                        self.chooser_icono.set_filename(icon_path)
                        break
        else:
            # Si no es python, limpiar las dependencias auto-detectadas
            current_deps = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
            # (Podríamos ser más inteligentes y solo borrar las de python,
            # pero por ahora simplemente no hacemos nada)
            pass

    def on_preview_update(self, widget):
        """Actualiza la vista previa con los datos del formulario."""
        
        # Actualizar Nombre
        name = self.entry_display_name.get_text()
        if name:
            self.preview_label_name.set_text(name)
        else:
            self.preview_label_name.set_text(self._("Nombre App"))

        # Actualizar Descripción
        comment = self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta)
        if comment:
            self.preview_label_comment.set_text(comment)
        else:
            self.preview_label_comment.set_text(self._("Descripción corta..."))

        # Actualizar Icono
        icon_path = self.chooser_icono.get_filename()
        
        # Si no hay icono, intentar buscar uno en el proyecto
        if not icon_path:
            dir_path = self.entry_proyecto_path.get_text() # Usar el nuevo Entry
            if dir_path:
                # Intentar buscar iconos comunes
                for nombre_icono in ["icon.png", "logo.png", "icon.svg", "logo.svg"]:
                    ruta_intento = os.path.join(dir_path, nombre_icono)
                    if os.path.exists(ruta_intento):
                        icon_path = ruta_intento
                        # Actualizar el chooser para reflejar esto
                        self.chooser_icono.set_filename(icon_path)
                        break

        if icon_path:
            try:
                # Escalar para la vista previa
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_size(icon_path, 96, 96)
                self.preview_image.set_from_pixbuf(pixbuf)
                # Establecer el icono de la ventana principal
                Gtk.Window.set_default_icon_from_file(icon_path)
            except GLib.Error:
                # Error al cargar (ej: SVG no soportado o corrupto)
                self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
                self.preview_image.set_pixel_size(96)
        else:
            self.preview_image.set_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
            self.preview_image.set_pixel_size(96)
    
    # --- Lógica de Dependencias ---

    def detectar_dependencias_python(self, package_type):
        """Busca un requirements.txt y lo convierte a deps de Debian o RPM."""
        
        dir_path = self.entry_proyecto_path.get_text() # Usar el nuevo Entry
        if not dir_path:
            return

        req_file = os.path.join(dir_path, "requirements.txt")
        if not os.path.exists(req_file):
            return

        try:
            with open(req_file, 'r') as f:
                requirements = f.readlines()
            
            detected_deps = []
            for req in requirements:
                req = req.strip()
                if not req or req.startswith("#"):
                    continue
                
                # Quitar versiones (ej: "requests>=2.0")
                # Usar re.split para manejar '==', '>=', '<=', '>', '~='
                pkg_name = re.split(r'[=><~]', req)[0].strip().lower()
                
                if not pkg_name:
                    continue

                if package_type == "deb":
                    # Convertir a formato debian
                    if pkg_name in self.mapa_conversiones_py:
                        detected_deps.append(self.mapa_conversiones_py[pkg_name])
                    else:
                        # Lógica de fallback
                        detected_deps.append(f"python3-{pkg_name}")
                elif package_type == "rpm":
                    # Convertir a formato RPM
                    if pkg_name in self.mapa_conversiones_py_rpm:
                        detected_deps.append(self.mapa_conversiones_py_rpm[pkg_name])
                    else:
                        # Lógica de fallback
                        detected_deps.append(f"python3-{pkg_name}")
            
            if detected_deps:
                # Añadir a las dependencias (sin borrar las existentes)
                texto_deps_actual = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
                deps_actuales = set(texto_deps_actual.split('\n'))
                
                # Añadir las nuevas sin duplicar
                for dep in detected_deps:
                    deps_actuales.add(dep)
                
                # Limpiar vacíos
                deps_actuales.discard("")

                texto_final = "\n".join(sorted(list(deps_actuales)))
                self.buffer_deps.set_text(texto_final)
                # Quitar el estilo placeholder si lo tenía
                self.textview_deps.get_style_context().remove_class("placeholder")

        except Exception as e:
            print(f"Error al leer requirements.txt: {e}")

    # --- Lógica de Escaneo de Dependencias con Gemini ---
    def on_scan_deps_gemini_clicked(self, widget):
        """Inicia el escaneo de dependencias con Gemini."""
        api_key = self.config_data.get("gemini_api_key")
        if not api_key:
            mostrar_error(self, self._("Error"), self._("Configura la API Key de Gemini en Ajustes para usar esta función"), self._)
            return

        dir_path = self.entry_proyecto_path.get_text()
        if not dir_path:
            mostrar_error(self, self._("Error"), self._("Selecciona un directorio de proyecto primero."), self._)
            return

        self.btn_scan_deps.set_sensitive(False)
        self.progress_bar.set_visible(True)
        self.progress_bar.set_text(self._("Escaneando dependencias con Gemini..."))
        self.progress_bar.pulse()

        thread = threading.Thread(target=self.scan_deps_gemini_thread, args=(dir_path, api_key))
        thread.daemon = True
        thread.start()

    def scan_deps_gemini_thread(self, dir_path, api_key):
        """Hilo para escanear dependencias."""
        try:
            # 1. Recopilar información del proyecto (imports, requirements, etc.)
            project_context = ""
            
            # Leer requirements.txt si existe
            req_file = os.path.join(dir_path, "requirements.txt")
            if os.path.exists(req_file):
                with open(req_file, 'r') as f:
                    project_context += f"--- requirements.txt ---\n{f.read()}\n"
            
            # Leer imports de archivos .py (primeras 50 líneas)
            for root, dirs, files in os.walk(dir_path):
                if '.git' in dirs: dirs.remove('.git')
                if '__pycache__' in dirs: dirs.remove('__pycache__')
                
                for file in files:
                    if file.endswith(".py"):
                        try:
                            with open(os.path.join(root, file), 'r') as f:
                                lines = f.readlines()[:50] # Solo las primeras 50 líneas para buscar imports
                                content = "".join(lines)
                                project_context += f"--- {file} ---\n{content}\n"
                        except:
                            pass
                if len(project_context) > 10000: # Limitar contexto
                    break
            
            if not project_context:
                raise Exception("No se encontró código relevante para analizar.")

            # 2. Consultar a Gemini
            package_type = "deb" # Default a deb para nombres de paquetes
            # Podríamos pasar self.combo_package_type.get_active_id() pero requiere acceso thread-safe o pasarlo como arg
            
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
            headers = {'Content-Type': 'application/json'}
            
            prompt = f"""
            Analyze the following Python project context and list the system dependencies required for Debian/Ubuntu (apt packages).
            Focus on Python libraries that need system packages (e.g., 'python3-numpy' for numpy, 'python3-gi' for PyGObject).
            Also include common system libraries if obvious (e.g., 'ffmpeg' if subprocess calls it).
            
            Return ONLY a list of package names, one per line. No markdown, no explanations.
            
            Context:
            {project_context}
            """
            
            data = {
                "contents": [{
                    "parts": [{"text": prompt}]
                }]
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            text_response = result['candidates'][0]['content']['parts'][0]['text']
            
            # Limpiar respuesta
            deps_list = [line.strip() for line in text_response.split('\n') if line.strip() and not line.startswith('```')]
            
            GLib.idle_add(self.on_scan_deps_success, deps_list)

        except Exception as e:
            print(f"Error Gemini Deps: {e}")
            GLib.idle_add(self.on_scan_deps_error, str(e))

    def on_scan_deps_success(self, deps_list):
        """Actualiza la UI con las dependencias detectadas."""
        self.progress_bar.set_visible(False)
        self.btn_scan_deps.set_sensitive(True)
        
        current_text = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
        current_deps = set(current_text.split('\n'))
        
        for dep in deps_list:
            current_deps.add(dep)
        
        current_deps.discard("")
        final_text = "\n".join(sorted(list(current_deps)))
        
        self.buffer_deps.set_text(final_text)
        self.textview_deps.get_style_context().remove_class("placeholder")
        
        mostrar_info(self, self._("Escaneo Completado"), self._(f"Se detectaron {len(deps_list)} dependencias potenciales."), self._)

    def on_scan_deps_error(self, error_msg):
        """Muestra error si falla el escaneo."""
        self.progress_bar.set_visible(False)
        self.btn_scan_deps.set_sensitive(True)
        mostrar_error(self, self._("Error al escanear"), error_msg, self._)

    # --- Sistema de Plantillas ---
    def on_save_template_clicked(self, widget):
        """Muestra diálogo para guardar plantilla."""
        dialog = Gtk.FileChooserDialog(
            title=self._("Guardar Plantilla"),
            parent=self,
            action=Gtk.FileChooserAction.SAVE
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        dialog.set_do_overwrite_confirmation(True)
        pkg_name = self.entry_pkg_name.get_text().strip()
        default_name = f"{pkg_name}_template.zip" if pkg_name else "plantilla_template.zip"
        dialog.set_current_name(default_name)
        
        filter_zip = Gtk.FileFilter()
        filter_zip.set_name("Zip Files")
        filter_zip.add_mime_type("application/zip")
        filter_zip.add_pattern("*.zip")
        dialog.add_filter(filter_zip)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filename = dialog.get_filename()
            if not filename.endswith(".zip"):
                filename += ".zip"
            self.save_template(filename)
        dialog.destroy()

    def on_load_template_clicked(self, widget):
        """Muestra diálogo para cargar plantilla."""
        dialog = Gtk.FileChooserDialog(
            title=self._("Cargar Plantilla"),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        
        filter_zip = Gtk.FileFilter()
        filter_zip.set_name("Zip Files")
        filter_zip.add_mime_type("application/zip")
        filter_zip.add_pattern("*.zip")
        dialog.add_filter(filter_zip)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            filename = dialog.get_filename()
            self.load_template(filename)
        dialog.destroy()

    def save_template(self, filename):
        """Guarda el estado actual del formulario en un archivo ZIP con capturas."""
        try:
            # Obtener categoría unificada
            treeiter = self.combo_categoria_unificada.get_active_iter()
            section = ""
            categories = ""
            if treeiter:
                model = self.combo_categoria_unificada.get_model()
                section = model[treeiter][1]
                categories = model[treeiter][2]

            # Datos base
            # 0. Guardar dependencias actuales en el mapa antes de guardar
            current_deps = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
            
            data = {
                "project_dir": self.entry_proyecto_path.get_text(),
                "main_file": self.combo_main_file.get_active_text(),
                "icon_path": self.chooser_icono.get_filename(),
                "pkg_name": self.entry_pkg_name.get_text(),
                "version": self.entry_version.get_text(),
                "package_type": "deb", # Always deb
                "architecture": self.combo_architecture.get_active_id(),
                "appstream_enabled": True, # self.check_appstream.get_active(),
                "category_section": section,
                "category_values": categories,
                "maintainer_name": self.entry_maintainer_name.get_text(),
                "maintainer_email": self.entry_maintainer_email.get_text(),
                "display_name": self.entry_display_name.get_text(),
                "short_desc": self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta),
                "long_desc": self.get_buffer_text_or_empty(self.buffer_desc_larga, self.placeholder_desc_larga),
                "long_desc": self.get_buffer_text_or_empty(self.buffer_desc_larga, self.placeholder_desc_larga),
                "dependencies": current_deps, # Legacy support
                "traducciones": self.traducciones_list,
                # "screenshots": self.screenshots_list, # Se manejará especial para el ZIP
                # AppStream metadata removed from template as requested
                "traducciones": self.traducciones_list,
                # "screenshots": self.screenshots_list, # Se manejará especial para el ZIP
                # AppStream metadata removed from template as requested
                "show_in_system_settings": self.check_system_settings.get_active(),
                "exec_args": self.entry_exec_args.get_text()
            }
            
            with zipfile.ZipFile(filename, 'w') as zipf:
                # 1. Guardar Icono
                icon_path = self.chooser_icono.get_filename()
                if icon_path and os.path.exists(icon_path):
                    ext = os.path.splitext(icon_path)[1]
                    zip_icon_path = f"icon{ext}"
                    zipf.write(icon_path, zip_icon_path)
                    data["icon_path"] = zip_icon_path
                
                # 2. Guardar JSON
                zipf.writestr("template.json", json.dumps(data, indent=4))
            
            mostrar_info(self, self._("Éxito"), self._("Plantilla guardada correctamente."), self._)
            
        except Exception as e:
            mostrar_error(self, self._("Error"), f"No se pudo guardar la plantilla: {e}", self._)

    def load_template(self, filename):
        """Carga un archivo ZIP (o JSON legacy) y rellena el formulario."""
        try:
            data = {}
            extract_dir = ""
            
            if zipfile.is_zipfile(filename):
                # Es un ZIP (nuevo formato)
                extract_dir = os.path.join(tempfile.gettempdir(), "EmpaquetadorDeb_Templates", os.path.basename(filename) + "_extracted")
                os.makedirs(extract_dir, exist_ok=True)
                
                with zipfile.ZipFile(filename, 'r') as zipf:
                    zipf.extractall(extract_dir)
                    
                json_path = os.path.join(extract_dir, "template.json")
                if os.path.exists(json_path):
                    with open(json_path, 'r') as f:
                        data = json.load(f)
                else:
                    raise Exception("El archivo ZIP no contiene template.json")
                
                # Actualizar ruta del icono a absoluta
                if "icon_path" in data:
                    abs_icon_path = os.path.join(extract_dir, data["icon_path"])
                    if os.path.exists(abs_icon_path):
                        data["icon_path"] = abs_icon_path

            else:
                # Intento de carga legacy (JSON directo)
                with open(filename, 'r') as f:
                    data = json.load(f)
            
            # Restaurar valores
            # Restaurar valores
            
            # 1. Solicitar directorio del proyecto (CRÍTICO: El usuario lo pidió explícitamente)
            project_dir = None
            
            dialog_dir = Gtk.FileChooserDialog(
                title=self._("Selecciona el directorio del proyecto para esta plantilla"),
                parent=self,
                action=Gtk.FileChooserAction.SELECT_FOLDER
            )
            dialog_dir.add_buttons(
                Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OPEN, Gtk.ResponseType.OK
            )
            
            response_dir = dialog_dir.run()
            if response_dir == Gtk.ResponseType.OK:
                project_dir = dialog_dir.get_filename()
            dialog_dir.destroy()

            if project_dir:
                self.entry_proyecto_path.set_text(project_dir)
                if os.path.isdir(project_dir):
                    self.on_proyecto_changed(project_dir)
            elif "project_dir" in data:
                 # Fallback al del JSON si el usuario cancela, pero avisando? 
                 # O simplemente respetamos que canceló y dejamos lo que había o lo del JSON.
                 # Comportamiento "seguro": poner lo del JSON pero no auto-cargar si no existe.
                 self.entry_proyecto_path.set_text(data["project_dir"])
                 if os.path.isdir(data["project_dir"]):
                    self.on_proyecto_changed(data["project_dir"])

            if "main_file" in data and data["main_file"]:
                # Try to set active ID if it exists in the combo
                # Since combo is populated dynamically, we might need to wait or check
                # For now, simplistic approach:
                for row in self.combo_main_file.get_model():
                    if row[0] == data["main_file"]:
                        self.combo_main_file.set_active_iter(row.iter)
                        break
            
            if "icon_path" in data and data["icon_path"] and os.path.exists(data["icon_path"]):
                self.chooser_icono.set_filename(data["icon_path"])
                self.on_preview_update(None)

            self.entry_pkg_name.set_text(data.get("pkg_name", ""))
            self.entry_version.set_text(data.get("version", ""))
            
            if "package_type" in data:
                # self.combo_package_type.set_active_id(data["package_type"]) # Ignored, always deb
                pass
            
            if "architecture" in data:
                self.combo_architecture.set_active_id(data["architecture"])
                
            if "appstream_enabled" in data:
                pass # self.check_appstream.set_active(data["appstream_enabled"])

            if "show_in_system_settings" in data:
                self.check_system_settings.set_active(data["show_in_system_settings"])

            self.entry_exec_args.set_text(data.get("exec_args", ""))

            # Restaurar categoría
            if "category_values" in data:
                for row in self.unified_category_store:
                    if row[2] == data["category_values"]:
                        self.combo_categoria_unificada.set_active_iter(row.iter)
                        break
            
            self.entry_maintainer_name.set_text(data.get("maintainer_name", ""))
            self.entry_maintainer_email.set_text(data.get("maintainer_email", ""))
            self.entry_display_name.set_text(data.get("display_name", ""))
            
            if "short_desc" in data and data["short_desc"]:
                self.buffer_desc_corta.set_text(data["short_desc"])
                self.textview_desc_corta.get_style_context().remove_class("placeholder")
            
            if "long_desc" in data and data["long_desc"]:
                self.buffer_desc_larga.set_text(data["long_desc"])
                self.textview_desc_larga.get_style_context().remove_class("placeholder")
                
            # Cargar dependencias (siempre las 'dependencies' simples o 'deb' del mapa si existe)
            deps_text = ""
            if "dependencies_map" in data and "deb" in data["dependencies_map"]:
                 deps_text = data["dependencies_map"]["deb"]
            elif "dependencies" in data:
                 deps_text = data["dependencies"]
            
            if deps_text:
                self.buffer_deps.set_text(deps_text)
                self.textview_deps.get_style_context().remove_class("placeholder")
            else:
                self.buffer_deps.set_text(self.placeholder_deps)
                self.textview_deps.get_style_context().add_class("placeholder")
                
            if "traducciones" in data:
                self.traducciones_list = data["traducciones"]
                self._refresh_translations_list()
                

            
            self.entry_appstream_name_main.set_text(data.get("appstream_name_main", ""))
            self.entry_appstream_comment_main.set_text(data.get("appstream_comment_main", ""))
            self.entry_appstream_developer_name.set_text(data.get("appstream_developer_name", ""))
            self.entry_appstream_license.set_text(data.get("appstream_license", "GPL-3.0-or-later"))
            self.entry_appstream_homepage.set_text(data.get("appstream_homepage", ""))
            self.entry_appstream_bugtracker.set_text(data.get("appstream_bugtracker", ""))

            self.on_preview_update(None)
            mostrar_info(self, self._("Éxito"), self._("Plantilla cargada correctamente."), self._)

        except Exception as e:
            mostrar_error(self, self._("Error"), f"No se pudo cargar la plantilla: {e}", self._)


    # --- Lógica de Traducción por Lotes ---
    def on_batch_translate_clicked(self, widget):
        """Muestra diálogo para traducción por lotes."""
        api_key = self.config_data.get("gemini_api_key")
        if not api_key:
            mostrar_error(self, self._("Error"), self._("Configura la API Key de Gemini en Ajustes para usar esta función"), self._)
            return

        # Diálogo simple para pedir idiomas
        dialog = Gtk.Dialog(title=self._("Traducción por Lotes"), transient_for=self, flags=0)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OK, Gtk.ResponseType.OK)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        label = Gtk.Label(label=self._("Introduce los códigos de idioma separados por comas (ej: fr, pt, it, de):"))
        box.add(label)
        
        entry = Gtk.Entry()
        entry.set_placeholder_text("fr, pt, it")
        box.add(entry)
        
        box.show_all()
        
        response = dialog.run()
        langs_str = entry.get_text()
        dialog.destroy()
        
        if response == Gtk.ResponseType.OK and langs_str:
            langs = [l.strip() for l in langs_str.split(',') if l.strip()]
            if langs:
                self.start_batch_translation(langs, api_key)

    def start_batch_translation(self, langs, api_key):
        """Inicia el hilo de traducción por lotes."""
        self.btn_batch_translate.set_sensitive(False)
        self.progress_bar.set_visible(True)
        self.progress_bar.set_text(self._(f"Traduciendo a {len(langs)} idiomas..."))
        self.progress_bar.pulse()
        
        thread = threading.Thread(target=self.batch_translate_thread, args=(langs, api_key))
        thread.daemon = True
        thread.start()

    def batch_translate_thread(self, langs, api_key):
        """Hilo para llamar a Gemini."""
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
            headers = {'Content-Type': 'application/json'}
            
            original_name = self.entry_display_name.get_text()
            original_comment = self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta)
            original_appstream_name = self.entry_appstream_name_main.get_text()
            original_appstream_comment = self.entry_appstream_comment_main.get_text()
            
            prompt = f"""
            Translate the app metadata to the following languages: {', '.join(langs)}.
            Return ONLY a JSON object where keys are language codes and values are objects with:
            "name", "comment".
            
            Original Name: "{original_name}"
            Original Comment: "{original_comment}"
            
            Example format:
            {{
                "fr": {{ "name": "...", "comment": "..." }},
                "pt": {{ ... }}
            }}
            """
            
            data = {
                "contents": [{
                    "parts": [{"text": prompt}]
                }]
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            text_response = result['candidates'][0]['content']['parts'][0]['text']
            
            # Limpiar markdown
            text_response = text_response.replace('```json', '').replace('```', '').strip()
            
            translations_map = json.loads(text_response)
            
            GLib.idle_add(self.on_batch_translate_success, translations_map)

        except Exception as e:
            print(f"Error Gemini Batch: {e}")
            GLib.idle_add(self.on_batch_translate_error, str(e))

    def on_batch_translate_success(self, translations_map):
        """Procesa los resultados de la traducción por lotes."""
        self.progress_bar.set_visible(False)
        self.btn_batch_translate.set_sensitive(True)
        
        count = 0
        for lang, data in translations_map.items():
            trans_data = {
                'lang': lang,
                'name': data.get('name', ''),
                'comment': data.get('comment', '')
            }
            
            # Actualizar o añadir
            found = False
            for i, existing in enumerate(self.traducciones_list):
                if existing['lang'] == lang:
                    self.traducciones_list[i] = trans_data
                    found = True
                    break
            if not found:
                self.traducciones_list.append(trans_data)
            count += 1
            
        self.traducciones_list.sort(key=lambda x: x['lang'])
        self._refresh_translations_list()
        
        mostrar_info(self, self._("Éxito"), self._(f"Se han procesado {count} traducciones correctamente."), self._)

    def on_batch_translate_error(self, error_msg):
        self.progress_bar.set_visible(False)
        self.btn_batch_translate.set_sensitive(True)
        mostrar_error(self, self._("Error de Traducción"), str(error_msg), self._)

    # --- Lógica Principal: Crear el Paquete ---

    def on_package_clicked(self, widget):
        """Valida los datos y lanza el proceso de construcción."""
        
        info = {} # Diccionario para pasar los datos
        
        # --- 1. Validar Directorio y Archivo Principal ---
        info["project_dir"] = self.entry_proyecto_path.get_text() # Usar el nuevo Entry
        if not info["project_dir"]:
            mostrar_error(self, self._("Error"), self._("Debes seleccionar un Directorio de Proyecto."), self._)
            return

        info["archivo_principal"] = self.combo_main_file.get_active_text()
        if not info["archivo_principal"] or info["archivo_principal"] == "No se encontraron archivos":
            mostrar_error(self, "Error", "Debes seleccionar un Archivo Principal.", self._)
            return

        # --- 2. Validar Icono ---
        info["icon_path"] = self.chooser_icono.get_filename()
        if not info["icon_path"]:
            mostrar_error(self, "Error", "Debes seleccionar un Icono.", self._)
            return
        info["icon_ext"] = os.path.splitext(info["icon_path"])[1]

        # --- 3. Validar Metadatos del Paquete ---
        info["pkg_name"] = self.entry_pkg_name.get_text().strip()
        info["pkg_version"] = self.entry_version.get_text().strip()
        
        # Validar nombre (solo minúsculas, números, guiones, puntos)
        if not re.match(r"^[a-z0-9][a-z0-9.-]+$", info["pkg_name"]):
            mostrar_error(self, self._("Error"), self._("Nombre del Paquete inválido.\nDebe estar en minúsculas y solo puede contener letras, números, guiones (-) y puntos (.)."), self._)
            return
        
        if not info["pkg_version"]:
            mostrar_error(self, self._("Error"), self._("Debes especificar una Versión."), self._)
            return

        # --- 4. Obtener Categoría Unificada ---
        treeiter = self.combo_categoria_unificada.get_active_iter()
        if treeiter:
            model = self.combo_categoria_unificada.get_model()
            info["section"] = model[treeiter][1] # ej: "utils"
            info["categories"] = model[treeiter][2] # ej: "Utility;Application;"
        else:
            mostrar_error(self, self._("Error"), self._("Debes seleccionar una Categoría Principal."), self._)
            return

        # --- 5. Validar Mantenedor ---
        maintainer_name = self.entry_maintainer_name.get_text().strip()
        maintainer_email = self.entry_maintainer_email.get_text().strip()
        if not maintainer_name or not maintainer_email:
            mostrar_error(self, self._("Error"), self._("Debes rellenar el Nombre y Correo del Mantenedor."), self._)
            return
        info["maintainer"] = f"{maintainer_name} <{maintainer_email}>"

        # --- 6. Validar Nombres y Descripciones ---
        info["display_name"] = self.entry_display_name.get_text()
        info["comment"] = self.get_buffer_text_or_empty(self.buffer_desc_corta, self.placeholder_desc_corta)
        if not info["display_name"] or not info["comment"]:
            mostrar_error(self, self._("Error"), self._("El Nombre y la Descripción Corta no pueden estar vacíos."), self._)
            return
        
        info["description"] = self.get_buffer_text_or_empty(self.buffer_desc_larga, self.placeholder_desc_larga)
        if not info["description"]:
            # Si la larga está vacía, reusar la corta
            info["description"] = info["comment"]

        # --- 7. Obtener Dependencias ---
        info["dependencies"] = self.get_buffer_text_or_empty(self.buffer_deps, self.placeholder_deps)
        
        # --- 8. Obtener Traducciones ---
        info["traducciones_extra"] = self.traducciones_list

        # --- 9. Obtener datos de AppStream ---
        info["appstream_enabled"] = False # Deshabilitado por petición del usuario
        info["appstream_screenshots"] = self.screenshots_list
        info["appstream_name_main"] = self.entry_appstream_name_main.get_text()
        info["appstream_comment_main"] = self.entry_appstream_comment_main.get_text()
        info["appstream_developer_name"] = self.entry_appstream_developer_name.get_text()
        info["appstream_license"] = self.entry_appstream_license.get_text()
        info["appstream_homepage"] = self.entry_appstream_homepage.get_text()
        info["appstream_bugtracker"] = self.entry_appstream_bugtracker.get_text()
        
        # --- 10. Obtener opción de Configuración del Sistema ---
        info["show_in_system_settings"] = self.check_system_settings.get_active()
        info["exec_args"] = self.entry_exec_args.get_text().strip()
        
        # Asegurar que package_type siempre tenga un valor válido
        # selected_package_type = self.combo_package_type.get_active_id() # Removed
        # print(f"DEBUG: selected_package_type from combo: {selected_package_type}")

        # info['package_type'] = self.combo_package_type.get_active_id() # Always deb
        info['package_type'] = "deb"
        
        # Fallback if combo returns None (shouldn't happen with set_active_id)
        # if not info['package_type']:
        #     info['package_type'] = "deb"
        
        info['architecture'] = self.combo_architecture.get_active_id()
        if not info['architecture']:
             info['architecture'] = "all"

        print(f"DEBUG: info['package_type'] after fallback: {info['package_type']}")
        print(f"DEBUG: info['architecture'] after fallback: {info['architecture']}")

        # Determinar extensión y nombre de archivo
        ext = ".deb"
        # if info['package_type'] == 'rpm':
        #     ext = ".rpm"
        # elif info['package_type'] == 'arch':
        #     ext = ".pkg.tar.zst"
            
        filename = f"{info['pkg_name']}_{info['pkg_version']}_{info['architecture']}{ext}"
        # --- 11. Pedir Dónde Guardar ---
        file_chooser_title = ""
        default_filename = ""

        # Asegurar que pkg_name y pkg_version no estén vacíos para el nombre de archivo
        pkg_name_safe = info['pkg_name'] if info['pkg_name'] else "mi-aplicacion"
        pkg_version_safe = info['pkg_version'] if info['pkg_version'] else "1.0.0"

        if info["package_type"] == "deb":
            file_chooser_title = self._("Guardar Paquete .deb")
            default_filename = f"{pkg_name_safe}_{pkg_version_safe}_all.deb"
        elif info["package_type"] == "rpm":
            file_chooser_title = self._("Guardar Paquete .rpm")
            default_filename = f"{pkg_name_safe}-{pkg_version_safe}-1.noarch.rpm" # Common RPM naming
        elif info["package_type"] == "arch":
            file_chooser_title = self._("Guardar Paquete Arch Linux")
            default_filename = f"{pkg_name_safe}-{pkg_version_safe}-1-any.pkg.tar.zst"

        # Fallback para el nombre de archivo si por alguna razón sigue vacío
        if not default_filename:
            default_filename = "paquete-generado.deb" # Un nombre genérico de último recurso

        dialog = Gtk.FileChooserDialog(
            title=file_chooser_title,
            parent=self,
            action=Gtk.FileChooserAction.SAVE
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        dialog.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(self._("Cancelar"))
        dialog.get_widget_for_response(Gtk.ResponseType.OK).set_label(self._("Guardar"))

        dialog.set_current_name(default_filename)

        response = dialog.run()
        save_path = dialog.get_filename()
        dialog.destroy()

        if response != Gtk.ResponseType.OK:
            return # Usuario canceló

        # Asegurar que la ruta de guardado tenga la extensión correcta
        # Asegurar que el nombre del archivo tenga la extensión correcta
        if not os.path.basename(save_path).endswith(".deb"):
            save_path = os.path.join(os.path.dirname(save_path), os.path.basename(save_path) + ".deb")

        # --- Lanzar la construcción en un hilo separado ---
        self.btn_paquete.set_sensitive(False)
        self.progress_bar.set_visible(True)
        self.progress_bar.set_text(self._("Construyendo paquete..."))
        self.progress_bar.pulse() # Modo "cargando"
        
        # Usar GLib.idle_add para no bloquear el UI
        GLib.idle_add(self.construir_paquete, info, save_path)


    def on_delete_event(self, widget, event):
        """Muestra un diálogo de confirmación al intentar cerrar la ventana."""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=self._("¿Estás seguro de que quieres salir?")
        )
        dialog.format_secondary_text(self._("Cualquier cambio no guardado se perderá."))
        response = dialog.run()
        dialog.destroy()

        if response == Gtk.ResponseType.YES:
            return False # Propagar el evento (cerrar)
        else:
            return True # Detener el evento (no cerrar)

    def construir_paquete(self, info, save_path):
        """El proceso de construcción (largo)."""
        
        build_dir = None
        try:
            print(f"DEBUG: construir_paquete received package_type: {info['package_type']}")
            if info["package_type"] == "deb":
                build_dir = tempfile.mkdtemp(prefix="deb_build_")
                self._construir_deb(info, build_dir, save_path)
            else:
                # Should not happen as we forced deb
                build_dir = tempfile.mkdtemp(prefix="deb_build_")
                self._construir_deb(info, build_dir, save_path)

            # 10. Éxito
            GLib.idle_add(
                mostrar_info,
                self,
                self._("¡Paquete creado con éxito!"),
                self._(f"El archivo se guardó en:\n{save_path}"),
                self._
            )

        except Exception as e:
            GLib.idle_add(mostrar_error, self, self._("Error al construir el paquete"), str(e), self._)
        
        finally:
            # Limpiar directorio temporal
            if build_dir and os.path.exists(build_dir):
                shutil.rmtree(build_dir)
            
            # Reactivar UI
            GLib.idle_add(self.progress_bar.set_visible, False)
            GLib.idle_add(self.btn_paquete.set_sensitive, True)
            # Devolver False para que GLib.idle_add no se repita
            return False

    def _prepare_executable(self, app_root, info):
        """Crea un symlink/copia del ejecutable principal con el nombre del paquete para asegurar WM_CLASS correcto."""
        original_main = os.path.join(app_root, info["archivo_principal"])
        main_dir = os.path.dirname(original_main)
        main_filename = os.path.basename(original_main)
        
        new_exec_name = info['pkg_name']
        new_exec_path = os.path.join(main_dir, new_exec_name)
        
        # Si ya se llama igual, no hacemos nada
        if new_exec_name == main_filename:
            return info["archivo_principal"]

        try:
            if os.path.exists(new_exec_path):
                if os.path.isdir(new_exec_path):
                    shutil.rmtree(new_exec_path)
                else:
                    os.remove(new_exec_path)
            
            # Intentar crear symlink
            os.symlink(main_filename, new_exec_path)
        except OSError:
            # Fallback a copia si falla el symlink (ej: sistemas de archivos sin soporte)
            try:
                shutil.copy(original_main, new_exec_path)
            except Exception as e:
                print(f"Error al preparar ejecutable: {e}")
                return info["archivo_principal"]
        
        # Calcular nueva ruta relativa
        rel_dir = os.path.dirname(info["archivo_principal"])
        return os.path.join(rel_dir, new_exec_name)

    def _construir_deb(self, info, build_dir, save_path):
        """Lógica para construir un paquete .deb."""
        # Directorios estándar para DEB
        debian_dir = os.path.join(build_dir, "DEBIAN")
        app_install_dir = os.path.join(build_dir, f"usr/share/{info['pkg_name']}")
        bin_dir = os.path.join(build_dir, "usr/bin")
        desktop_dir = os.path.join(build_dir, "usr/share/applications")
        icon_dir = os.path.join(build_dir, f"usr/share/icons/hicolor/256x256/apps")
        metainfo_dir = os.path.join(build_dir, "usr/share/metainfo")
        
        GLib.idle_add(self.progress_bar.set_text, self._("Creando estructura de directorios..."))
        GLib.idle_add(self.progress_bar.pulse)

        os.makedirs(debian_dir)
        os.makedirs(app_install_dir)
        os.makedirs(bin_dir)
        os.makedirs(desktop_dir)
        os.makedirs(icon_dir)

        # 2. Escribir archivo DEBIAN/control
        GLib.idle_add(self.progress_bar.set_text, self._("Generando archivo de control..."))
        GLib.idle_add(self.progress_bar.pulse)
        
        # Asegurar que la descripción corta no tenga saltos de línea
        short_desc_safe = info['comment'].replace('\n', ' ').strip()
        
        deps_list = [dep.strip() for dep in info["dependencies"].split('\n') if dep.strip()]
        deps_str = ", ".join(deps_list) if deps_list else ""
        
        # Construir el contenido sin dedent para la descripción larga para evitar problemas de indentación
        control_content = dedent(f"""
        Package: {info['pkg_name'].strip()}
        Version: {info['pkg_version'].strip()}
        Architecture: {info['architecture'].strip()}
        Maintainer: {info['maintainer'].strip()}
        Depends: {deps_str.strip()}
        Section: {info['section'].strip()}
        Priority: optional
        Description: {short_desc_safe}
        """).strip()
        
        # Añadir descripción larga línea por línea, asegurando el espacio inicial
        if info["description"]:
            for line in info["description"].splitlines():
                # Si la línea está vacía, usar un punto para representar línea vacía en control file
                if not line.strip():
                    control_content += "\n ."
                else:
                    control_content += f"\n {line}"

        with open(os.path.join(debian_dir, "control"), "w") as f:
            f.write(control_content + "\n")

        # 3. Escribir script pre-removal (para detener procesos antes de borrar)
        prerm_content = dedent(f"""
        #!/bin/sh
        set -e
        if [ "$1" = "remove" ]; then
            echo "Deteniendo procesos de {info['pkg_name']}..."
            # Intentar matar procesos que coincidan con la ruta de instalación de forma agresiva
            pkill -9 -f "/usr/share/{info['pkg_name']}" || true
            # También intentar matar por nombre de paquete si coincide con el ejecutable
            pkill -9 -x "{info['pkg_name']}" || true
        fi
        exit 0
        """)
        prerm_path = os.path.join(debian_dir, "prerm")
        with open(prerm_path, "w") as f:
            f.write(prerm_content)
        os.chmod(prerm_path, 0o755)

        # 4. Escribir script post-removal (para `purge`)
        postrm_content = dedent(f"""
        #!/bin/sh
        set -e
        if [ "$1" = "purge" ]; then
            echo "Purgando {info['pkg_name']}..."
            rm -rf /usr/share/{info['pkg_name']}
        fi
        exit 0
        """)
        postrm_path = os.path.join(debian_dir, "postrm")
        with open(postrm_path, "w") as f:
            f.write(postrm_content)
        os.chmod(postrm_path, 0o755) # Permisos de ejecución

        # 4. Copiar archivos del proyecto
        GLib.idle_add(self.progress_bar.set_text, self._("Copiando archivos del proyecto..."))
        GLib.idle_add(self.progress_bar.pulse)
        
        shutil.copytree(
            info["project_dir"],
            app_install_dir,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns('.git', '__pycache__', '*.deb', '*.rpm')
        )

        # 5. Crear lanzador en /usr/bin
        # Preparar el ejecutable (renombrar/symlink) para corregir WM_CLASS
        relative_exec_path = self._prepare_executable(app_install_dir, info)
        archivo_a_ejecutar = os.path.join(app_install_dir, relative_exec_path)
        os.chmod(archivo_a_ejecutar, 0o755)
        
        # Ruta final de instalación (no la temporal de construcción)
        final_path = f"/usr/share/{info['pkg_name']}/{relative_exec_path}"
        
        if info["archivo_principal"].endswith(".py"):
            exec_line = f"python3 {final_path} \"$@\""
        elif info["archivo_principal"].endswith(".sh") or info["archivo_principal"].endswith(".bash"):
            exec_line = f"bash {final_path} \"$@\""
        else:
            # Asumir que es un binario o script ejecutable con shebang
            exec_line = f"{final_path} \"$@\""
        launcher_content = dedent(f"""
        #!/bin/sh
        {exec_line}
        """)
        launcher_path = os.path.join(bin_dir, info["pkg_name"])
        with open(launcher_path, "w") as f:
            f.write(launcher_content)
        os.chmod(launcher_path, 0o755)

        # 6. Crear archivo .desktop
        icon_name_no_ext = info['pkg_name']
        
        extra_categories = ""
        if info.get("show_in_system_settings"):
            extra_categories = "Settings;DesktopSettings;X-XFCE-SettingsDialog;X-XFCE-SystemSettings;X-GNOME-Settings-Panel;"

        exec_cmd = f"{info['pkg_name']} {info['exec_args']}" if info.get("exec_args") else info['pkg_name']

        desktop_content = dedent(f"""
        [Desktop Entry]
        Version=1.0
        Type=Application
        Name={info['display_name']}
        Comment={info['comment']}
        Exec={exec_cmd}
        Icon={icon_name_no_ext}
        StartupWMClass={info['pkg_name']}
        Categories={info['categories']}{extra_categories}
        Terminal=false
        """)
        for trad in info["traducciones_extra"]:
            lang = trad['lang']
            if trad['name']:
                desktop_content += f"Name[{lang}]={trad['name']}\n"
            if trad['comment']:
                desktop_content += f"Comment[{lang}]={trad['comment']}\n"
        with open(os.path.join(desktop_dir, f"{info['pkg_name']}.desktop"), "w") as f:
            f.write(desktop_content.strip())

        # 7. Copiar icono
        icon_dest_path = os.path.join(icon_dir, f"{icon_name_no_ext}{info['icon_ext']}")
        shutil.copy(info["icon_path"], icon_dest_path)
        if info['icon_ext'] == ".svg":
            svg_generic_dir = os.path.join(build_dir, "usr/share/icons/hicolor/scalable/apps")
            os.makedirs(svg_generic_dir, exist_ok=True)
            os.symlink(icon_dest_path, os.path.join(svg_generic_dir, f"{icon_name_no_ext}.svg"))

        # 8. Crear archivo AppStream
        if info["appstream_enabled"]:
            os.makedirs(metainfo_dir, exist_ok=True)
            
            # Renombrar capturas para AppStream (1.png, 2.png, ...)
            renamed_screenshots = []
            if info["appstream_screenshots"]:
                for i, src_path in enumerate(info["appstream_screenshots"]):
                    ext = os.path.splitext(src_path)[1]
                    renamed_screenshots.append(f"{i+1}{ext}")
            info["appstream_screenshots_renamed"] = renamed_screenshots

            appstream_content = self.generar_appstream_xml(info)
            appstream_file_path = os.path.join(metainfo_dir, f"{info['pkg_name']}.desktop.appdata.xml")
            with open(appstream_file_path, "w") as f:
                f.write(appstream_content)
            
            if info["appstream_screenshots"]:
                # Guardar en /usr/share/{pkg_name}/screenshots
                screenshots_dir = os.path.join(app_install_dir, "screenshots")
                os.makedirs(screenshots_dir, exist_ok=True)
                for i, src_path in enumerate(info["appstream_screenshots"]):
                    dst_name = renamed_screenshots[i]
                    shutil.copy(src_path, os.path.join(screenshots_dir, dst_name))
        
        GLib.idle_add(self.progress_bar.set_text, self._("Empaquetando con dpkg-deb..."))
        GLib.idle_add(self.progress_bar.pulse)
        
        proceso = subprocess.run(
            ["dpkg-deb", "--build", build_dir, save_path],
            capture_output=True, text=True
        )
        
        if proceso.returncode != 0:
            print(f"Error al crear el paquete DEB:\n{proceso.stderr}")
            raise Exception(f"Error de dpkg-deb:\n{proceso.stderr}")



    def generar_appstream_xml(self, info):
        """Genera el contenido del archivo XML de AppStream."""
        from xml.etree.ElementTree import Element, SubElement, tostring
        from xml.dom import minidom
        from datetime import datetime # Import datetime here

        component = Element("component", type="desktop-application")
        
        id_elem = SubElement(component, "id")
        id_elem.text = f"{info['pkg_name']}.desktop"
        
        name_elem = SubElement(component, "name")
        name_elem.text = info.get("appstream_name_main") or info["display_name"]
        
        summary_elem = SubElement(component, "summary")
        summary_elem.text = info.get("appstream_comment_main") or info["comment"]
        
        metadata = SubElement(component, "metadata_license")
        metadata.text = "CC0-1.0" # O la licencia que corresponda
        
        project_license = SubElement(component, "project_license")
        project_license.text = info.get("appstream_license") or "GPL-3.0-or-later"

        # Developer Name
        developer = SubElement(component, "developer_name")
        if info.get("appstream_developer_name"):
            developer.text = info["appstream_developer_name"]
        else:
            # Extract name from "Name <email>"
            maintainer_parts = info.get('maintainer', '').split('<')
            developer.text = maintainer_parts[0].strip() if maintainer_parts else "Unknown"

        # URL
        # Homepage
        website = info.get("appstream_homepage") or getattr(self, 'app_info', {}).get("website")
        if website:
            url = SubElement(component, "url", type="homepage")
            url.text = website

        # Bugtracker
        bugtracker = info.get("appstream_bugtracker")
        if bugtracker:
            url_bug = SubElement(component, "url", type="bugtracker")
            url_bug.text = bugtracker

        description = SubElement(component, "description")
        description.text = f"<p>{info['description']}</p>"

        # Content Rating (Requerido por GNOME Software)
        # Se añade un rating básico "oars-1.1" con todos los valores a "none" por defecto para cumplir requisitos
        content_rating = SubElement(component, "content_rating", type="oars-1.1")
        
        oars_attributes = [
            "violence-cartoon", "violence-fantasy", "violence-realistic", "violence-bloodshed", "violence-sexual",
            "drugs-alcohol", "drugs-narcotics", "drugs-tobacco", "sex-nudity", "sex-themes", "sex-homosexuality",
            "sex-prostitution", "sex-adultery", "language-profanity", "language-humor", "language-discrimination",
            "social-chat", "social-info", "social-audio", "social-location", "social-contacts", "money-purchasing",
            "money-gambling"
        ]
        
        for attr in oars_attributes:
            content_attribute = SubElement(content_rating, "content_attribute", id=attr)
            content_attribute.text = "none"

        # Icono
        icon_elem = SubElement(component, "icon", type="stock")
        icon_elem.text = info['pkg_name']

        # Información de la versión
        releases = SubElement(component, "releases")
        release = SubElement(releases, "release", version=info["pkg_version"], date= datetime.now().strftime("%Y-%m-%d"))
        release_desc = SubElement(release, "description")
        release_desc.text = f"<p>{self._('Lanzamiento inicial.')}</p>"

        # Capturas de pantalla
        # Usar la lista renombrada si existe, sino la original (fallback)
        screenshots_list = info.get("appstream_screenshots_renamed", info["appstream_screenshots"])
        
        if screenshots_list:
            screenshots = SubElement(component, "screenshots")
            for i, screenshot_item in enumerate(screenshots_list):
                screenshot = SubElement(screenshots, "screenshot", type="default" if i == 0 else "extra")
                image = SubElement(screenshot, "image", type="source")
                
                # Si viene de la lista renombrada, es solo el nombre de archivo
                # Si viene de la original, es la ruta completa
                filename = os.path.basename(screenshot_item)
                
                image.text = f"/usr/share/{info['pkg_name']}/screenshots/{filename}"

        # Lanzable
        launchable = SubElement(component, "launchable", type="desktop-id")
        launchable.text = f"{info['pkg_name']}.desktop"

        # Provides (Para que GNOME Software sepa qué binario provee este componente)
        provides = SubElement(component, "provides")
        binary = SubElement(provides, "binary")
        binary.text = info['pkg_name']

        # Traducciones
        if info["traducciones_extra"]:
            for trad in info["traducciones_extra"]:
                lang = trad['lang']
                
                # Use appstream-specific name/comment if available, otherwise fallback to desktop ones
                appstream_name_text = trad.get('appstream_name') or trad.get('name')
                appstream_comment_text = trad.get('appstream_comment') or trad.get('comment')

                if appstream_name_text:
                    name_lang = SubElement(component, "name", {"xml:lang": lang})
                    name_lang.text = appstream_name_text
                if appstream_comment_text:
                    summary_lang = SubElement(component, "summary", {"xml:lang": lang})
                    summary_lang.text = appstream_comment_text

        xml_str = tostring(component, "utf-8")
        pretty_xml_str = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        return pretty_xml_str


    def on_add_screenshot_clicked(self, widget):
        """Abre un diálogo para seleccionar capturas de pantalla."""
        dialog = Gtk.FileChooserDialog(
            title=self._("Seleccionar capturas de pantalla"),
            parent=self,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        dialog.set_select_multiple(True)
        filter_img = Gtk.FileFilter()
        filter_img.set_name(self._("Imágenes"))
        filter_img.add_mime_type("image/png")
        filter_img.add_mime_type("image/jpeg")
        dialog.add_filter(filter_img)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            files = dialog.get_filenames()
            for file in files:
                if file not in self.screenshots_list:
                    self.screenshots_list.append(file)
            self._refresh_screenshots_list()
        dialog.destroy()

    def on_remove_screenshot_clicked(self, widget):
        """Elimina la captura de pantalla seleccionada."""
        selected_children = self.flowbox_screenshots.get_selected_children()
        if selected_children:
            selected_widget = selected_children[0]
            card_widget = selected_widget.get_child() # Obtener el Gtk.Box que contiene la ruta
            file_path = card_widget.file_path # Usar el atributo personalizado
            if file_path in self.screenshots_list:
                self.screenshots_list.remove(file_path)
                self._refresh_screenshots_list()
                self.btn_remove_screenshot.set_sensitive(False)

    def _create_screenshot_card(self, file_path):
        """Crea una tarjeta de vista previa para una captura de pantalla."""
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        card.set_margin_top(5)
        card.set_margin_bottom(5)
        card.set_margin_start(5)
        card.set_margin_end(5)
        card.file_path = file_path # Guardar la ruta para referencia

        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_size(file_path, 128, 72) # 16:9 aspect ratio
            image = Gtk.Image.new_from_pixbuf(pixbuf)
        except GLib.Error:
            image = Gtk.Image.new_from_icon_name("image-missing", Gtk.IconSize.DIALOG)
        
        card.pack_start(image, True, True, 0)

        label = Gtk.Label(label=os.path.basename(file_path))
        label.set_max_width_chars(20)
        label.set_ellipsize(3) # Pango.EllipsizeMode.END
        card.pack_start(label, False, False, 0)
        
        return card

    def _refresh_screenshots_list(self):
        """Actualiza el FlowBox de capturas de pantalla."""
        # Limpiar el flowbox
        for child in self.flowbox_screenshots.get_children():
            self.flowbox_screenshots.remove(child)

        if not self.screenshots_list:
            # (Opcional) Mostrar un label si está vacío
            pass
        else:
            for file_path in sorted(self.screenshots_list):
                card = self._create_screenshot_card(file_path)
                self.flowbox_screenshots.add(card)
        
        self.flowbox_screenshots.show_all()
