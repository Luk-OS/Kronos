import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

def crear_label_titulo(texto, _):
    """Helper para crear etiquetas de título de sección."""
    label = Gtk.Label()
    # Usar Pango markup para negrita
    label.set_markup(f"<b>{_(texto)}</b>")
    label.set_halign(Gtk.Align.START)
    return label

def mostrar_error(parent, titulo, mensaje, _):
    dialog = Gtk.MessageDialog(
        transient_for=parent,
        flags=0,
        message_type=Gtk.MessageType.ERROR,
        buttons=Gtk.ButtonsType.CANCEL,
        text=_(titulo),
    )
    dialog.format_secondary_text(_(mensaje))
    dialog.run()
    dialog.destroy()

def mostrar_info(parent, titulo, mensaje, _):
    dialog = Gtk.MessageDialog(
        transient_for=parent,
        flags=0,
        message_type=Gtk.MessageType.INFO,
        buttons=Gtk.ButtonsType.OK,
        text=_(titulo),
    )
    dialog.format_secondary_text(_(mensaje))
    dialog.run()
    dialog.destroy()
