import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib
import requests
import json
import threading

# --- Diálogo de Traducción ---
class TranslationDialog(Gtk.Dialog):
    """Diálogo para añadir una nueva traducción."""
    
    def __init__(self, parent_window, api_key, original_name, original_comment, _):
        super().__init__(title=_("Añadir Traducción"), transient_for=parent_window, flags=0)
        self._ = _
        self.api_key = api_key
        self.original_name = original_name
        self.original_comment = original_comment
        
        self.set_modal(True)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_ADD, Gtk.ResponseType.OK
        )
        self.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(self._("Cancelar"))
        self.get_widget_for_response(Gtk.ResponseType.OK).set_label(self._("Añadir"))
        self.set_default_size(450, 180)
        
        content_area = self.get_content_area()
        self.grid = Gtk.Grid(column_spacing=10, row_spacing=10, margin=15)
        content_area.add(self.grid)

        # Código de Idioma
        self.label_lang_code = Gtk.Label(label=self._("Código Idioma (ej: 'en', 'pt', 'fr'):"))
        self.grid.attach(self.label_lang_code, 0, 0, 1, 1)
        
        hbox_lang = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        self.entry_lang_code = Gtk.Entry()
        self.entry_lang_code.set_placeholder_text("en")
        hbox_lang.pack_start(self.entry_lang_code, True, True, 0)
        
        # Botón Generar con Gemini
        self.btn_gemini = Gtk.Button.new_from_icon_name("system-search-symbolic", Gtk.IconSize.BUTTON)
        self.btn_gemini.set_tooltip_text(self._("Generar traducción con Gemini"))
        self.btn_gemini.connect("clicked", self.on_generate_clicked)
        if not self.api_key:
            self.btn_gemini.set_sensitive(False)
            self.btn_gemini.set_tooltip_text(self._("Configura la API Key de Gemini en Ajustes para usar esta función"))
        hbox_lang.pack_start(self.btn_gemini, False, False, 0)
        
        self.grid.attach(hbox_lang, 1, 0, 1, 1)
        
        # Spinner para carga
        self.spinner = Gtk.Spinner()
        hbox_lang.pack_start(self.spinner, False, False, 0)

        # Nombre
        self.label_name = Gtk.Label(label=self._("Nombre Traducido:"))
        self.grid.attach(self.label_name, 0, 1, 1, 1)
        self.entry_name = Gtk.Entry()
        self.entry_name.set_placeholder_text(self._("Mi App"))
        self.grid.attach(self.entry_name, 1, 1, 1, 1)

        # Descripción
        self.label_comment = Gtk.Label(label=self._("Descripción Traducida:"))
        self.grid.attach(self.label_comment, 0, 2, 1, 1)
        self.entry_comment = Gtk.Entry()
        self.entry_comment.set_placeholder_text(self._("Una descripción corta"))
        self.grid.attach(self.entry_comment, 1, 2, 1, 1)

        self.show_all()

    def update_ui_for_language(self, _):
        """Actualiza todos los textos de la UI al idioma actual."""
        self._ = _
        self.set_title(self._("Añadir Traducción"))
        self.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(self._("Cancelar"))
        self.get_widget_for_response(Gtk.ResponseType.OK).set_label(self._("Añadir"))
        self.label_lang_code.set_label(self._("Código Idioma (ej: 'en', 'pt', 'fr'):"))
        self.label_name.set_label(self._("Nombre Traducido:"))
        self.entry_name.set_placeholder_text(self._("Mi App"))
        self.label_comment.set_label(self._("Descripción Traducida:"))
        self.entry_comment.set_placeholder_text(self._("Una descripción corta"))
        print("TranslationDialog UI updated for new language.")

    def get_translation(self):
        """Devuelve los datos de la traducción."""
        return {
            'lang': self.entry_lang_code.get_text().strip(),
            'name': self.entry_name.get_text(),
            'comment': self.entry_comment.get_text()
        }

    def on_generate_clicked(self, widget):
        """Inicia la generación de traducción en un hilo."""
        lang_code = self.entry_lang_code.get_text().strip()
        if not lang_code:
            # Mostrar error (podríamos usar un label de estado o un diálogo)
            print("Error: Código de idioma vacío")
            return

        self.btn_gemini.set_sensitive(False)
        self.spinner.start()
        
        thread = threading.Thread(target=self.generate_translation_thread, args=(lang_code,))
        thread.daemon = True
        thread.start()

    def generate_translation_thread(self, lang_code):
        """Llama a la API de Gemini."""
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={self.api_key}"
            headers = {'Content-Type': 'application/json'}
            
            prompt = f"""
            Translate the following app metadata to language code '{lang_code}'.
            Return ONLY a JSON object with keys: "name", "comment".
            
            Original Name: "{self.original_name}"
            Original Comment: "{self.original_comment}"
            """
            
            data = {
                "contents": [{
                    "parts": [{"text": prompt}]
                }]
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            text_response = result['candidates'][0]['content']['parts'][0]['text']
            
            # Limpiar markdown si Gemini lo incluye
            text_response = text_response.replace('```json', '').replace('```', '').strip()
            
            translation = json.loads(text_response)
            
            GLib.idle_add(self.on_generation_success, translation)
            
        except Exception as e:
            print(f"Error Gemini: {e}")
            GLib.idle_add(self.on_generation_error, str(e))

    def on_generation_success(self, translation):
        """Actualiza la UI con la traducción."""
        self.spinner.stop()
        self.btn_gemini.set_sensitive(True)
        
        if 'name' in translation:
            self.entry_name.set_text(translation['name'])
                
        if 'comment' in translation:
            self.entry_comment.set_text(translation['comment'])

    def on_generation_error(self, error_msg):
        """Muestra error en la UI."""
        self.spinner.stop()
        self.btn_gemini.set_sensitive(True)
        print(f"Error de generación: {error_msg}")
        # Aquí podrías mostrar un diálogo de error si quisieras
