import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

# --- Diálogo de Configuración ---
class SettingsDialog(Gtk.Dialog):
    """Diálogo para configurar el mantenedor por defecto."""
    
    def __init__(self, parent_window, current_name, current_email, current_api_key, _):
        super().__init__(title=_("Configuración"), transient_for=parent_window, flags=0)
        self._ = _
        self.set_modal(True)
        self.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        self.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(_("Cancelar"))
        self.get_widget_for_response(Gtk.ResponseType.OK).set_label(_("Guardar"))

        self.set_default_size(400, 150)
        
        content_area = self.get_content_area()
        self.grid = Gtk.Grid(column_spacing=10, row_spacing=10, margin=15)
        content_area.add(self.grid)

        # Nombre
        self.label_name = Gtk.Label(label=self._("Nombre Mantenedor:"))
        self.label_name.set_halign(Gtk.Align.START)
        self.entry_maintainer_name = Gtk.Entry()
        self.entry_maintainer_name.set_text(current_name)
        self.entry_maintainer_name.set_placeholder_text(self._("Tu Nombre"))
        self.entry_maintainer_name.set_hexpand(True)
        self.grid.attach(self.label_name, 0, 0, 1, 1)
        self.grid.attach(self.entry_maintainer_name, 1, 0, 1, 1)

        # Email
        self.label_email = Gtk.Label(label=self._("Correo Mantenedor:"))
        self.label_email.set_halign(Gtk.Align.START)
        self.entry_maintainer_email = Gtk.Entry()
        self.entry_maintainer_email.set_text(current_email)
        self.entry_maintainer_email.set_placeholder_text(self._("tu@email.com"))
        self.entry_maintainer_email.set_hexpand(True)
        self.grid.attach(self.label_email, 0, 1, 1, 1)
        self.grid.attach(self.entry_maintainer_email, 1, 1, 1, 1)

        # Gemini API Key
        self.label_api_key = Gtk.Label(label=self._("Gemini API Key:"))
        self.label_api_key.set_halign(Gtk.Align.START)
        self.entry_api_key = Gtk.Entry()
        self.entry_api_key.set_text(current_api_key)
        self.entry_api_key.set_placeholder_text("AIzaSy...")
        self.entry_api_key.set_visibility(False) # Hide characters
        self.entry_api_key.set_hexpand(True)
        self.grid.attach(self.label_api_key, 0, 2, 1, 1)
        self.grid.attach(self.entry_api_key, 1, 2, 1, 1)
        
        self.show_all()

    def update_ui_for_language(self, _):
        """Actualiza todos los textos de la UI al idioma actual."""
        self._ = _
        self.set_title(self._("Configuración"))
        self.get_widget_for_response(Gtk.ResponseType.CANCEL).set_label(self._("Cancelar"))
        self.get_widget_for_response(Gtk.ResponseType.OK).set_label(self._("Guardar"))
        self.label_name.set_label(self._("Nombre Mantenedor:"))
        self.entry_maintainer_name.set_placeholder_text(self._("Tu Nombre"))
        self.label_email.set_label(self._("Correo Mantenedor:"))
        self.entry_maintainer_email.set_placeholder_text(self._("tu@email.com"))
        self.label_api_key.set_label(self._("Gemini API Key:"))
        print("SettingsDialog UI updated for new language.")

    def get_settings(self):
        """Devuelve el nombre, email y api key."""
        return self.entry_maintainer_name.get_text(), self.entry_maintainer_email.get_text(), self.entry_api_key.get_text()
