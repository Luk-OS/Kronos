import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, Gdk
import os

class AboutDialog(Gtk.Dialog):
    def __init__(self, parent, app_info, config_data, _):
        super().__init__(title=_("Acerca de"), transient_for=parent, flags=0)
        self.set_modal(True)
        self.set_default_size(300, 250) # Tamaño compacto
        self.set_resizable(False)
        self._ = _

        # Estilo CSS eliminado para usar tema GTK
        
        box = self.get_content_area()
        # box.get_style_context().add_class("about-box") # Removed custom class
        
        # Contenedor principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(20)
        main_box.set_margin_end(20)
        box.add(main_box)

        # 1. Logo y Título
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        header_box.set_halign(Gtk.Align.CENTER)
        main_box.pack_start(header_box, False, False, 0)

        # Logo
        try:
            logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'logo.png')
            if os.path.exists(logo_path):
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(logo_path, 64, 64, True)
                image = Gtk.Image.new_from_pixbuf(pixbuf)
                header_box.pack_start(image, False, False, 0)
            else:
                icon_name = app_info.get("logo_icon_name", "application-x-deb")
                image = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
                image.set_pixel_size(64)
                header_box.pack_start(image, False, False, 0)
        except Exception as e:
            print(f"Error cargando logo en About: {e}")

        # Info (Titulo + Version)
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info_box.set_valign(Gtk.Align.CENTER)
        header_box.pack_start(info_box, False, False, 0)

        label_title = Gtk.Label(label=_("Luk-Os Debify"))
        label_title.get_style_context().add_class("about-title")
        label_title.set_halign(Gtk.Align.START)
        info_box.pack_start(label_title, False, False, 0)

        version = app_info.get("version", "1.0.0")
        label_version = Gtk.Label(label=f"v{version}")
        label_version.get_style_context().add_class("about-version")
        label_version.set_halign(Gtk.Align.START)
        info_box.pack_start(label_version, False, False, 0)

        # 2. Descripción
        desc_text = _("Una herramienta simple y elegante\npara crear paquetes .deb y .rpm.")
        label_desc = Gtk.Label(label=desc_text)
        label_desc.set_justify(Gtk.Justification.CENTER)
        label_desc.get_style_context().add_class("about-desc")
        main_box.pack_start(label_desc, False, False, 5)

        # 3. Créditos / Autor
        label_credits = Gtk.Label()
        label_credits.set_markup(f"<small><b>2026 {self._('Creado por Aprende con Sthip')}</b>\n{self._('Potenciado por Gemini')}</small>")
        label_credits.set_justify(Gtk.Justification.CENTER)
        main_box.pack_start(label_credits, False, False, 5)

        # 4. Website Link - REMOVED
        # website = app_info.get("website", "https://github.com/sthip/luk-os-debify")
        # link_button = Gtk.LinkButton.new_with_label(website, _("Visitar Sitio Web"))
        # link_button.get_style_context().add_class("about-link")
        # main_box.pack_start(link_button, False, False, 0)

        # Botón Cerrar (Oculto en el header bar si se usa, pero aquí lo ponemos abajo para ser explícitos si se quiere, 
        # aunque GtkDialog ya suele tener botones. Vamos a usar el area de acción para un botón simple)
        
        # Eliminamos los botones estándar del GtkDialog para hacerlo más custom
        # self.get_action_area().hide() # Esto a veces da problemas con el layout
        
        # Vamos a añadir un botón de cierre personalizado más bonito
        btn_close = Gtk.Button(label=_("Cerrar"))
        btn_close.connect("clicked", lambda x: self.response(Gtk.ResponseType.CLOSE))
        btn_close.set_halign(Gtk.Align.CENTER)
        btn_close.set_size_request(100, -1)
        main_box.pack_end(btn_close, False, False, 10)

        self.show_all()
