import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

class TestWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Test Style")
        self.set_default_size(400, 300)
        self.set_border_width(10)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(vbox)

        # CSS Provider
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"""
        entry, textview {
            padding: 5px;
            border: 1px solid red; /* Red border to make it obvious */
            border-radius: 3px;
            background-color: white;
        }
        """)
        screen = Gdk.Screen.get_default()
        style_context = Gtk.StyleContext()
        style_context.add_provider_for_screen(screen, css_provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        # Entry (Reference)
        entry = Gtk.Entry()
        entry.set_text("Entry (Reference)")
        vbox.pack_start(entry, False, False, 0)

        # TextView in ScrolledWindow (Default Shadow)
        label1 = Gtk.Label(label="TextView in ScrolledWindow (Default Shadow)")
        vbox.pack_start(label1, False, False, 0)
        
        sw1 = Gtk.ScrolledWindow()
        sw1.set_min_content_height(80)
        tv1 = Gtk.TextView()
        tv1.get_buffer().set_text("Content...")
        sw1.add(tv1)
        vbox.pack_start(sw1, False, False, 0)

        # TextView in ScrolledWindow (Shadow NONE)
        label2 = Gtk.Label(label="TextView in ScrolledWindow (Shadow NONE)")
        vbox.pack_start(label2, False, False, 0)

        sw2 = Gtk.ScrolledWindow()
        sw2.set_shadow_type(Gtk.ShadowType.NONE)
        sw2.set_min_content_height(80)
        tv2 = Gtk.TextView()
        tv2.get_buffer().set_text("Content...")
        sw2.add(tv2)
        vbox.pack_start(sw2, False, False, 0)

window = TestWindow()
window.connect("destroy", Gtk.main_quit)
window.show_all()
Gtk.main()
