#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
EmpaquetadorDebianGTK: Una herramienta gráfica simple para crear
paquetes .deb de aplicaciones.
"""

import sys
import os
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import locale # Importar el módulo locale

# Establecer el locale del sistema para que GTK+ pueda traducir sus propios widgets
locale.setlocale(locale.LC_ALL, '')

# Añadir el directorio src al path para poder importar los módulos
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from main_window import EmpaquetadorApp

# --- Punto de Entrada ---
if __name__ == "__main__":
    try:
        app = EmpaquetadorApp()
        app.connect("destroy", Gtk.main_quit)
        Gtk.main()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        # En caso de un error crítico al inicio (ej: GTK no instalado)
        # Imprimir en la terminal
        print("Error crítico al iniciar la aplicación:")
        print(e)
