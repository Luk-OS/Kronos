Paquete que aplica branding completo de Luk-OS (Kronos) sobre Devuan.
Incluye os-release, lsb-release, issue, motd, hostnamectl y GRUB.
