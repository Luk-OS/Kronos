# Luk-OS Branding Package

Este paquete aplica el branding oficial de Luk-OS GNU/Linux.

Cambia /etc/os-release, /etc/motd, fastfetch y bloquea base-files de Devuan.

Mantenido por: Aprende con Sthip <aprendeconsthip@gmail.com>
