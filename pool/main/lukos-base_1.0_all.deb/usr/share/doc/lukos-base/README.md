# Luk-OS Kronos Branding Package

Este paquete aplica el branding oficial de Luk-OS GNU/Linux Kronos.

Cambia /etc/os-release, motd y mantiene compatibilidad con Devuan.

Mantenido por: Aprende con Sthip <aprendeconsthip@gmail.com>
