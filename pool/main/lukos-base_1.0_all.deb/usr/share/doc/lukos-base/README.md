# Luk-OS Kronos Branding Package

Este paquete aplica el branding completo de Luk-OS GNU/Linux Kronos sobre Devuan.

- Modifica /etc/os-release
- Actualiza el mensaje de bienvenida
- Configura Fastfetch para mostrar Luk-OS Kronos
- Mantiene ID=devuan para compatibilidad con repos oficiales

Mantenido por: Aprende con Sthip <aprendeconsthip@gmail.com>
