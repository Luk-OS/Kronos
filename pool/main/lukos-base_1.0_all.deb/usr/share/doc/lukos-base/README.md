Paquete que aplica branding completo de Luk-OS 26 (Kronos) alpha-1 sobre Devuan.
Mantiene ID=devuan y codename original para compatibilidad.
Incluye os-release, lsb-release, issue, motd, hostnamectl y GRUB.
