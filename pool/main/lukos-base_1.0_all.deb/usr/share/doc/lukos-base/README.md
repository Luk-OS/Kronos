# Luk-OS Branding Package

Este paquete aplica el branding oficial de **Luk-OS GNU/Linux**, basado en Devuan.

- Cambia el nombre de la distribución
- Actualiza /etc/os-release
- Configura /etc/motd
- Aplica compatibilidad con fastfetch
- Bloquea actualizaciones de base-files desde Devuan

Mantenido por: Aprende con Sthip <aprendeconsthip@gmail.com>
