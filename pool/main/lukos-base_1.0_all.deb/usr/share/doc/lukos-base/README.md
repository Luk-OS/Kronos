# Luk-OS Kronos Branding Package

Este paquete aplica el branding completo de Luk-OS GNU/Linux Kronos sobre Devuan:

- /etc/os-release
- /etc/lsb-release
- /etc/issue
- /etc/motd
- hostnamectl
- /etc/default/grub

Mantiene ID=devuan para compatibilidad con repos oficiales.

Mantenido por: Aprende con Sthip <aprendeconsthip@gmail.com>
