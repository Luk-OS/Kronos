Paquete que aplica branding completo de Luk-OS 26 (Kronos) -Alphav1 sobre Devuan.
Mantiene ID=devuan y codename original para compatibilidad.
Incluye os-release, lsb-release, issue, motd, hostnamectl y GRUB.
