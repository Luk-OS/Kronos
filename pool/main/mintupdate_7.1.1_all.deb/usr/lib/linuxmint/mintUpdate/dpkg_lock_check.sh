#!/bin/sh
/bin/fuser /var/lib/dpkg/lock