import os
import locale
from utils.translations import Translations

print("--- Environment ---")
print(f"LANG: {os.environ.get('LANG')}")
print(f"LANGUAGE: {os.environ.get('LANGUAGE')}")
try:
    print(f"locale.getdefaultlocale(): {locale.getdefaultlocale()}")
except Exception as e:
    print(f"locale.getdefaultlocale() error: {e}")

t = Translations()
print(f"Initial lang: {t.lang}")

print("--- Setting language to 'auto' ---")
# Force set to something else first to verify change
t.lang = "it"
print(f"Lang set to 'it' manually: {t.lang}")

t.set_language("auto")
print(f"Lang after set_language('auto'): {t.lang}")

if t.lang == "en" and "es" in t.STRINGS:
    print("FAILURE: Defaulted to English despite Spanish being available")
else:
    print(f"SUCCESS: Detected language correctly as {t.lang}")
