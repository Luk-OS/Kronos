import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Notify', '0.7')
import os
from gi.repository import Gtk, GLib, Notify, GdkPixbuf

from utils.translations import Translations

from ui.settings_dialog import SettingsDialog
from ui.css_manager import CSSManager

class UpdateWindow(Gtk.Window):
    def __init__(self, translations, apt_manager):
        super().__init__(title=translations.get("app_name"))
        self.set_default_size(700, 450) # Horizontal layout
        self.set_position(Gtk.WindowPosition.CENTER)
        self.translations = translations
        self.apt_manager = apt_manager
        
        # Load Icon
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(current_dir)
        self.logo_path = os.path.join(project_root, "assets", "logo.png")
        
        if os.path.exists(self.logo_path):
            try:
                self.set_icon_from_file(self.logo_path)
            except Exception as e:
                print(f"Error loading icon: {e}")
        
        # Load CSS
        CSSManager.load_css()
        
        # Initialize Notify
        Notify.init(self.translations.get("app_name"))
        
        # Main Layout
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(vbox)

        # Top Bar (Toolbar)
        self.top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.top_bar.get_style_context().add_class("top-bar")
        self.top_bar.set_margin_top(5)
        self.top_bar.set_margin_bottom(5)
        self.top_bar.set_margin_start(10)
        self.top_bar.set_margin_end(10)
        vbox.pack_start(self.top_bar, False, False, 0)

        # Install Button
        self.btn_install = Gtk.Button(label=self.translations.get("install_updates"))
        self.btn_install.get_style_context().add_class("suggested-action")
        self.btn_install.connect("clicked", self.on_install_clicked)
        self.btn_install.set_sensitive(False)
        self.top_bar.pack_start(self.btn_install, False, False, 0)
        
        # Menu Button
        self.menu_button = Gtk.MenuButton()
        icon = Gtk.Image.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.MENU)
        self.menu_button.set_image(icon)
        self.top_bar.pack_end(self.menu_button, False, False, 0)
        
        self.popover = Gtk.Popover()
        self.menu_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.menu_box.set_margin_top(10)
        self.menu_box.set_margin_bottom(10)
        self.menu_box.set_margin_start(10)
        self.menu_box.set_margin_end(10)
        
        # Menu Items - Store references for language updates
        self.btn_autoremove = Gtk.ModelButton(label=self.translations.get("auto_remove"))
        self.btn_autoremove.connect("clicked", self.on_autoremove_clicked)
        self.menu_box.pack_start(self.btn_autoremove, False, False, 0)
        
        self.btn_autoclean = Gtk.ModelButton(label=self.translations.get("auto_clean"))
        self.btn_autoclean.connect("clicked", self.on_autoclean_clicked)
        self.menu_box.pack_start(self.btn_autoclean, False, False, 0)
        
        self.menu_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 5)
        
        self.btn_settings = Gtk.ModelButton(label=self.translations.get("settings"))
        self.btn_settings.connect("clicked", self.on_settings_clicked)
        self.menu_box.pack_start(self.btn_settings, False, False, 0)
        
        self.btn_about = Gtk.ModelButton(label=self.translations.get("about"))
        self.btn_about.connect("clicked", self.on_about_clicked)
        self.menu_box.pack_start(self.btn_about, False, False, 0)
        
        self.menu_box.show_all()
        self.popover.add(self.menu_box)
        self.menu_button.set_popover(self.popover)
        
        # Stack for different states (Checking, Updates, UpToDate)
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        vbox.pack_start(self.stack, True, True, 0)
        
        # 1. Checking View
        self.box_checking = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.box_checking.set_valign(Gtk.Align.CENTER)
        self.spinner = Gtk.Spinner()
        self.spinner.start()
        self.spinner.set_size_request(128, 128) # Increased to 128
        self.spinner.set_tooltip_text(self.translations.get("app_name"))
        self.box_checking.pack_start(self.spinner, False, False, 0)
        self.lbl_checking = Gtk.Label(label=self.translations.get("checking"))
        self.box_checking.pack_start(self.lbl_checking, False, False, 0)
        self.stack.add_named(self.box_checking, "checking")
        
        # 2. Updates View
        self.box_updates = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        
        # Package List (ListBox for Cards)
        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        self.listbox.set_header_func(self.listbox_header_func)
        
        scrolled_list = Gtk.ScrolledWindow()
        scrolled_list.set_min_content_height(300)
        scrolled_list.add(self.listbox)
        self.box_updates.pack_start(scrolled_list, True, True, 0)
        
        self.stack.add_named(self.box_updates, "updates")
        
        # 3. Up To Date View
        self.box_uptodate = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.box_uptodate.set_valign(Gtk.Align.CENTER)
        icon_ok = Gtk.Image.new_from_icon_name("object-select-symbolic", Gtk.IconSize.DIALOG)
        icon_ok.set_pixel_size(128) # Increased to 128
        icon_ok.set_tooltip_text(self.translations.get("app_name"))
        self.box_uptodate.pack_start(icon_ok, False, False, 0)
        lbl_ok = Gtk.Label(label=self.translations.get("system_updated_title"))
        lbl_ok.get_style_context().add_class("title-label")
        self.box_uptodate.pack_start(lbl_ok, False, False, 0)
        lbl_msg = Gtk.Label(label=self.translations.get("system_updated_msg"))
        lbl_msg.get_style_context().add_class("status-label")
        self.box_uptodate.pack_start(lbl_msg, False, False, 0)
        self.stack.add_named(self.box_uptodate, "uptodate")
        
        # Progress Bar (Hidden by default, shown during operations)
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(True)
        self.progress_bar.set_text("")
        self.progress_bar.set_no_show_all(True)
        vbox.pack_start(self.progress_bar, False, False, 5)
        
        # Terminal Output (Collapsed by default)
        self.expander = Gtk.Expander(label=self.translations.get("terminal_output"))
        self.expander.set_expanded(False)  # Collapsed by default
        self.textview = Gtk.TextView()
        self.textview.set_editable(False)
        self.textview.set_cursor_visible(False)
        scrolled_text = Gtk.ScrolledWindow()
        scrolled_text.set_min_content_height(150)
        scrolled_text.add(self.textview)
        self.expander.add(scrolled_text)
        vbox.pack_start(self.expander, False, False, 0)
        
        self.connect("delete-event", self.on_delete_event)
        self.connect("show", self.on_show)
    
    def update_status_title(self, status_text):
        # User requested to remove status text from window title
        app_name = self.translations.get("app_name")
        self.set_title(app_name)

    def update_translations(self):
        """Update all UI text with current language"""
        # Update button
        self.btn_install.set_label(self.translations.get("install_updates"))
        
        # Update menu items
        self.btn_autoremove.set_label(self.translations.get("auto_remove"))
        self.btn_autoclean.set_label(self.translations.get("auto_clean"))
        self.btn_settings.set_label(self.translations.get("settings"))
        self.btn_about.set_label(self.translations.get("about"))
        
        # Update expander
        self.expander.set_label(self.translations.get("terminal_output"))
        
        # Update window title
        self.set_title(self.translations.get("app_name"))
        
        # Update checking view label
        self.lbl_checking.set_label(self.translations.get("checking"))
        
        # Update current view text
        current_view = self.stack.get_visible_child_name()
        if current_view == "checking":
            self.update_status_title(self.translations.get("checking"))
        elif current_view == "uptodate":
            self.update_status_title(self.translations.get("up_to_date"))
            # Update the labels in uptodate view
            for child in self.box_uptodate.get_children():
                if isinstance(child, Gtk.Label):
                    style = child.get_style_context()
                    if style.has_class("title-label"):
                        child.set_label(self.translations.get("system_updated_title"))
                    elif style.has_class("status-label"):
                        child.set_label(self.translations.get("system_updated_msg"))
        elif current_view == "updates":
            # Don't call get_upgradable_packages() here as it blocks the UI
            # Just update the subtitle with a generic message
            self.update_status_title(self.translations.get("updates_available"))



    def listbox_header_func(self, row, before):
        if before:
            row.set_header(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))

    def on_show(self, widget):
        self.check_updates()
    
    def pulse_progress_bar(self):
        """Animate the progress bar with pulse effect"""
        self.progress_bar.pulse()
        return True  # Continue pulsing

    def check_updates(self):
        self.stack.set_visible_child_name("checking")
        self.update_status_title(self.translations.get("checking"))
        self.btn_install.set_sensitive(False)
        
        # Clear ListBox
        for child in self.listbox.get_children():
            self.listbox.remove(child)
        
        def callback(data):
            if data is None:
                # Finished
                packages = self.apt_manager.get_upgradable_packages()
                GLib.idle_add(self.update_ui_after_check, packages)
            # Ignore line output during check
        
        self.apt_manager.run_update(callback)

    def update_ui_after_check(self, packages):
        if packages:
            # Clear ListBox again to be safe
            for child in self.listbox.get_children():
                self.listbox.remove(child)
                
            for pkg in packages:
                # pkg is (name, old_version, new_version)
                row = self.create_package_row(pkg)
                self.listbox.add(row)
            
            self.listbox.show_all()
            self.stack.set_visible_child_name("updates")
            self.update_status_title(f"{len(packages)} {self.translations.get('updates_available')}")
            self.btn_install.set_sensitive(True)
        else:
            self.stack.set_visible_child_name("uptodate")
            self.update_status_title(self.translations.get("up_to_date"))
            self.btn_install.set_sensitive(False)

    def create_package_row(self, pkg_info):
        name, old_ver, new_ver = pkg_info
        
        row = Gtk.ListBoxRow()
        row.set_selectable(False)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.get_style_context().add_class("package-card")
        box.set_margin_top(5)
        box.set_margin_bottom(5)
        box.set_margin_start(10)
        box.set_margin_end(10)
        
        # Name
        lbl_name = Gtk.Label(label=name, xalign=0)
        lbl_name.get_style_context().add_class("package-name")
        box.pack_start(lbl_name, False, False, 0)
        
        # Version Info
        version_text = f"{old_ver} -> {new_ver}"
        lbl_ver = Gtk.Label(label=version_text, xalign=0)
        lbl_ver.get_style_context().add_class("package-version")
        box.pack_start(lbl_ver, False, False, 0)
        
        row.add(box)
        return row

    def on_install_clicked(self, widget):
        self.btn_install.set_sensitive(False)
        self.textview.get_buffer().set_text("")
        self.append_text(f"--- {self.translations.get('installing')} ---\n")
        
        # Don't show progress bar yet, wait for first output
        self.progress_started = False
        
        def callback(data):
            if data is None:
                # Finished
                if self.progress_started:
                    self.progress_bar.hide()
                    self.progress_started = False
                # Show completion notification - Disabled by user request
                # self.show_completion_notification(
                #     self.translations.get('updates_completed_title'),
                #     self.translations.get('updates_completed_msg')
                # )
                GLib.idle_add(self.check_updates) # Re-check after install
            else:
                line, progress = data
                self.append_text(line)
                
                # Show progress bar on first output
                if not self.progress_started:
                    self.progress_started = True
                    GLib.idle_add(self._show_progress_bar, self.translations.get('installing'))
                
                # Update progress if available
                if progress is not None:
                    GLib.idle_add(self._update_progress, progress)
                else:
                    # Pulse if no specific progress
                    GLib.idle_add(self.progress_bar.pulse)
        
        self.apt_manager.run_upgrade(callback)

    def on_autoremove_clicked(self, widget):
        self.popover.popdown()
        self.textview.get_buffer().set_text("")
        self.append_text(f"--- {self.translations.get('auto_remove')} ---\n")
        
        # Don't show progress bar yet, wait for first output
        self.progress_started = False
        
        def callback(data):
            if data is None:
                # Finished
                if self.progress_started:
                    self.progress_bar.hide()
                    self.progress_started = False
                # Show completion notification
                self.show_completion_notification(
                    self.translations.get('autoremove_completed_title'),
                    self.translations.get('autoremove_completed_msg')
                )
            else:
                line, progress = data
                self.append_text(line)
                
                # Show progress bar on first output
                if not self.progress_started:
                    self.progress_started = True
                    GLib.idle_add(self._show_progress_bar, self.translations.get('auto_remove'))
                
                # Update progress if available
                if progress is not None:
                    GLib.idle_add(self._update_progress, progress)
                else:
                    # Pulse if no specific progress
                    GLib.idle_add(self.progress_bar.pulse)
        
        self.apt_manager.run_autoremove(callback)

    def on_autoclean_clicked(self, widget):
        self.popover.popdown()
        self.textview.get_buffer().set_text("")
        self.append_text(f"--- {self.translations.get('auto_clean')} ---\n")
        
        # Don't show progress bar yet, wait for first output
        self.progress_started = False
        
        def callback(data):
            if data is None:
                # Finished
                if self.progress_started:
                    self.progress_bar.hide()
                    self.progress_started = False
                # Show completion notification
                self.show_completion_notification(
                    self.translations.get('autoclean_completed_title'),
                    self.translations.get('autoclean_completed_msg')
                )
            else:
                line, progress = data
                self.append_text(line)
                
                # Show progress bar on first output
                if not self.progress_started:
                    self.progress_started = True
                    GLib.idle_add(self._show_progress_bar, self.translations.get('auto_clean'))
                
                # Update progress if available
                if progress is not None:
                    GLib.idle_add(self._update_progress, progress)
                else:
                    # Pulse if no specific progress
                    GLib.idle_add(self.progress_bar.pulse)
        
        self.apt_manager.run_autoclean(callback)

    def on_settings_clicked(self, widget):
        self.popover.popdown()
        dialog = SettingsDialog(self, self.translations)
        dialog.run()
        dialog.destroy()

    def on_about_clicked(self, widget):
        self.popover.popdown()
        
        dialog = Gtk.Dialog(title=self.translations.get("about"), transient_for=self, flags=0)
        dialog.add_button(self.translations.get("close"), Gtk.ResponseType.OK)
        
        # Content Area
        content_area = dialog.get_content_area()
        content_area.set_spacing(12)
        content_area.set_margin_top(20)
        content_area.set_margin_bottom(20)
        content_area.set_margin_start(40)
        content_area.set_margin_end(40)
        
        # Icon
        if os.path.exists(self.logo_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(self.logo_path, 80, 80, True)
                icon = Gtk.Image.new_from_pixbuf(pixbuf)
            except Exception as e:
                print(f"Error loading icon for about dialog: {e}")
                icon = Gtk.Image.new_from_icon_name("system-software-update", Gtk.IconSize.DIALOG)
                icon.set_pixel_size(80)
        else:
            icon = Gtk.Image.new_from_icon_name("system-software-update", Gtk.IconSize.DIALOG)
            icon.set_pixel_size(80)
            
        content_area.pack_start(icon, False, False, 0)
        
        # App Name
        lbl_name = Gtk.Label()
        lbl_name.set_markup(f"<span size='xx-large' weight='bold'>{self.translations.get('app_name')}</span>")
        content_area.pack_start(lbl_name, False, False, 0)
        
        # Version
        lbl_version = Gtk.Label(label="1.0")
        content_area.pack_start(lbl_version, False, False, 0)
        
        # Description
        lbl_desc = Gtk.Label(label=self.translations.get("about_msg"))
        lbl_desc.set_justify(Gtk.Justification.CENTER)
        lbl_desc.set_line_wrap(True)
        lbl_desc.set_max_width_chars(40)
        content_area.pack_start(lbl_desc, False, False, 10)
        
        # Author Link
        lbl_author = Gtk.Label()
        created_text = self.translations.get("created_by_text")
        author_name = self.translations.get("author_name")
        markup = f"{created_text} <a href='https://www.youtube.com/@AprendeconSthip'>{author_name}</a>"
        lbl_author.set_markup(markup)
        content_area.pack_start(lbl_author, False, False, 10)
        
        content_area.show_all()
        dialog.run()
        dialog.destroy()

    def append_text(self, text):
        GLib.idle_add(self._append_text_main_thread, text)

    def _append_text_main_thread(self, text):
        if text is None:
            return

        buffer = self.textview.get_buffer()
        end_iter = buffer.get_end_iter()
        buffer.insert(end_iter, text)
        mark = buffer.create_mark(None, end_iter, False)
        self.textview.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)

    def show_completion_notification(self, title, message):
        """Show a system notification when an operation completes"""
        icon = self.logo_path if os.path.exists(self.logo_path) else "system-software-update"
        notification = Notify.Notification.new(title, message, icon)
        notification.set_timeout(3000)  # 3 segundos
        notification.show()

    def _show_progress_bar(self, text):
        """Show the progress bar with initial text"""
        self.progress_bar.set_text(text)
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.show()

    def _update_progress(self, percentage):
        """Update progress bar with percentage"""
        fraction = percentage / 100.0
        self.progress_bar.set_fraction(fraction)
        self.progress_bar.set_text(f"{percentage}%")

    def on_delete_event(self, widget, event):
        self.hide()
        return True
