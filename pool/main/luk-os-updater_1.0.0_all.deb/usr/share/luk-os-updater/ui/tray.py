import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Notify', '0.7')
from gi.repository import Gtk, GLib, Notify
try:
    gi.require_version('AppIndicator3', '0.1')
    from gi.repository import AppIndicator3 as AppIndicator
except ValueError:
    try:
        gi.require_version('AyatanaAppIndicator3', '0.1')
        from gi.repository import AyatanaAppIndicator3 as AppIndicator
    except ValueError:
        print("Error: Neither AppIndicator3 nor AyatanaAppIndicator3 found.")
        print("Please install 'gir1.2-appindicator3-0.1' or 'gir1.2-ayatanaappindicator3-0.1'")
        exit(1)
from utils.apt_manager import APTManager
from ui.window import UpdateWindow
import os

from utils.translations import Translations
from utils.config_manager import ConfigManager
from ui.settings_dialog import SettingsDialog

class SystemTray:
    def __init__(self, app_id, show_window=False):
        self.app_id = app_id
        self.translations = Translations()
        self.config_manager = ConfigManager()
        
        # Initialize Notify
        Notify.init(self.translations.get("app_name"))
        
        # Use updater.png from assets for Tray
        # Get absolute path relative to this file (ui/tray.py) -> ../assets/updater.png
        current_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(current_dir)
        icon_path = os.path.join(project_root, "assets", "updater.png")
        
        # Path for notification icon (same as window)
        self.logo_path = os.path.join(project_root, "assets", "logo.png")
        
        if not os.path.exists(icon_path):
            print(f"Warning: Icon not found at {icon_path}, using fallback.")
            icon_path = "system-software-update" # Fallback
            
        self.indicator = AppIndicator.Indicator.new(
            app_id,
            icon_path,
            AppIndicator.IndicatorCategory.APPLICATION_STATUS
        )
        self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)
        
        self.menu = Gtk.Menu()
        self.apt_manager = APTManager()
        self.window = UpdateWindow(self.translations, self.apt_manager)
        
        self.build_menu()
        self.indicator.set_menu(self.menu)
        
        # Check for updates on startup
        if show_window:
            # Window will check on show
            GLib.idle_add(self.on_open, None)
        else:
            self.check_updates_background()

        # Schedule background checks
        if self.config_manager.get("autostart"): # Or just always schedule if running?
             # The requirement is periodic checks.
             self.schedule_next_check()

    def schedule_next_check(self):
        value = self.config_manager.get("check_interval_value")
        unit = self.config_manager.get("check_interval_unit")
        
        multiplier = 60 # Default minutes
        if unit == "hours":
            multiplier = 3600
        elif unit == "days":
            multiplier = 86400
        elif unit == "weeks":
            multiplier = 604800
            
        interval_seconds = value * multiplier
        GLib.timeout_add_seconds(interval_seconds, self.on_periodic_check)

    def on_periodic_check(self):
        self.check_updates_background()
        # Re-schedule to account for config changes
        self.schedule_next_check()
        return False # Don't repeat automatically, we reschedule manually

    def build_menu(self):
        # Install Updates (Opens Window)
        item_install = Gtk.MenuItem(label=self.translations.get("install_updates"))
        item_install.connect("activate", self.on_install)
        self.menu.append(item_install)
        
        self.menu.append(Gtk.SeparatorMenuItem())
        
        # Maintenance
        item_autoremove = Gtk.MenuItem(label=self.translations.get("auto_remove"))
        item_autoremove.connect("activate", self.on_autoremove)
        self.menu.append(item_autoremove)
        
        item_autoclean = Gtk.MenuItem(label=self.translations.get("auto_clean"))
        item_autoclean.connect("activate", self.on_autoclean)
        self.menu.append(item_autoclean)
        
        self.menu.append(Gtk.SeparatorMenuItem())
        
        # Configuration
        item_config = Gtk.MenuItem(label=self.translations.get("settings"))
        item_config.connect("activate", self.on_config)
        self.menu.append(item_config)
        
        # About
        item_about = Gtk.MenuItem(label=self.translations.get("about"))
        item_about.connect("activate", self.on_about)
        self.menu.append(item_about)
        
        self.menu.append(Gtk.SeparatorMenuItem())
        
        # Quit
        item_quit = Gtk.MenuItem(label=self.translations.get("quit"))
        item_quit.connect("activate", self.on_quit)
        self.menu.append(item_quit)
        
        self.menu.show_all()
    
    def update_menu(self):
        """Update menu items with current language"""
        # Clear current menu
        for child in self.menu.get_children():
            self.menu.remove(child)
        
        # Rebuild menu with new translations
        self.build_menu()

    def check_updates_background(self):
        def callback(data):
            if data is None:
                # Finished
                packages = self.apt_manager.get_upgradable_packages()
                if packages:
                    self.show_notification(
                        self.translations.get("updates_found_title"),
                        f"{len(packages)} {self.translations.get('updates_found_msg')}"
                    )
                else:
                    # No updates available
                    self.show_notification(
                        self.translations.get("no_updates_title"),
                        self.translations.get("no_updates_msg")
                    )
            # Ignore line output during background check
        
        self.apt_manager.run_update(callback)

    def show_notification(self, title, message):
        icon = self.logo_path if os.path.exists(self.logo_path) else "system-software-update"
        notification = Notify.Notification.new(title, message, icon)
        notification.set_timeout(3000)  # 3 segundos
        notification.show()

    def on_open(self, widget):
        self.window.show_all()
        self.window.present()
        # Window auto-checks on show
        
    def on_install(self, widget):
        self.window.show_all()
        self.window.present()
        # Just open the window, don't auto-start install
        # The window will show the updates found (if any)
        # self.window.on_install_clicked(None)

    def on_autoremove(self, widget):
        self.window.show_all()
        self.window.present()
        self.window.on_autoremove_clicked(None)

    def on_autoclean(self, widget):
        self.window.show_all()
        self.window.present()
        self.window.on_autoclean_clicked(None)

    def on_config(self, widget):
        dialog = SettingsDialog(self.window, self.translations, self)
        dialog.run()
        dialog.destroy()
        
    def on_about(self, widget):
        # Use the window's about logic or create a new one
        # Since window has a nice about dialog now, let's use it
        self.window.on_about_clicked(None)

    def on_quit(self, widget):
        # Show confirmation dialog
        dialog = Gtk.MessageDialog(
            transient_for=None,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=self.translations.get("quit_confirmation_title")
        )
        dialog.format_secondary_text(self.translations.get("quit_confirmation_msg"))
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            Gtk.main_quit()
