import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import os
import pwd

from utils.config_manager import ConfigManager

class SettingsDialog(Gtk.Dialog):
    def __init__(self, parent, translations, tray=None):
        super().__init__(title=translations.get("settings"), transient_for=parent, flags=0)
        self.translations = translations
        self.config_manager = ConfigManager()
        self.parent_window = parent
        self.tray = tray
        self.updating = False  # Guard against recursion
        self.add_buttons(translations.get("close"), Gtk.ResponseType.CLOSE)
        
        self.set_default_size(350, 200)
        
        box = self.get_content_area()
        box.set_spacing(10)
        box.set_margin_top(20)
        box.set_margin_bottom(20)
        box.set_margin_start(20)
        box.set_margin_end(20)
        
        # Autostart
        self.check_autostart = Gtk.CheckButton(label=translations.get("start_auto"))
        self.check_autostart.set_active(self.config_manager.get("autostart"))
        self.check_autostart.connect("toggled", self.on_autostart_toggled)
        box.add(self.check_autostart)
        
        # Interval
        hbox_interval = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.lbl_interval = Gtk.Label(label=translations.get("interval_minutes"))
        hbox_interval.pack_start(self.lbl_interval, False, False, 0)
        
        # Value SpinButton
        adj = Gtk.Adjustment(value=self.config_manager.get("check_interval_value"), lower=1, upper=1000, step_increment=1, page_increment=10, page_size=0)
        self.spin_interval = Gtk.SpinButton(adjustment=adj)
        self.spin_interval.connect("value-changed", self.on_interval_value_changed)
        hbox_interval.pack_start(self.spin_interval, True, True, 0)
        
        # Unit ComboBox
        self.combo_unit = Gtk.ComboBoxText()
        self.combo_unit.append("minutes", translations.get("minutes"))
        self.combo_unit.append("hours", translations.get("hours"))
        self.combo_unit.append("days", translations.get("days"))
        self.combo_unit.append("weeks", translations.get("weeks"))
        
        current_unit = self.config_manager.get("check_interval_unit")
        self.combo_unit.set_active_id(current_unit)
        self.combo_unit.connect("changed", self.on_interval_unit_changed)
        
        hbox_interval.pack_start(self.combo_unit, False, False, 0)
        
        box.add(hbox_interval)
        
        # Language
        hbox_lang = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.lbl_lang = Gtk.Label(label=translations.get("language"))
        hbox_lang.pack_start(self.lbl_lang, False, False, 0)
        
        self.combo_lang = Gtk.ComboBoxText()
        languages = translations.get_available_languages()
        
        # Sort languages (optional)
        for code, name in languages.items():
            self.combo_lang.append(code, name)
            
        current_lang = self.config_manager.get("language")
        self.combo_lang.set_active_id(current_lang)
        self.combo_lang.connect("changed", self.on_language_changed)
        
        hbox_lang.pack_start(self.combo_lang, True, True, 0)
        box.add(hbox_lang)
        
        self.show_all()
    
    def update_texts(self):
        """Update all dialog texts with current language"""
        self.updating = True  # Start update
        try:
            self.set_title(self.translations.get("settings"))
            self.check_autostart.set_label(self.translations.get("start_auto"))
            self.lbl_interval.set_label(self.translations.get("interval_minutes"))
            self.lbl_lang.set_label(self.translations.get("language"))
            
            # Update combo unit items
            current_unit = self.combo_unit.get_active_id()
            self.combo_unit.remove_all()
            self.combo_unit.append("minutes", self.translations.get("minutes"))
            self.combo_unit.append("hours", self.translations.get("hours"))
            self.combo_unit.append("days", self.translations.get("days"))
            self.combo_unit.append("weeks", self.translations.get("weeks"))
            self.combo_unit.set_active_id(current_unit)
            
            # Update language combo items
            current_lang = self.combo_lang.get_active_id()
            self.combo_lang.remove_all()
            languages = self.translations.get_available_languages()
            for code, name in languages.items():
                self.combo_lang.append(code, name)
            self.combo_lang.set_active_id(current_lang)
        finally:
            self.updating = False  # End update

    def get_user_home(self):
        # Since we run as user now, just use expanduser
        return os.path.expanduser("~")

    def get_autostart_path(self):
        home = self.get_user_home()
        return os.path.join(home, ".config", "autostart", "luk-os-updater.desktop")

    def on_autostart_toggled(self, widget):
        path = self.get_autostart_path()
        enabled = widget.get_active()
        self.config_manager.set("autostart", enabled)
        
        if enabled:
            self.create_autostart_file(path)
        else:
            self.remove_autostart_file(path)

    def on_interval_value_changed(self, widget):
        self.config_manager.set("check_interval_value", int(widget.get_value()))

    def on_interval_unit_changed(self, widget):
        unit = widget.get_active_id()
        if unit:
            self.config_manager.set("check_interval_unit", unit)

    def on_language_changed(self, widget):
        if self.updating:
            return
            
        lang = widget.get_active_id()
        if lang:
            self.config_manager.set("language", lang)
            # Update language in translations object
            self.translations.set_language(lang)
            
            # Update this dialog
            self.update_texts()
            
            # Update parent window if exists
            if self.parent_window and hasattr(self.parent_window, 'update_translations'):
                self.parent_window.update_translations()
            
            # Update tray menu if exists
            if self.tray and hasattr(self.tray, 'update_menu'):
                self.tray.update_menu()

    def create_autostart_file(self, path):
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            
            import sys
            script_path = os.path.abspath(sys.argv[0])
            
            # No pkexec needed for autostart since we run as user
            content = f"""[Desktop Entry]
Type=Application
Name=Luk-Os Updater
Exec=python3 "{script_path}"
Icon=system-software-update
X-GNOME-Autostart-enabled=true
"""
            
            with open(path, "w") as f:
                f.write(content)
                
        except Exception as e:
            print(f"Error creating autostart: {e}")

    def remove_autostart_file(self, path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            print(f"Error removing autostart: {e}")
