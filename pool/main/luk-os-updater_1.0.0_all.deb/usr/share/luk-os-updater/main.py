import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib
from ui.tray import SystemTray
import signal
import os
import sys
import subprocess
import fcntl
import argparse
import socket
import threading

LOCK_FILE = '/tmp/luk-os-updater.lock'
SOCKET_PATH = '/tmp/luk-os-updater.sock'

def start_socket_server(tray):
    """Start a Unix socket server to listen for commands from other instances"""
    if os.path.exists(SOCKET_PATH):
        try:
            os.remove(SOCKET_PATH)
        except OSError:
            pass
    
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        server.bind(SOCKET_PATH)
        server.listen(1)
        
        def listen():
            while True:
                try:
                    conn, _ = server.accept()
                    data = conn.recv(1024)
                    if data == b"SHOW":
                        GLib.idle_add(tray.on_open, None)
                    conn.close()
                except Exception as e:
                    print(f"Socket error: {e}")
                    break

        t = threading.Thread(target=listen, daemon=True)
        t.start()
    except Exception as e:
        print(f"Failed to start socket server: {e}")

def send_show_command():
    """Send a command to the running instance to show the window"""
    try:
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.connect(SOCKET_PATH)
        client.send(b"SHOW")
        client.close()
        print("Sent show command to running instance.")
    except Exception as e:
        print(f"Could not connect to running instance: {e}")

def main():
    # Parse arguments
    parser = argparse.ArgumentParser(description="Luk-Os Updater")
    parser.add_argument("--window", action="store_true", help="Open the main window on startup")
    args = parser.parse_args()

    # Ensure only one instance is running
    try:
        fp = open(LOCK_FILE, 'w')
        # Try to acquire an exclusive lock on the file
        fcntl.lockf(fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        # Another instance is running
        if args.window:
            send_show_command()
        else:
            print("Another instance is already running.")
        sys.exit(0)
    
    # Allow Ctrl+C to exit
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    
    app_id = "luk-os-updater"
    tray = SystemTray(app_id, show_window=args.window)
    
    # Start listening for commands
    start_socket_server(tray)
    
    Gtk.main()

if __name__ == "__main__":
    main()
