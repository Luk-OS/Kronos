import json
import os

class ConfigManager:
    def __init__(self):
        self.config_dir = self.get_config_dir()
        self.config_file = os.path.join(self.config_dir, "settings.json")
        self.defaults = {
            "check_interval_value": 1,
            "check_interval_unit": "hours",
            "autostart": False,
            "language": "auto"
        }
        self.config = self.load_config()

    def get_config_dir(self):
        # Use user's home
        home = os.path.expanduser("~")
        path = os.path.join(home, ".config", "luk-os-updater")
        return path

    def load_config(self):
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                    # Merge with defaults
                    config = self.defaults.copy()
                    config.update(data)
                    return config
        except Exception as e:
            print(f"Error loading config: {e}")
        return self.defaults.copy()

    def save_config(self):
        try:
            os.makedirs(self.config_dir, exist_ok=True)
            
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
                
        except Exception as e:
            print(f"Error saving config: {e}")

    def get(self, key):
        return self.config.get(key, self.defaults.get(key))

    def set(self, key, value):
        self.config[key] = value
        self.save_config()
