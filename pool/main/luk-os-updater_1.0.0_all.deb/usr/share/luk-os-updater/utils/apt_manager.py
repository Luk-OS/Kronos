import subprocess
import threading

class APTManager:
    def __init__(self):
        pass

    def run_update(self, callback=None):
        """Runs apt list --upgradable to check for updates without root."""
        # Reverted to checking local cache to avoid password prompt
        self._run_command(["apt", "list", "--upgradable"], callback)

    def run_upgrade(self, callback=None):
        """Runs apt upgrade -y with pkexec and status-fd for progress."""
        # -o APT::Status-Fd=1 makes apt output status info to stdout
        self._run_command(["pkexec", "apt", "-o", "APT::Status-Fd=1", "upgrade", "-y"], callback)

    def run_autoremove(self, callback=None):
        """Runs apt autoremove -y with pkexec."""
        self._run_command(["pkexec", "apt", "autoremove", "-y"], callback)

    def run_autoclean(self, callback=None):
        """Runs apt autoclean with pkexec."""
        self._run_command(["pkexec", "apt", "autoclean"], callback)

    def get_upgradable_packages(self):
        """Returns a list of tuples (package, current_version, new_version)."""
        packages = []
        try:
            # Run apt list --upgradable
            # We don't need pkexec for this
            result = subprocess.run(
                ["apt", "list", "--upgradable"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            lines = result.stdout.splitlines()
            for line in lines:
                if "Listing..." in line:
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    # Format: package/repo version arch [upgradable from: old_version]
                    pkg_name = parts[0].split('/')[0]
                    new_ver = parts[1]
                    # Trying to extract old version if available, usually at the end
                    # This is a basic parser, might need refinement
                    packages.append((pkg_name, "...", new_ver))
        except Exception as e:
            print(f"Error getting packages: {e}")
        return packages

    def _run_command(self, command, callback):
        def target():
            try:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1
                )
                
                for line in process.stdout:
                    if callback:
                        # Parse APT progress from output
                        progress = self._parse_progress(line)
                        
                        # Determine if this is a machine-readable status line that shouldn't be shown in text view
                        is_status_line = line.startswith("dlstatus") or line.startswith("pmstatus")
                        text_to_show = None if is_status_line else line
                        
                        if progress is not None:
                            # Send progress as tuple (text_to_show, progress_percentage)
                            callback((text_to_show, progress))
                        else:
                            # Send just the line
                            callback((text_to_show, None))
                
                process.wait()
                if callback:
                    callback(None) # Signal finished
            except Exception as e:
                if callback:
                    callback((f"Error: {str(e)}\n", None))
                    callback(None)

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def _parse_progress(self, line):
        """Parse APT progress from output line using Status-Fd format"""
        import re
        
        # APT Status-Fd format:
        # dlstatus:pkg:percent:message
        # pmstatus:pkg:percent:message
        
        try:
            if line.startswith("dlstatus") or line.startswith("pmstatus"):
                parts = line.split(":")
                if len(parts) >= 3:
                    percent_str = parts[2]
                    return float(percent_str)
        except ValueError:
            pass

        # Fallback for standard output (e.g. during autoremove/clean which might not use status-fd)
        # APT shows progress like: "Progress: [50%]" or "Fetched 10.5 MB in 5s (2,100 kB/s)"
        match = re.search(r'(\d+)%', line)
        if match:
            return int(match.group(1))
        
        return None
