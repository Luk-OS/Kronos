import subprocess
import threading

class APTManager:
    def __init__(self):
        pass

    def run_update(self, callback=None):
        """Runs apt list --upgradable to check for updates without root."""
        # We can't run 'apt update' without root, so we check upgradable list.
        # This assumes the system updates its cache periodically or the user
        # has run apt update manually.
        # To force a cache update, we would need pkexec, but user requested
        # no password for checking.
        self._run_command(["apt", "list", "--upgradable"], callback)

    def run_upgrade(self, callback=None):
        """Runs apt upgrade -y with pkexec."""
        self._run_command(["pkexec", "apt", "upgrade", "-y"], callback)

    def run_autoremove(self, callback=None):
        """Runs apt autoremove -y with pkexec."""
        self._run_command(["pkexec", "apt", "autoremove", "-y"], callback)

    def run_autoclean(self, callback=None):
        """Runs apt autoclean with pkexec."""
        self._run_command(["pkexec", "apt", "autoclean"], callback)

    def get_upgradable_packages(self):
        """Returns a list of tuples (package, current_version, new_version)."""
        packages = []
        try:
            # Run apt list --upgradable
            # We don't need pkexec for this
            result = subprocess.run(
                ["apt", "list", "--upgradable"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            lines = result.stdout.splitlines()
            for line in lines:
                if "Listing..." in line:
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    # Format: package/repo version arch [upgradable from: old_version]
                    pkg_name = parts[0].split('/')[0]
                    new_ver = parts[1]
                    # Trying to extract old version if available, usually at the end
                    # This is a basic parser, might need refinement
                    packages.append((pkg_name, "...", new_ver))
        except Exception as e:
            print(f"Error getting packages: {e}")
        return packages

    def _run_command(self, command, callback):
        def target():
            try:
                process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1
                )
                
                for line in process.stdout:
                    if callback:
                        # Parse APT progress from output
                        progress = self._parse_progress(line)
                        if progress is not None:
                            # Send progress as tuple (line, progress_percentage)
                            callback((line, progress))
                        else:
                            # Send just the line
                            callback((line, None))
                
                process.wait()
                if callback:
                    callback(None) # Signal finished
            except Exception as e:
                if callback:
                    callback((f"Error: {str(e)}\n", None))
                    callback(None)

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    def _parse_progress(self, line):
        """Parse APT progress from output line"""
        import re
        # APT shows progress like: "Progress: [50%]" or "Fetched 10.5 MB in 5s (2,100 kB/s)"
        # Pattern for percentage: contains number followed by %
        match = re.search(r'(\d+)%', line)
        if match:
            return int(match.group(1))
        
        # Also check for "Reading database..." which can show progress
        if "Reading database" in line:
            match = re.search(r'(\d+)%', line)
            if match:
                return int(match.group(1))
        
        return None
