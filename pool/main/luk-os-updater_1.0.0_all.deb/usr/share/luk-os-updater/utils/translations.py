import locale

class Translations:
    STRINGS = {
        "en": {
            "check_updates": "Check for Updates",
            "install_updates": "Install Updates",
            "quit": "Quit",
            "checking": "Checking for updates...",
            "installing": "Installing updates...",
            "up_to_date": "System is up to date.",
            "updates_available": "Updates available:",
            "close": "Close",
            "error": "Error",
            "finished": "Finished",
            "package": "Package",
            "version": "Version",
            "new_version": "New Version",
            "open_updater": "Check for Updates",
            "system_updated_title": "System Updated",
            "system_updated_msg": "Your system is fully up to date.",
            "auto_remove": "Auto Remove unused packages",
            "auto_clean": "Auto Clean",
            "settings": "Settings",
            "start_auto": "Start automatically",
            "updates_found_title": "Updates Available",
            "updates_found_msg": "New updates are available for your system.",
            "interval_minutes": "Check interval:",
            "about": "About",
            "about_msg": "Luk-Os Updater\nA simple system tray application for managing system updates.",
            "minutes": "Minutes",
            "hours": "Hours",
            "days": "Days",
            "weeks": "Weeks",
            "menu": "Menu",
            "maintenance": "Maintenance",
            "updates_completed_title": "Updates Completed",
            "updates_completed_msg": "All updates have been successfully installed.",
            "no_updates_title": "No Updates Available",
            "no_updates_msg": "Your system is already up to date.",
            "autoremove_completed_title": "Auto Remove Completed",
            "autoremove_completed_msg": "Unused packages have been removed.",
            "autoclean_completed_title": "Auto Clean Completed",
            "autoclean_completed_msg": "Package cache has been cleaned.",
            "operation_completed": "Operation completed successfully.",
            "checking_updates": "Checking for updates...",
            "app_name": "Luk-Os Updater",
            "quit_confirmation_title": "Confirm Exit",
            "quit_confirmation_msg": "Are you sure you want to exit Luk-Os Updater?",
            "terminal_output": "Terminal Output",
            "language": "Language:",
            "lang_auto": "System Default",
            "lang_en": "English",
            "lang_es": "Spanish",
            "lang_fr": "French",
            "lang_de": "German",
            "lang_it": "Italian",
            "author_name": "Aprende con Sthip",
            "created_by_text": "Created by"
        },
        "es": {
            "check_updates": "Buscar actualizaciones",
            "install_updates": "Instalar actualizaciones",
            "quit": "Salir",
            "checking": "Buscando actualizaciones...",
            "installing": "Instalando actualizaciones...",
            "up_to_date": "El sistema está actualizado.",
            "updates_available": "Actualizaciones disponibles:",
            "close": "Cerrar",
            "error": "Error",
            "finished": "Finalizado",
            "package": "Paquete",
            "version": "Versión",
            "new_version": "Nueva Versión",
            "open_updater": "Buscar Actualizaciones",
            "system_updated_title": "Sistema Actualizado",
            "system_updated_msg": "Tu sistema está completamente actualizado.",
            "auto_remove": "Auto Eliminar paquetes no utilizados",
            "auto_clean": "Auto Limpiar",
            "settings": "Configuración",
            "start_auto": "Iniciar automáticamente",
            "updates_found_title": "Actualizaciones Disponibles",
            "updates_found_msg": "Hay nuevas actualizaciones disponibles para tu sistema.",
            "interval_minutes": "Intervalo de comprobación:",
            "about": "Acerca de",
            "about_msg": "Luk-Os Updater\nUna aplicación sencilla de bandeja del sistema para gestionar actualizaciones.",
            "minutes": "Minutos",
            "hours": "Horas",
            "days": "Días",
            "weeks": "Semanas",
            "menu": "Menú",
            "maintenance": "Mantenimiento",
            "updates_completed_title": "Actualizaciones Completadas",
            "updates_completed_msg": "Todas las actualizaciones se han instalado correctamente.",
            "no_updates_title": "No Hay Actualizaciones",
            "no_updates_msg": "Tu sistema ya está actualizado.",
            "autoremove_completed_title": "Auto Eliminación Completada",
            "autoremove_completed_msg": "Los paquetes no utilizados han sido eliminados.",
            "autoclean_completed_title": "Auto Limpieza Completada",
            "autoclean_completed_msg": "La caché de paquetes ha sido limpiada.",
            "operation_completed": "Operación completada exitosamente.",
            "checking_updates": "Buscando actualizaciones...",
            "app_name": "Actualizador Luk-Os",
            "quit_confirmation_title": "Confirmar Salida",
            "quit_confirmation_msg": "¿Estás seguro de que deseas salir del Actualizador Luk-Os?",
            "terminal_output": "Salida del Terminal",
            "language": "Idioma:",
            "lang_auto": "Predeterminado del Sistema",
            "lang_en": "Inglés",
            "lang_es": "Español",
            "lang_fr": "Francés",
            "lang_de": "Alemán",
            "lang_it": "Italiano",
            "author_name": "Aprende con Sthip",
            "created_by_text": "Creado por"
        },
        "fr": {
            "check_updates": "Vérifier les mises à jour",
            "install_updates": "Installer les mises à jour",
            "quit": "Quitter",
            "checking": "Vérification des mises à jour...",
            "installing": "Installation des mises à jour...",
            "up_to_date": "Le système est à jour.",
            "updates_available": "Mises à jour disponibles :",
            "close": "Fermer",
            "error": "Erreur",
            "finished": "Terminé",
            "package": "Paquet",
            "version": "Version",
            "new_version": "Nouvelle Version",
            "open_updater": "Vérifier les mises à jour",
            "system_updated_title": "Système mis à jour",
            "system_updated_msg": "Votre système est entièrement à jour.",
            "auto_remove": "Auto Suppression des paquets inutilisés",
            "auto_clean": "Auto Nettoyage",
            "settings": "Paramètres",
            "start_auto": "Démarrer automatiquement",
            "updates_found_title": "Mises à jour disponibles",
            "updates_found_msg": "De nouvelles mises à jour sont disponibles pour votre système.",
            "interval_minutes": "Intervalle de vérification :",
            "about": "À propos",
            "about_msg": "Luk-Os Updater\nUne application simple pour gérer les mises à jour système.",
            "minutes": "Minutes",
            "hours": "Heures",
            "days": "Jours",
            "weeks": "Semaines",
            "menu": "Menu",
            "maintenance": "Maintenance",
            "updates_completed_title": "Mises à jour terminées",
            "updates_completed_msg": "Toutes les mises à jour ont été installées avec succès.",
            "no_updates_title": "Aucune mise à jour disponible",
            "no_updates_msg": "Votre système est déjà à jour.",
            "autoremove_completed_title": "Suppression automatique terminée",
            "autoremove_completed_msg": "Les paquets inutilisés ont été supprimés.",
            "autoclean_completed_title": "Nettoyage automatique terminé",
            "autoclean_completed_msg": "Le cache des paquets a été nettoyé.",
            "operation_completed": "Opération terminée avec succès.",
            "checking_updates": "Vérification des mises à jour...",
            "app_name": "Mise à jour Luk-Os",
            "quit_confirmation_title": "Confirmer la sortie",
            "quit_confirmation_msg": "Êtes-vous sûr de vouloir quitter Mise à jour Luk-Os ?",
            "terminal_output": "Sortie du terminal",
            "language": "Langue :",
            "lang_auto": "Défaut du système",
            "lang_en": "Anglais",
            "lang_es": "Espagnol",
            "lang_fr": "Français",
            "lang_de": "Allemand",
            "lang_it": "Italien",
            "author_name": "Aprende con Sthip",
            "created_by_text": "Créé par"
        },
        "de": {
            "check_updates": "Nach Updates suchen",
            "install_updates": "Updates installieren",
            "quit": "Beenden",
            "checking": "Suche nach Updates...",
            "installing": "Installiere Updates...",
            "up_to_date": "Das System ist auf dem neuesten Stand.",
            "updates_available": "Verfügbare Updates:",
            "close": "Schließen",
            "error": "Fehler",
            "finished": "Fertig",
            "package": "Paket",
            "version": "Version",
            "new_version": "Neue Version",
            "open_updater": "Nach Updates suchen",
            "system_updated_title": "System aktualisiert",
            "system_updated_msg": "Ihr System ist auf dem neuesten Stand.",
            "auto_remove": "Automatisch entfernen unbenutzte Pakete",
            "auto_clean": "Automatisch bereinigen",
            "settings": "Einstellungen",
            "start_auto": "Automatisch starten",
            "updates_found_title": "Updates verfügbar",
            "updates_found_msg": "Neue Updates sind für Ihr System verfügbar.",
            "interval_minutes": "Prüfintervall:",
            "about": "Über",
            "about_msg": "Luk-Os Updater\nEine einfache Systemleistenanwendung zur Verwaltung von Systemupdates.",
            "minutes": "Minuten",
            "hours": "Stunden",
            "days": "Tage",
            "weeks": "Wochen",
            "menu": "Menü",
            "maintenance": "Wartung",
            "updates_completed_title": "Updates abgeschlossen",
            "updates_completed_msg": "Alle Updates wurden erfolgreich installiert.",
            "no_updates_title": "Keine Updates verfügbar",
            "no_updates_msg": "Ihr System ist bereits auf dem neuesten Stand.",
            "autoremove_completed_title": "Automatisches Entfernen abgeschlossen",
            "autoremove_completed_msg": "Nicht verwendete Pakete wurden entfernt.",
            "autoclean_completed_title": "Automatische Bereinigung abgeschlossen",
            "autoclean_completed_msg": "Der Paket-Cache wurde bereinigt.",
            "operation_completed": "Vorgang erfolgreich abgeschlossen.",
            "checking_updates": "Suche nach Updates...",
            "app_name": "Luk-Os Updater",
            "quit_confirmation_title": "Beenden bestätigen",
            "quit_confirmation_msg": "Sind Sie sicher, dass Sie Luk-Os Updater beenden möchten?",
            "terminal_output": "Terminal-Ausgabe",
            "language": "Sprache:",
            "lang_auto": "Systemstandard",
            "lang_en": "Englisch",
            "lang_es": "Spanisch",
            "lang_fr": "Französisch",
            "lang_de": "Deutsch",
            "lang_it": "Italienisch",
            "author_name": "Aprende con Sthip",
            "created_by_text": "Erstellt von"
        },
        "it": {
            "check_updates": "Controlla aggiornamenti",
            "install_updates": "Installa aggiornamenti",
            "quit": "Esci",
            "checking": "Controllo aggiornamenti...",
            "installing": "Installazione aggiornamenti...",
            "up_to_date": "Il sistema è aggiornato.",
            "updates_available": "Aggiornamenti disponibili:",
            "close": "Chiudi",
            "error": "Errore",
            "finished": "Finito",
            "package": "Pacchetto",
            "version": "Versione",
            "new_version": "Nuova Versione",
            "open_updater": "Controlla aggiornamenti",
            "system_updated_title": "Sistema aggiornato",
            "system_updated_msg": "Il tuo sistema è completamente aggiornato.",
            "auto_remove": "Rimozione automatica pacchetti inutilizzati",
            "auto_clean": "Pulizia automatica",
            "settings": "Impostazioni",
            "start_auto": "Avvio automatico",
            "updates_found_title": "Aggiornamenti disponibili",
            "updates_found_msg": "Sono disponibili nuovi aggiornamenti per il tuo sistema.",
            "interval_minutes": "Intervallo di controllo:",
            "about": "Informazioni",
            "about_msg": "Luk-Os Updater\nUna semplice applicazione per gestire gli aggiornamenti di sistema.",
            "minutes": "Minuti",
            "hours": "Ore",
            "days": "Giorni",
            "weeks": "Settimane",
            "menu": "Menu",
            "maintenance": "Manutenzione",
            "updates_completed_title": "Aggiornamenti completati",
            "updates_completed_msg": "Tutti gli aggiornamenti sono stati installati con successo.",
            "no_updates_title": "Nessun aggiornamento disponibile",
            "no_updates_msg": "Il tuo sistema è già aggiornato.",
            "autoremove_completed_title": "Rimozione automatica completata",
            "autoremove_completed_msg": "I pacchetti inutilizzati sono stati rimossi.",
            "autoclean_completed_title": "Pulizia automatica completata",
            "autoclean_completed_msg": "La cache dei pacchetti è stata pulita.",
            "operation_completed": "Operazione completata con successo.",
            "checking_updates": "Controllo aggiornamenti...",
            "app_name": "Aggiornatore Luk-Os",
            "quit_confirmation_title": "Conferma uscita",
            "quit_confirmation_msg": "Sei sicuro di voler uscire da Aggiornatore Luk-Os?",
            "terminal_output": "Output del terminale",
            "language": "Lingua:",
            "lang_auto": "Predefinito di sistema",
            "lang_en": "Inglese",
            "lang_es": "Spagnolo",
            "lang_fr": "Francese",
            "lang_de": "Tedesco",
            "lang_it": "Italiano",
            "author_name": "Aprende con Sthip",
            "created_by_text": "Creato da"
        }
    }

    def __init__(self):
        from utils.config_manager import ConfigManager
        self.config_manager = ConfigManager()
        
        self.lang = "en"  # Default to English
        config_lang = self.config_manager.get("language")
        
        if config_lang and config_lang != "auto":
            # User has explicitly set a language
            if config_lang in self.STRINGS:
                self.lang = config_lang
        else:
            # Try to detect system language
            self.lang = self._detect_system_language()
    
    def _detect_system_language(self):
        """Detect system language using multiple methods"""
        import os
        
        # Try multiple methods to detect system language
        lang_code = None
        
        # Method 1: locale.getdefaultlocale()
        try:
            sys_lang = locale.getdefaultlocale()[0]
            if sys_lang:
                lang_code = sys_lang.split('_')[0].lower()
                if lang_code in self.STRINGS:
                    return lang_code
        except:
            pass
        
        # Method 2: LANG environment variable
        try:
            lang_env = os.environ.get('LANG', '')
            if lang_env:
                lang_code = lang_env.split('_')[0].split('.')[0].lower()
                if lang_code in self.STRINGS:
                    return lang_code
        except:
            pass
        
        # Method 3: LANGUAGE environment variable
        try:
            language_env = os.environ.get('LANGUAGE', '')
            if language_env:
                # LANGUAGE can be a colon-separated list
                lang_code = language_env.split(':')[0].split('_')[0].lower()
                if lang_code in self.STRINGS:
                    return lang_code
        except:
            pass
        
        # Default to English if no supported language found
        return "en"

    def get(self, key):
        return self.STRINGS.get(self.lang, self.STRINGS["en"]).get(key, key)
    
    def set_language(self, lang_code):
        """Change the current language"""
        if lang_code == "auto":
            # Use the improved system language detection
            lang_code = self._detect_system_language()
        
        if lang_code in self.STRINGS:
            self.lang = lang_code
            return True
        return False

    def get_available_languages(self):
        """Return available languages with translated names"""
        # Access STRINGS directly to avoid recursion
        lang_strings = self.STRINGS.get(self.lang, self.STRINGS["en"])
        return {
            "auto": lang_strings.get("lang_auto", "System Default"),
            "en": lang_strings.get("lang_en", "English"),
            "es": lang_strings.get("lang_es", "Spanish"),
            "fr": lang_strings.get("lang_fr", "French"),
            "de": lang_strings.get("lang_de", "German"),
            "it": lang_strings.get("lang_it", "Italian")
        }
